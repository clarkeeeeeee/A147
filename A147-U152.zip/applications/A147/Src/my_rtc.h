#ifndef _MY_RTC_H_
#define _MY_RTC_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

void MyRtcInit();
void RTC_setTime(int16_t hh,int16_t mm,int16_t ss,bool);
void RTC_handle();

#endif



