#ifndef _PID_H_
#define _PID_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "top.h"

#define PID_INC		0
#define PID_MODE	3


#define PID_START		70
#define PID_STOT		96


#if PID_INC
typedef struct Pid
{
 	float error;//偏差  
    float error_next;//上一个偏差  
    float error_last;//上上一个偏差 
    float kp,ki,kd;//定义比例，积分，微分参数  
	float OUT;//增量
	int T;  //PID计算周期--采样周期
	int C1ms;
	
	float value;
}PID;
#else
typedef struct Pid
{
 	float Kp;
 	int T;  //PID计算周期--采样周期
 	float Ti;
 	float Td; 
	
	float ki;
	float kd;
	
 	float Ek;  //本次偏差
	float Ek_1;//上次偏差
	float SEk; //历史偏差之和
	
	float Iout;
	float Pout;
	float Dout;
	
 	float OUT;

 	int C1ms;
}PID;
#endif

extern PID pid;

void PID_Init(void);
bool PID_Calc(float,float);




#endif



