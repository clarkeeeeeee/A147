#include "led.h"
#include "dev.h"
#include "self_check.h"
#include "ack.h"
#include "top.h"
#include "connect.h"
#include "timer_process.h"
#include "time.h"
#include "lcd.h"
#include "single.h"


sKeyLed_t sKeyLed;
sCtxLed_t sCtxLed;
sKeyLedDuty_t sKeyLedDuty={0};
sCtxLedDuty_t sCtxLedDuty={0};

const uint8_t LedDutyDef[3]={LED_DUTY_OFF,LED_DUTY_DIM,LED_DUTY_ON};

extern ACKLifecycleState_t ACK_LifecycleState;

#define LED_WIFI_SEARCH_TICKS		(5*60*100)
uint32_t Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
unsigned int LedFullTime=POWER_ON_ALL_SHOW_TIME;

bool GetWifiSearchTicks()
{
	return (Led_WifiSearchTicks>0);
}
bool LedResetWifiSearchTicks()
{
//	if(!Led_WifiSearchTicks && gbWifiLost)
	{
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
		return true;
	}
//	return false;
}

typedef enum
{
	eLedStatus_Off,
	eLedStatus_Red_1S,
	eLedStatus_RedBlue_1S,
	eLedStatus_Red,
	eLedStatus_Blue,
	eLedStatus_RedBlinkingAt1Hz,
	eLedStatus_RedBlinkingAt2Hz,
	eLedStatus_RedBlueBlinkingAt1Hz,
	
	eLedStatus_RedBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0S2,
	eLedStatus_BlueBlinkingAt1Hz,
}eLedStatus_t;

eLedStatus_t eLedStatus=eLedStatus_Off;
uint16_t WifiLedTicks=0;

#define DEF_POWER_LED_ON	PF4=1
#define DEF_POWER_LED_OFF	PF4=0
#define DEF_READY_LED_ON	PA0=1
#define DEF_READY_LED_OFF	PA0=0
#define DEF_WIFI_RED_LED_ON		PC1=1
#define DEF_WIFI_RED_LED_OFF	PC1=0
#define DEF_WIFI_BLUE_LED_ON	PC0=1
#define DEF_WIFI_BLUE_LED_OFF	PC0=0

bool gbWifiLost=true;
bool gbResetWiFiCredentials=false;

#define LOST_WIFI_COUNTS		6000
uint32_t LostWifiCounts=LOST_WIFI_COUNTS;

extern int16_t gWifiLed_NoWifiWarnTicks;

void LedInit()
{
	GPIO_SetMode(PA, BIT0|BIT1|BIT2|BIT3|BIT4|BIT5|BIT6|BIT7, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT0|BIT1|BIT2|BIT3|BIT4|BIT5, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PF, BIT15, GPIO_MODE_OUTPUT);
}

static void WifiLed()
{
	static eLedStatus_t eLedStatus_bkp;
	static bool bAlexaConnected=false;
	
	if(gWifiLed_NoWifiWarnTicks>-1)
	{
		if(gWifiLed_NoWifiWarnTicks>50 || (gWifiLed_NoWifiWarnTicks>30 &&  gWifiLed_NoWifiWarnTicks<40) || (gWifiLed_NoWifiWarnTicks>10 &&  gWifiLed_NoWifiWarnTicks<20))
			sKeyLed.eWifiLed_Red=eLed_On;
		else
			sKeyLed.eWifiLed_Red=eLed_Off;
		sKeyLed.eWifiLed_White=eLed_Off;
		sKeyLed.eWifiLed_Blue=eLed_Off;
		gWifiLed_NoWifiWarnTicks--;
		return;
	}
	
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
	else
	{
		if(!Led_WifiSearchTicks)
		{
			if(!DevAwake)
				sKeyLed.eWifiLed_White=eLed_Off;
			else
				sKeyLed.eWifiLed_White=eLed_Dim;
			sKeyLed.eWifiLed_Blue=eLed_Off;
			sKeyLed.eWifiLed_Red=eLed_Off;
			return;
		}
	}
	
	if(gbResetWiFiCredentials)
	{
		WifiLedTicks=0;
		LostWifiCounts=0;
		
		if(sKey.key_cnts>1000 && sKey.key_cnts<=1200)
		{
			sKeyLed.eWifiLed_White=eLed_Off;
			sKeyLed.eWifiLed_Blue=eLed_On;
			sKeyLed.eWifiLed_Red=eLed_On;
		}
//		else if(sKey.key_cnts>1200 && sKey.key_cnts<=1230)
//		{
//			if((sKey.key_cnts>1200 && sKey.key_cnts<=1205)\
//				||(sKey.key_cnts>1210 && sKey.key_cnts<=1215)\
//				||(sKey.key_cnts>1220 && sKey.key_cnts<=1225)\
//			)
//			{
//				DEF_WIFI_BLUE_LED_OFF;
//				DEF_WIFI_RED_LED_ON;
//			}
//			else
//			{
//				DEF_WIFI_BLUE_LED_OFF;
//				DEF_WIFI_RED_LED_OFF;
//			}
//		}
		else
		{
			sKeyLed.eWifiLed_White=eLed_Off;
			sKeyLed.eWifiLed_Blue=eLed_Off;
			sKeyLed.eWifiLed_Red=eLed_Off;
		}
		return;
	}
	
	if(gbKeyUgsEn)
	{
		if(sFlip.ugs_led_on)
			sKeyLed.eWifiLed_Red=eLed_On;
		else
			sKeyLed.eWifiLed_Red=eLed_Off;
		sKeyLed.eWifiLed_White=eLed_Off;
		sKeyLed.eWifiLed_Blue=sKeyLed.eWifiLed_Red;
		
		gbWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		return;
	}
	if(gbKeyFrsEn)
	{
		if(sFlip.sFlip_1s)
			sKeyLed.eWifiLed_Red=eLed_On;
		else
			sKeyLed.eWifiLed_Red=eLed_Off;
		sKeyLed.eWifiLed_White=eLed_Off;
		sKeyLed.eWifiLed_Blue=eLed_Off;//sKeyLed.eWifiLed_Red;
		
		gbWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		return;
	}
	
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
	{
		sKeyLed.eWifiLed_White=eLed_Off;
		if(DevAwake)
			sKeyLed.eWifiLed_Blue=eLed_On;
		else
			sKeyLed.eWifiLed_Blue=eLed_Dim;
		sKeyLed.eWifiLed_Red=eLed_Off;
		
		bAlexaConnected=true;
		gbWifiLost=false;
		LostWifiCounts=0;
	}
	else if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
	{
		if(LostWifiCounts>=LOST_WIFI_COUNTS)
		{
			if(bAlexaConnected)
			{
				gbWifiLost=true;
				bAlexaConnected=false;
			}
			if(gbWifiLost)
			{
				Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
				
				if(sFlip.sFlip_1s)
				{
					sKeyLed.eWifiLed_Red=eLed_On;
					sKeyLed.eWifiLed_Blue=eLed_Off;
				}
				else
				{
					sKeyLed.eWifiLed_Red=eLed_Off;
					sKeyLed.eWifiLed_Blue=eLed_On;
				}
				sKeyLed.eWifiLed_White=eLed_Off;
			}
//			else
//			{
//				if(sFlip.sFlip_1s)
//					sKeyLed.eWifiLed_Red=eLed_On;
//				else
//					sKeyLed.eWifiLed_Red=eLed_Off;
//				sKeyLed.eWifiLed_White=eLed_Off;
//				sKeyLed.eWifiLed_Blue=eLed_Off;
//			}
		}
		
//		else if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
//			eLedStatus=eLedStatus_BlueBlinkingAt0Hz5;
//		else
//			eLedStatus=eLedStatus_Off;
	}
	else
	{
		bAlexaConnected=false;
		if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
		{
			LostWifiCounts=0;
//			DevAwake=DEV_AWAKE;
			if(sFlip.sFlip_1s)
				sKeyLed.eWifiLed_Red=eLed_On;
			else
				sKeyLed.eWifiLed_Red=eLed_Off;
			sKeyLed.eWifiLed_White=eLed_Off;
			sKeyLed.eWifiLed_Blue=eLed_Off;
		}
		else
		{
			sKeyLed.eWifiLed_White=eLed_Dim;
			sKeyLed.eWifiLed_Blue=eLed_Off;
			sKeyLed.eWifiLed_Red=eLed_Off;
		}
	}
}

extern int Alexa_InitiateFactoryReset();
bool gbUgsNoOpThenReboot=false;		//ugs opration fail , then reboot the module
void LedHandleForTmrInt()
{
	LostWifiCounts++;
	WifiLedTicks++;
	if(Led_WifiSearchTicks)
	{
		Led_WifiSearchTicks--;
		if(!Led_WifiSearchTicks)
		{
			if(gbKeyUgsEn)
			{
				gbUgsNoOpThenReboot=true;
			}
			
			gbKeyUgsEn=false;
			gbKeyFrsEn=false;
		}
	}
	if(LedFullTime)
	#if LED_DISPLAY_ALL
		;
	#else
		LedFullTime--;
	#endif
}


void LedAllClear()
{
	sCtxLed.eBrewingLed=eLed_Off;
	sCtxLed.eKeepLed=eLed_Off;
	sCtxLed.eWarmLed=eLed_Off;
	sCtxLed.eArrowLed_8=eLed_Off;
	sCtxLed.eArrowLed_10=eLed_Off;
	sCtxLed.eArrowLed_12=eLed_Off;
	sCtxLed.eArrowLed_14=eLed_Off;
	sCtxLed.eLed_Nbr8=eLed_Off;
	sCtxLed.eLed_Nbr10=eLed_Off;
	sCtxLed.eLed_Nbr12=eLed_Off;
	sCtxLed.eLed_Nbr14=eLed_Off;
	sCtxLed.eTubeLed=eLed_Off;

	sKeyLed.eCarafeLed=eLed_Off;
	sKeyLed.eBoldLed=eLed_Off;
	sKeyLed.eRegularLed=eLed_Off;
	sKeyLed.eSingleLed=eLed_Off;
	sKeyLed.eTimeLed=eLed_Off;
	sKeyLed.ePowerLed_White=eLed_Off;
	sKeyLed.ePowerLed_Red=eLed_Off;
	sKeyLed.eReadyToBrewLed_White=eLed_Off;
	sKeyLed.eReadyToBrewLed_Green=eLed_Off;
	sKeyLed.eWifiLed_Red=eLed_Off;
	sKeyLed.eWifiLed_Blue=eLed_Off;
	sKeyLed.eWifiLed_White=eLed_Off;
}

#define LED_1S		100

static void LedSelfCheck()
{
	static uint16_t ticks=0;
	static uint8_t step=0xff;
	
	if(!SelfCheckRetStatus())
		return;
	
	if(step!=eSelfCheck)
	{
		step=eSelfCheck;
		ticks=0;
	}
	
	switch(eSelfCheck)
	{
		case eSelfCheck_Display:
			sCtxLed.eBrewingLed=eLed_On;
			sCtxLed.eKeepLed=eLed_On;
			sCtxLed.eWarmLed=eLed_On;
			sCtxLed.eArrowLed_8=eLed_On;
			sCtxLed.eArrowLed_10=eLed_On;
			sCtxLed.eArrowLed_12=eLed_On;
			sCtxLed.eArrowLed_14=eLed_On;
			sCtxLed.eLed_Nbr8=eLed_On;
			sCtxLed.eLed_Nbr10=eLed_On;
			sCtxLed.eLed_Nbr12=eLed_On;
			sCtxLed.eLed_Nbr14=eLed_On;
			sCtxLed.eTubeLed=eLed_On;
		
			sKeyLed.eCarafeLed=eLed_On;
			sKeyLed.eBoldLed=eLed_On;
			sKeyLed.eRegularLed=eLed_On;
			sKeyLed.eSingleLed=eLed_On;
			sKeyLed.eTimeLed=eLed_On;
		
			if(ticks==0)
			{
				if(sKeyLed.ePowerLed_Red)
				{
					sKeyLed.ePowerLed_White=eLed_On;
					sKeyLed.ePowerLed_Red=eLed_Off;
				}
				else 
				{
					sKeyLed.ePowerLed_Red=eLed_On;
					sKeyLed.ePowerLed_White=eLed_Off;
				}
				
				if(sKeyLed.eReadyToBrewLed_Green)
				{
					sKeyLed.eReadyToBrewLed_White=eLed_On;
					sKeyLed.eReadyToBrewLed_Green=eLed_Off;
				}
				else 
				{
					sKeyLed.eReadyToBrewLed_Green=eLed_On;
					sKeyLed.eReadyToBrewLed_White=eLed_Off;
				}
				
				if(sKeyLed.eWifiLed_Blue)
				{
					sKeyLed.eWifiLed_Red=eLed_On;
					sKeyLed.eWifiLed_Blue=eLed_Off;
					sKeyLed.eWifiLed_White=eLed_Off;
				}
				else if(sKeyLed.eWifiLed_Red)
				{
					sKeyLed.eWifiLed_Blue=eLed_Off;
					sKeyLed.eWifiLed_Red=eLed_Off;
					sKeyLed.eWifiLed_White=eLed_On;
				}
				else 
				{
					sKeyLed.eWifiLed_White=eLed_Off;
					sKeyLed.eWifiLed_Red=eLed_Off;
					sKeyLed.eWifiLed_Blue=eLed_On;
				}
			}
			if(++ticks>=LED_1S)
				ticks=0;
		break;
		
		case eSelfCheck_CarafeCounts:
			LedAllClear();
			sKeyLed.eCarafeLed=eLed_On;
		break;
		case eSelfCheck_SingleCounts:
			LedAllClear();
			sKeyLed.eSingleLed=eLed_On;
		break;
		
		case eSelfCheck_Communication:
			LedAllClear();
			if(!gbSelfCheckGetModuleInf)
				ticks=0;
			else
			{
				sKeyLed.eWifiLed_Blue=eLed_On;
				if(++ticks>=LED_1S)
					eSelfCheck++;
			}
		break;

		case eSelfCheck_ButtonClock:	LedAllClear();	sKeyLed.eTimeLed=eLed_On;	break;
		case eSelfCheck_ButtonCarafe:	LedAllClear();	sKeyLed.eCarafeLed=eLed_On;	break;
		case eSelfCheck_ButtonSingle:	LedAllClear();	sKeyLed.eSingleLed=eLed_On;	break;
		case eSelfCheck_ButtonWifi:		LedAllClear();	sKeyLed.eWifiLed_White=eLed_On;	break;
		case eSelfCheck_ButtonReady:	LedAllClear();	sKeyLed.eReadyToBrewLed_White=eLed_On;	break;
		case eSelfCheck_ButtonBold:		LedAllClear();	sKeyLed.eBoldLed=eLed_On;	break;
		case eSelfCheck_ButtonRegular:	LedAllClear();	sKeyLed.eRegularLed=eLed_On;	break;
//		case eSelfCheck_ButtonPower:	LedAllClear();	sKeyLed.ePowerLed_White=eLed_On;	break;
			
		case eSelfCheck_CarafeTest:
			LedAllClear();
			sKeyLed.eCarafeLed=eLed_On;
//			sKeyLed.eReadyToBrewLed_Green=eLed_On;
			if(!gbSelfCheckRelayOn)
				sKeyLed.ePowerLed_White=eLed_Dim;
			else
				sKeyLed.ePowerLed_Red=eLed_On;
		break;
		case eSelfCheck_SingleServeTest:
			LedAllClear();
			sKeyLed.eSingleLed=eLed_On;
//			sKeyLed.eReadyToBrewLed_Green=eLed_On;
			if(!gbSelfCheckSingleRelayOn)
				sKeyLed.ePowerLed_White=eLed_Dim;
			else
				sKeyLed.ePowerLed_Red=eLed_On;
		break;	
			
			
		default:
			LedAllClear();
		break;
	}
}


static void SingleCtxLed(uint8_t msk)
{
	if(msk&1)
		sCtxLed.eLed_Nbr8=eLed_On;
	else
		sCtxLed.eLed_Nbr8=eLed_Off;
	
	if(msk&2)
		sCtxLed.eLed_Nbr10=eLed_On;
	else
		sCtxLed.eLed_Nbr10=eLed_Off;
	
	if(msk&4)
		sCtxLed.eLed_Nbr12=eLed_On;
	else
		sCtxLed.eLed_Nbr12=eLed_Off;
	
	if(msk&8)
		sCtxLed.eLed_Nbr14=eLed_On;
	else
		sCtxLed.eLed_Nbr14=eLed_Off;
}
static void Led_BrewSetup()
{
	static u8 ticks=0;
	
	if(!DevAwake)
		goto Led_BrewSetup__Clear;
	
	if(eBrewSetup==eBrewSetup_Carafe)
	{
		if(gCleaningRequiredLcd==CLEANING_REQUIRED_YES)
		{
			if(ticks<LED_1S)
				sKeyLed.eCarafeLed=eLed_On;
			else
				sKeyLed.eCarafeLed=eLed_Off;
			if(++ticks>=LED_1S*2)
				ticks=0;
		}
		else
			sKeyLed.eCarafeLed=eLed_On;
		if(eDevStatus<eDevStatus_ReadyToBrew)
			sKeyLed.eSingleLed=eLed_Dim;
		else
			sKeyLed.eSingleLed=eLed_Off;
		
		sCtxLed.eArrowLed_8=eLed_Off;
		sCtxLed.eArrowLed_10=eLed_Off;
		sCtxLed.eArrowLed_12=eLed_Off;
		sCtxLed.eArrowLed_14=eLed_Off;
		sCtxLed.eLed_Nbr8=eLed_Off;
		sCtxLed.eLed_Nbr10=eLed_Off;
		sCtxLed.eLed_Nbr12=eLed_Off;
		sCtxLed.eLed_Nbr14=eLed_Off;
		return;
	}
	if(eBrewSetup>=eBrewSetup_Single8 && eBrewSetup<=eBrewSetup_Single14)
	{
		sCtxLed.eArrowLed_8=eLed_Off;
		sCtxLed.eArrowLed_10=eLed_Off;
		sCtxLed.eArrowLed_12=eLed_Off;
		sCtxLed.eArrowLed_14=eLed_Off;
		
		if(gDevError)
		{
			if(ticks<LED_1S)
				sKeyLed.eSingleLed=eLed_On;
			else
				sKeyLed.eSingleLed=eLed_Off;
			if(++ticks>=LED_1S*2)
				ticks=0;
			SingleCtxLed(0);
			return;
		}
		else
			sKeyLed.eSingleLed=eLed_On;
		
		if(eDevStatus<eDevStatus_ReadyToBrew)
			sKeyLed.eCarafeLed=eLed_Dim;
		else
			sKeyLed.eCarafeLed=eLed_Off;
		
		
		switch(eBrewSetup)
		{
			case eBrewSetup_Single8:
				sCtxLed.eArrowLed_8=eLed_On;
			break;
			case eBrewSetup_Single10:
				sCtxLed.eArrowLed_10=eLed_On;
			break;
			case eBrewSetup_Single12:
				sCtxLed.eArrowLed_12=eLed_On;
			break;
			case eBrewSetup_Single14:
				sCtxLed.eArrowLed_14=eLed_On;
			break;
			default:
				break;
		}
		
		if(eDevStatus<eDevStatus_ReadyToBrew)
		{
			SingleCtxLed(0xf);
		}
		else
		{
			switch(eBrewSetup)
			{
				case eBrewSetup_Single8:
					SingleCtxLed(1);
				break;
				case eBrewSetup_Single10:
					SingleCtxLed(2);
				break;
				case eBrewSetup_Single12:
					SingleCtxLed(4);
				break;
				case eBrewSetup_Single14:
					SingleCtxLed(8);
				break;
				default:
					break;
			}
		}
		return;
	}
	
	Led_BrewSetup__Clear:
	{
		sKeyLed.eCarafeLed=eLed_Off;
		sKeyLed.eSingleLed=eLed_Off;
		sCtxLed.eArrowLed_8=eLed_Off;
		sCtxLed.eArrowLed_10=eLed_Off;
		sCtxLed.eArrowLed_12=eLed_Off;
		sCtxLed.eArrowLed_14=eLed_Off;
		sCtxLed.eLed_Nbr8=eLed_Off;
		sCtxLed.eLed_Nbr10=eLed_Off;
		sCtxLed.eLed_Nbr12=eLed_Off;
		sCtxLed.eLed_Nbr14=eLed_Off;
	}
}
//power led
static void Led_Power()
{
	static u8 ticks=0;
//	if(gbAcOff)
//		sKeyLed.ePowerLed_White=eLed_Off;
//	else
//		sKeyLed.ePowerLed_White=eLed_On;
//	return;
	
	if(!DevAwake)
		goto Led_Power__Clear;
	
	if(SingleGetClearWater() || gbForceSingleHeat)
	{
		if(ticks<LED_1S/2)
		{
			sKeyLed.ePowerLed_Red=eLed_On;
			sKeyLed.ePowerLed_White=eLed_Off;
		}
		else
		{
			sKeyLed.ePowerLed_Red=eLed_Off;
			sKeyLed.ePowerLed_White=eLed_Off;
		}
		if(++ticks>=LED_1S)
			ticks=0;
		return;
	}
	else
		ticks=0;
	
	if(eDevStatus<eDevStatus_ReadyToBrew)
	{
		sKeyLed.ePowerLed_Red=eLed_Off;
		sKeyLed.ePowerLed_White=eLed_On;
		return;
	}
	if(eDevStatus<eDevStatus_Brewing)		//eDevStatus_ReadyToBrew
	{
		sKeyLed.ePowerLed_Red=eLed_Off;
		sKeyLed.ePowerLed_White=eLed_Dim;
		return;
	}
	else
	{
		sKeyLed.ePowerLed_Red=eLed_On;
		sKeyLed.ePowerLed_White=eLed_Off;
		return;
	}
	
	Led_Power__Clear:
	{
		sKeyLed.ePowerLed_Red=eLed_Off;
		sKeyLed.ePowerLed_White=eLed_Off;
	}
}

//ready brew led
static void Led_ReadyToBrew()
{
	#if FM_SHOW
	if(gDevError&DEV_ERROR_NEEDLE)
	{
		sKeyLed.eReadyToBrewLed_Green=eLed_On;
		sKeyLed.eReadyToBrewLed_White=eLed_Off;
	}
	else
	{
		sKeyLed.eReadyToBrewLed_Green=eLed_Off;
		sKeyLed.eReadyToBrewLed_White=eLed_On;
	}
	return;
	#endif
	
	if(eDevStatus==eDevStatus_ReadyToBrew)
	{
		if(DevAwake)
			sKeyLed.eReadyToBrewLed_Green=eLed_On;
		else
			sKeyLed.eReadyToBrewLed_Green=eLed_Dim;
		sKeyLed.eReadyToBrewLed_White=eLed_Off;
	}
	else if(eDevStatus>eDevStatus_ReadyToBrew)
	{
		sKeyLed.eReadyToBrewLed_Green=eLed_Off;
		sKeyLed.eReadyToBrewLed_White=eLed_Off;
	}
	else
	{
		sKeyLed.eReadyToBrewLed_Green=eLed_Off;
		if(DevAwake)
		{
			if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
				sKeyLed.eReadyToBrewLed_White=eLed_On;
			else
				sKeyLed.eReadyToBrewLed_White=eLed_Dim;
		}
		else
			sKeyLed.eReadyToBrewLed_White=eLed_Off;
	}
}

//BrewStrength led
static void Led_BrewStrength()
{
	if(!DevAwake)
		goto Led_BrewStrength__Clear;
	
//	if(!DevAwake)
//	{
//		if(eBrewStrength==eBrewStrength_Regular)
//		{
//			sKeyLed.eRegularLed=eLed_Dim;
//			sKeyLed.eBoldLed=eLed_Off;
//			return;
//		}
//		if(eBrewStrength==eBrewStrength_Bold)
//		{
//			sKeyLed.eBoldLed=eLed_Dim;
//			sKeyLed.eRegularLed=eLed_Off;
//			return;
//		}
//	}
	
	if(eBrewStrength==eBrewStrength_Regular)
	{
		sKeyLed.eRegularLed=eLed_On;
		if(eDevStatus<=eDevStatus_ReadyToBrew)
			sKeyLed.eBoldLed=eLed_Dim;
		else
			sKeyLed.eBoldLed=eLed_Off;
		return;
	}
	if(eBrewStrength==eBrewStrength_Bold)
	{
		sKeyLed.eBoldLed=eLed_On;
		if(eDevStatus<=eDevStatus_ReadyToBrew)
			sKeyLed.eRegularLed=eLed_Dim;
		else
			sKeyLed.eRegularLed=eLed_Off;
		return;
	}
	
	Led_BrewStrength__Clear:
	{	
		sKeyLed.eRegularLed=eLed_Off;
		sKeyLed.eBoldLed=eLed_Off;
	}
}

//time key led
static void Led_Time()
{
	if(DevAwake)
	{
		if(!gbTimeShow)
			sKeyLed.eTimeLed=eLed_On;
		else
			sKeyLed.eTimeLed=eLed_Dim;
	}
	else
		sKeyLed.eTimeLed=eLed_Dim;
}

//brewing led
static void Led_Brewing()
{
	if(eDevStatus==eDevStatus_Brewing)
		sCtxLed.eBrewingLed=eLed_On;
	else
		sCtxLed.eBrewingLed=eLed_Off;
}
//kw led
static void Led_KeepWarm()
{
	if(eDevStatus>=eDevStatus_CoffeeReady)
	{
		sCtxLed.eKeepLed=eLed_On;
		sCtxLed.eWarmLed=eLed_On;
	}
	else if(eDevStatus>=eDevStatus_Brewing)
	{
		sCtxLed.eKeepLed=eLed_Off;
		sCtxLed.eWarmLed=eLed_Off;
	}
	else
	{
		sCtxLed.eKeepLed=eLed_Off;
		
		#if 0
		if(Single_GetKeepWarm())
		{
			if(DevAwake)
				sCtxLed.eWarmLed=eLed_On;
			else
				sCtxLed.eWarmLed=eLed_Off;//sCtxLed.eWarmLed=eLed_Dim;
		}
		else
		#endif
			sCtxLed.eWarmLed=eLed_Off;
	}	
}

//clock led
static void Led_Clock()
{
	if(!gbTimeShow)
		sCtxLed.eTubeLed=eLed_Off;
	else
		sCtxLed.eTubeLed=eLed_On;
}




//UPDATE ALL DUTY
static void UpdateLedDuty()
{
	sKeyLedDuty.BoldLed=LedDutyDef[sKeyLed.eBoldLed];
	sKeyLedDuty.CarafeLed=LedDutyDef[sKeyLed.eCarafeLed];
	sKeyLedDuty.PowerLed_Red=LedDutyDef[sKeyLed.ePowerLed_Red];
	sKeyLedDuty.PowerLed_White=LedDutyDef[sKeyLed.ePowerLed_White];
	sKeyLedDuty.ReadyToBrewLed_Green=LedDutyDef[sKeyLed.eReadyToBrewLed_Green];
	sKeyLedDuty.ReadyToBrewLed_White=LedDutyDef[sKeyLed.eReadyToBrewLed_White];
	sKeyLedDuty.RegularLed=LedDutyDef[sKeyLed.eRegularLed];
	sKeyLedDuty.SingleLed=LedDutyDef[sKeyLed.eSingleLed];
	sKeyLedDuty.TimeLed=LedDutyDef[sKeyLed.eTimeLed];
	sKeyLedDuty.WifiLed_Blue=LedDutyDef[sKeyLed.eWifiLed_Blue];
	sKeyLedDuty.WifiLed_Red=LedDutyDef[sKeyLed.eWifiLed_Red];
	sKeyLedDuty.WifiLed_White=LedDutyDef[sKeyLed.eWifiLed_White];
	
	
	sCtxLedDuty.ArrowLed_8=LedDutyDef[sCtxLed.eArrowLed_8];
	sCtxLedDuty.ArrowLed_10=LedDutyDef[sCtxLed.eArrowLed_10];
	sCtxLedDuty.ArrowLed_12=LedDutyDef[sCtxLed.eArrowLed_12];
	sCtxLedDuty.ArrowLed_14=LedDutyDef[sCtxLed.eArrowLed_14];
	sCtxLedDuty.Led_Nbr8=LedDutyDef[sCtxLed.eLed_Nbr8];
	sCtxLedDuty.Led_Nbr10=LedDutyDef[sCtxLed.eLed_Nbr10];
	sCtxLedDuty.Led_Nbr12=LedDutyDef[sCtxLed.eLed_Nbr12];
	sCtxLedDuty.Led_Nbr14=LedDutyDef[sCtxLed.eLed_Nbr14];
	sCtxLedDuty.BrewingLed=LedDutyDef[sCtxLed.eBrewingLed];
	sCtxLedDuty.KeepLed=LedDutyDef[sCtxLed.eKeepLed];
	sCtxLedDuty.WarmLed=LedDutyDef[sCtxLed.eWarmLed];
	sCtxLedDuty.TubeLed=LedDutyDef[sCtxLed.eTubeLed=eLed_On];
	
	if(sKeyLedDuty.PowerLed_Red)
	{
		if(sKeyLedDuty.TimeLed)
			sKeyLedDuty.TimeLed++;
		if(sKeyLedDuty.CarafeLed)
			sKeyLedDuty.CarafeLed++;
	}
}
void LedHandle()
{
	if(SelfCheckRetStatus())
	{
		LedSelfCheck();
		goto LedHandle_End;
	}
	
	if(LedFullTime)
	{
//		sKeyLed.eBoldLed=eLed_On;
//		sKeyLed.eCarafeLed=eLed_On;
//		sKeyLed.ePowerLed_Red=eLed_On;
//		sKeyLed.ePowerLed_White=eLed_On;
//		sKeyLed.eReadyToBrewLed_Green=eLed_On;
//		sKeyLed.eReadyToBrewLed_White=eLed_On;
//		sKeyLed.eRegularLed=eLed_On;
//		sKeyLed.eSingleLed=eLed_On;
//		sKeyLed.eTimeLed=eLed_On;
//		sKeyLed.eWifiLed_Blue=eLed_On;
//		sKeyLed.eWifiLed_Red=eLed_On;
//		sKeyLed.eWifiLed_White=eLed_On;
//		
//		sCtxLed.eArrowLed_10=eLed_On;
//		sCtxLed.eArrowLed_12=eLed_On;
//		sCtxLed.eArrowLed_14=eLed_On;
//		sCtxLed.eArrowLed_8=eLed_On;
//		sCtxLed.eLed_Nbr10=eLed_On;
//		sCtxLed.eLed_Nbr12=eLed_On;
//		sCtxLed.eLed_Nbr14=eLed_On;
//		sCtxLed.eLed_Nbr8=eLed_On;
//		sCtxLed.eBrewingLed=eLed_On;
//		sCtxLed.eKeepLed=eLed_On;
//		sCtxLed.eTubeLed=eLed_On;
//		sCtxLed.eWarmLed=eLed_On;
		goto LedHandle_End;
	}
	
	#ifdef LED_IS_RELAY_STATUS
	if(gbRelay)
	{
		sLedRoutine.LedLeftWifiRedLedOn();
		sLedRoutine.LedRightWifiRedLedOn();
	}
	else
	{
		sLedRoutine.LedLeftWifiLedOff();
		sLedRoutine.LedRightWifiLedOff();
	}
	return;
	#endif
	
	WifiLed();
	Led_BrewSetup();
	Led_Power();
	Led_ReadyToBrew();
	Led_BrewStrength();
	Led_Time();
	Led_Brewing();
	Led_KeepWarm();
	Led_Clock();
LedHandle_End:	
	UpdateLedDuty();
}



#define LED_SEG_VALID		1
#define LED_SEG_A			PA7
#define LED_SEG_B			PA6
#define LED_SEG_C			PA5
#define LED_SEG_D			PA4
#define LED_SEG_E			PA3
#define LED_SEG_F			PA2
#define LED_SEG_G			PA1
#define LED_SEG_H			PA0

#define LED_COM_VALID		1
#define LED_COM1			PC2
#define LED_COM2			PC4
#define LED_COM3			PC5
#define LED_COM4			PC3
#define LED_COM5			PC1
#define LED_COM6			PC0
#define LED_COM7			PF15


u8 LedRam[7]={0};
static u8 DutyLocal=0;

#define SET_LED_MSK_BOLD			LedRam[5]|=32
#define SET_LED_MSK_REGULAR			LedRam[5]|=128
#define SET_LED_MSK_CAFARE			LedRam[4]|=32
#define SET_LED_MSK_SINGLE			LedRam[6]|=64
#define SET_LED_MSK_POWER_RED		LedRam[4]|=17
#define SET_LED_MSK_POWER_WHITE		LedRam[4]|=6
#define SET_LED_MSK_READY_GREEN		LedRam[5]|=17
#define SET_LED_MSK_READY_WHITE		LedRam[5]|=6
#define SET_LED_MSK_TIME			LedRam[4]|=128
#define SET_LED_MSK_WIFI_BLUE		LedRam[2]|=128
#define SET_LED_MSK_WIFI_RED		LedRam[1]|=128
#define SET_LED_MSK_WIFI_WHITE		LedRam[0]|=128

#define CLR_LED_MSK_POWER_RED		LedRam[4]&=~17
#define CLR_LED_MSK_WIFI_BLUE		LedRam[2]&=~128
#define CLR_LED_MSK_WIFI_RED		LedRam[1]&=~128
#define CLR_LED_MSK_READY_GREEN		LedRam[5]&=~17

#define SET_LED_MSK_KEEP			LedRam[4]|=8
#define SET_LED_MSK_WARM			LedRam[5]|=8
#define SET_LED_MSK_ARROW8			LedRam[3]|=8
#define SET_LED_MSK_ARROW10			LedRam[6]|=1
#define SET_LED_MSK_ARROW12			LedRam[6]|=4
#define SET_LED_MSK_ARROW14			LedRam[6]|=16
#define SET_LED_MSK_NBR8			LedRam[3]|=128
#define SET_LED_MSK_NBR10			LedRam[6]|=2
#define SET_LED_MSK_NBR12			LedRam[6]|=8
#define SET_LED_MSK_NBR14			LedRam[6]|=32
#define SET_LED_MSK_BREWING			{LedRam[4]|=64;LedRam[5]|=64;}

static void ClrLedRam()
{
	u8 i=0;
	
	for(;i<sizeof(LedRam);i++)
		LedRam[i]=0;
}
static void Clr()
{
	LED_SEG_A=!LED_SEG_VALID;
	LED_SEG_B=!LED_SEG_VALID;
	LED_SEG_C=!LED_SEG_VALID;
	LED_SEG_D=!LED_SEG_VALID;
	LED_SEG_E=!LED_SEG_VALID;
	LED_SEG_F=!LED_SEG_VALID;
	LED_SEG_G=!LED_SEG_VALID;
	LED_SEG_H=!LED_SEG_VALID;
	
	LED_COM1=!LED_COM_VALID;
	LED_COM2=!LED_COM_VALID;
	LED_COM3=!LED_COM_VALID;
	LED_COM4=!LED_COM_VALID;
	LED_COM5=!LED_COM_VALID;
	LED_COM6=!LED_COM_VALID;
	LED_COM7=!LED_COM_VALID;
}
static void UpdateSeg(u8 seg_msk)
{
	if(seg_msk&1)
		LED_SEG_A=LED_SEG_VALID;
	else
		LED_SEG_A=!LED_SEG_VALID;
	
	if(seg_msk&2)
		LED_SEG_B=LED_SEG_VALID;
	else
		LED_SEG_B=!LED_SEG_VALID;
	
	if(seg_msk&4)
		LED_SEG_C=LED_SEG_VALID;
	else
		LED_SEG_C=!LED_SEG_VALID;
	
	if(seg_msk&8)
		LED_SEG_D=LED_SEG_VALID;
	else
		LED_SEG_D=!LED_SEG_VALID;
	
	if(seg_msk&16)
		LED_SEG_E=LED_SEG_VALID;
	else
		LED_SEG_E=!LED_SEG_VALID;
	
	if(seg_msk&32)
		LED_SEG_F=LED_SEG_VALID;
	else
		LED_SEG_F=!LED_SEG_VALID;
	
	if(seg_msk&64)
		LED_SEG_G=LED_SEG_VALID;
	else
		LED_SEG_G=!LED_SEG_VALID;
	
	if(seg_msk&128)
		LED_SEG_H=LED_SEG_VALID;
	else
		LED_SEG_H=!LED_SEG_VALID;
}




static void UpdateTubeRam()
{
	if(LedFullTime)
	{
		LedRam[3]|=32;
		LedRam[3]|=16;
		LedRam[0]|=0x7f;
		LedRam[1]|=0x7f;
		LedRam[2]|=0x7f;
		LedRam[3]|=2;
		LedRam[3]|=4;
		LedRam[3]|=1;
		LedRam[3]|=64;
		return;
	}
	
	if(DutyLocal>=sCtxLedDuty.TubeLed)
		return;
	
	if(LcdRam[0]&2)	//first bc
		LedRam[3]|=32;
	if(LcdRam[0]&4)
		LedRam[3]|=16;
	
	LedRam[0]|=(LcdRam[1]&0x7f);
	LedRam[1]|=(LcdRam[2]&0x7f);
	LedRam[2]|=(LcdRam[3]&0x7f);
	
	if(LcdRam[4]&1)	//colon
		LedRam[3]|=2;
	if(LcdRam[4]&2)
		LedRam[3]|=4;
	
	if(LcdRam[4]&4)	//colon
		LedRam[3]|=1;
	if(LcdRam[4]&8)
		LedRam[3]|=64;
}
static void UpdateLedRam()
{
	if(DutyLocal<sCtxLedDuty.TubeLed)
	{
		UpdateTubeRam();
	}
	
	if(DutyLocal<sKeyLedDuty.BoldLed)
		SET_LED_MSK_BOLD;
	if(DutyLocal<sKeyLedDuty.CarafeLed)
		SET_LED_MSK_CAFARE;
	if(DutyLocal<sKeyLedDuty.PowerLed_Red)
		SET_LED_MSK_POWER_RED;
	if(DutyLocal<sKeyLedDuty.PowerLed_White)
		SET_LED_MSK_POWER_WHITE;
	if(DutyLocal<sKeyLedDuty.ReadyToBrewLed_Green)
		SET_LED_MSK_READY_GREEN;
	if(DutyLocal<sKeyLedDuty.ReadyToBrewLed_White)
		SET_LED_MSK_READY_WHITE;
	if(DutyLocal<sKeyLedDuty.RegularLed)
		SET_LED_MSK_REGULAR;
	if(DutyLocal<sKeyLedDuty.SingleLed)
		SET_LED_MSK_SINGLE;
	if(DutyLocal<sKeyLedDuty.TimeLed)
		SET_LED_MSK_TIME;
	if(DutyLocal<sKeyLedDuty.WifiLed_Blue)
		SET_LED_MSK_WIFI_BLUE;
	if(DutyLocal<sKeyLedDuty.WifiLed_Red)
		SET_LED_MSK_WIFI_RED;
	if(DutyLocal<sKeyLedDuty.WifiLed_White)
		SET_LED_MSK_WIFI_WHITE;
	
	
	if(DutyLocal<sCtxLedDuty.KeepLed)
		SET_LED_MSK_KEEP;
	if(DutyLocal<sCtxLedDuty.WarmLed)
		SET_LED_MSK_WARM;
	if(DutyLocal<sCtxLedDuty.BrewingLed)
		SET_LED_MSK_BREWING;
	if(DutyLocal<sCtxLedDuty.ArrowLed_8)
		SET_LED_MSK_ARROW8;
	if(DutyLocal<sCtxLedDuty.ArrowLed_10)
		SET_LED_MSK_ARROW10;
	if(DutyLocal<sCtxLedDuty.ArrowLed_12)
		SET_LED_MSK_ARROW12;
	if(DutyLocal<sCtxLedDuty.ArrowLed_14)
		SET_LED_MSK_ARROW14;
	if(DutyLocal<sCtxLedDuty.Led_Nbr8)
		SET_LED_MSK_NBR8;
	if(DutyLocal<sCtxLedDuty.Led_Nbr10)
		SET_LED_MSK_NBR10;
	if(DutyLocal<sCtxLedDuty.Led_Nbr12)
		SET_LED_MSK_NBR12;
	if(DutyLocal<sCtxLedDuty.Led_Nbr14)
		SET_LED_MSK_NBR14;
}

void LedScan()
{
	static u8 ComIdx=0;
	
	
	
//	UpdateSeg(0xff);
//	LED_COM1=0;
//	LED_COM2=1;
//	LED_COM3=1;
//	return;
	
	Clr();
	
//	LED_COM1=1;
//	UpdateSeg(0XFF);
//	return;
	
//	if(DutyLocal==0)	//no display
//	{
//		goto LedInt_SkipUpdateSeg;
//	}
	if(LedFullTime)
	{
		LedRam[0]=0xff;
		LedRam[1]=0xff;
		LedRam[2]=0xff;
		LedRam[3]=0xff;
		LedRam[4]=0xff;
		LedRam[5]=0xff;
		LedRam[6]=0xff;
		
		CLR_LED_MSK_POWER_RED;
		CLR_LED_MSK_WIFI_BLUE;
		CLR_LED_MSK_WIFI_RED;
		CLR_LED_MSK_READY_GREEN;
	}
	else
	{
		ClrLedRam();
		UpdateLedRam();
	}
	switch(ComIdx)
	{
		case 0:
			UpdateSeg(LedRam[0]);
			LED_COM1=1;
		break;
		
		case 1:
			UpdateSeg(LedRam[1]);
			LED_COM2=1;
		break;
		
		case 2:
			UpdateSeg(LedRam[2]);
			LED_COM3=1;
		break;
		
		case 3:
			UpdateSeg(LedRam[3]);
			LED_COM4=1;
		break;
		
		case 4:
			UpdateSeg(LedRam[4]);
			LED_COM5=1;
		break;
		
		case 5:
			UpdateSeg(LedRam[5]);
			LED_COM6=1;
		break;
		
		case 6:
			UpdateSeg(LedRam[6]);
			LED_COM7=1;
		break;
		
		default:
		break;
	}
	
LedInt_SkipUpdateSeg:	
	if(++DutyLocal>=LED_DUTY_REF)
	{
		DutyLocal=0;
		if(++ComIdx>=7)
			ComIdx=0;
	}
}





