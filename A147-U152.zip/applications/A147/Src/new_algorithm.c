
#include "new_algorithm.h"
#include "dev.h"
#include "pid.h"

#if (FIRMWARE_VERSION>10 || (FIRMWARE_VERSION==10 && FIRMWARE_VERSION_MINOR>5))

#define UPDATE_DELAY    20      //BASE 10MS

#if FIRMWARE_VERSION>10
#define RATE            UPDATE_DELAY/2500
#define DUTY_ADJ_ECHO   0.48/UPDATE_DELAY
#define DUTY_ADJ_ECHO2	0.0003*UPDATE_DELAY
#else
#define RATE            UPDATE_DELAY/2200
#define DUTY_ADJ_ECHO   0.45/UPDATE_DELAY
#define DUTY_ADJ_ECHO2	0.00025*UPDATE_DELAY
#endif

#define DUTY_ADJ_ECHO3_HEATTEMP		0.0010*UPDATE_DELAY

static float RateDyn;
static float DiffNow;
static uint16_t NewAlgorithmTicks;
static float ValuePre;
static float NewAlgorithmRes;
static float Echo2Res;
static float Echo3Res;
float NewAlgorithm__Duty;

void NewAlgorithmInit(float now)
{
    NewAlgorithmTicks=0;
    ValuePre=-1;
	
	float comp;
	comp=(float)HeatTemp*0.8+now*0.2;
	
	if(comp<PID_START)
	{
		NewAlgorithm__Duty=40;//SINGLE_MT_DUTY_MIN;
		return;
	}
	if(0)//comp>PID_STOT)
	{
		NewAlgorithm__Duty=40*SINGLE_MT_PERIOD/100;
		return;
	}
//	NewAlgorithm__Duty=(comp-PID_START)*SINGLE_MT_PERIOD/100+SINGLE_MT_DUTY_MIN;
	NewAlgorithm__Duty=(comp-PID_START)*0.8+SINGLE_MT_DUTY_MIN;
//	NewAlgorithm__Duty=SINGLE_MT_DUTY_MIN;
}

bool NewAlgorithm(float des,float now)
{
    if(++NewAlgorithmTicks>=UPDATE_DELAY)
        NewAlgorithmTicks=0;
    else
        return false;

    if(ValuePre==-1)
    {
        ValuePre=now;
        return false;
    }
    RateDyn=(float)(des-now)*RATE;
    DiffNow=now-ValuePre;
    ValuePre=now;
	
	
	if	(DiffNow>0)
		NewAlgorithmRes=(float)(DiffNow-RateDyn)*DUTY_ADJ_ECHO*NewAlgorithm__Duty;
	else
		NewAlgorithmRes=(float)(DiffNow-RateDyn)*DUTY_ADJ_ECHO*NewAlgorithm__Duty;
//	NewAlgorithmRes=NewAlgorithmRes*NewAlgorithm__Duty/100;
	if(now>des+1.9)
		Echo2Res=(float)(now-des)*DUTY_ADJ_ECHO2*NewAlgorithm__Duty;
	else
		Echo2Res=0;
//	if(HeatTemp<now)
		Echo3Res=(float)(HeatTemp-now)*DUTY_ADJ_ECHO3_HEATTEMP*0.5;
	//else
	//	Echo3Res=0;
	
    NewAlgorithm__Duty+=NewAlgorithmRes;
	NewAlgorithm__Duty+=Echo2Res;
	NewAlgorithm__Duty+=Echo3Res;
	if(NewAlgorithm__Duty<18*SINGLE_MT_PERIOD/100)
		NewAlgorithm__Duty=18*SINGLE_MT_PERIOD/100;
//	if(NewAlgorithm__Duty<SINGLE_MT_DUTY_MIN)
//		NewAlgorithm__Duty=SINGLE_MT_DUTY_MIN;
	
	printf("%s now=%.2f,HeatTemp=%d,RateDyn=%.2f,DiffNow=%.2f,NewAlgorithmRes=%.2f,Echo2Res=%.2f,Echo3Res=%.2f,NewAlgorithm__Duty=%d \r\n",__func__,now,HeatTemp,RateDyn,DiffNow,NewAlgorithmRes,Echo2Res,Echo3Res,(uint8_t)NewAlgorithm__Duty);
    return true;
}
#else
#define UPDATE_DELAY    20      //BASE 10MS
#define RATE            UPDATE_DELAY/1888
#define DUTY_ADJ_ECHO   0.65/UPDATE_DELAY
#define DUTY_ADJ_ECHO2	0.0003*UPDATE_DELAY
#define DUTY_ADJ_ECHO3_HEATTEMP		0.0010*UPDATE_DELAY

static float RateDyn;
static float DiffNow;
static uint16_t NewAlgorithmTicks;
static float ValuePre;
static float NewAlgorithmRes;
static float Echo2Res;
static float Echo3Res;
float NewAlgorithm__Duty;

void NewAlgorithmInit(float now)
{
    NewAlgorithmTicks=0;
    ValuePre=-1;
	
	float comp;
	comp=(float)HeatTemp*0.8+now*0.2;
	
	if(comp<PID_START)
	{
		NewAlgorithm__Duty=40;//SINGLE_MT_DUTY_MIN;
		return;
	}
	if(0)//comp>PID_STOT)
	{
		NewAlgorithm__Duty=40*SINGLE_MT_PERIOD/100;
		return;
	}
//	NewAlgorithm__Duty=(comp-PID_START)*SINGLE_MT_PERIOD/100+SINGLE_MT_DUTY_MIN;
	NewAlgorithm__Duty=(comp-PID_START)*0.2+SINGLE_MT_DUTY_MIN;
//	NewAlgorithm__Duty=SINGLE_MT_DUTY_MIN;
}

bool NewAlgorithm(float des,float now)
{
    if(++NewAlgorithmTicks>=UPDATE_DELAY)
        NewAlgorithmTicks=0;
    else
        return false;

    if(ValuePre==-1)
    {
        ValuePre=now;
        return false;
    }
    RateDyn=(float)(des-now)*RATE;
    DiffNow=now-ValuePre;
    ValuePre=now;
	
	
	if	(DiffNow>0)
		NewAlgorithmRes=(float)(DiffNow-RateDyn)*DUTY_ADJ_ECHO*NewAlgorithm__Duty;
	else
		NewAlgorithmRes=(float)(DiffNow-RateDyn)*DUTY_ADJ_ECHO*NewAlgorithm__Duty;
//	NewAlgorithmRes=NewAlgorithmRes*NewAlgorithm__Duty/100;
	if(now>des+1.5)
		Echo2Res=(float)(now-des)*DUTY_ADJ_ECHO2*NewAlgorithm__Duty;
	else
		Echo2Res=0;
//	if(HeatTemp<now)
		Echo3Res=(float)(HeatTemp-now)*DUTY_ADJ_ECHO3_HEATTEMP*0.5;
	//else
	//	Echo3Res=0;
	
    NewAlgorithm__Duty+=NewAlgorithmRes;
	NewAlgorithm__Duty+=Echo2Res;
	NewAlgorithm__Duty+=Echo3Res;
	if(NewAlgorithm__Duty<18*SINGLE_MT_PERIOD/100)
		NewAlgorithm__Duty=18*SINGLE_MT_PERIOD/100;
//	if(NewAlgorithm__Duty<SINGLE_MT_DUTY_MIN)
//		NewAlgorithm__Duty=SINGLE_MT_DUTY_MIN;
	
	#if C_PRINT
	printf("%s now=%.2f,HeatTemp=%d,RateDyn=%.2f,DiffNow=%.2f,NewAlgorithmRes=%.2f,Echo2Res=%.2f,Echo3Res=%.2f,NewAlgorithm__Duty=%d \r\n",__func__,now,HeatTemp,RateDyn,DiffNow,NewAlgorithmRes,Echo2Res,Echo3Res,(uint8_t)NewAlgorithm__Duty);
    #endif
	return true;
}
#endif






























