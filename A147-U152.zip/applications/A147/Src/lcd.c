#include "lcd.h"
#include "time.h"
#include "dev.h"
#include "brew.h"
#include "self_check.h"
#include "key.h"
#include "xw_touch.h"
#include "single.h"


#define LCD_RAM_LEN		5

#define LCD_1S		100

unsigned char LcdScanIdx=0;
unsigned char LcdRam[LCD_RAM_LEN];
unsigned char LcdRamBuf[LCD_RAM_LEN];
unsigned int LcdFullTime=POWER_ON_ALL_SHOW_TIME;

const unsigned char NBR_TAB[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

#define DEF_WORD_C		0X39
#define DEF_WORD_L		0X38
#define DEF_WORD_E		0X79
#define DEF_WORD_A		0X77
#define DEF_WORD_n		0X54
#define DEF_WORD_U		0X3e
#define DEF_WORD_P		0X73
#define DEF_WORD_S		0x6d
#define DEF_WORD_N		0x37
#define DEF_WORD_b		0x7c
#define DEF_WORD_F		0x71
#define DEF_WORD_I		0x30
#define DEF_WORD_H		0x76
#define DEF_WORD_d		0x5e
#define DEF_WORD_2		0x5b
#define DEF_WORD_0		0x3f
#define DEF_WORD_t		0x78
#define DEF_WORD_o		0x5c

#define DEF_WORD_LINE	0x40
#define DEF_WORD_DOWN_LINE	0x08


#define LCD_SEG1(X)	PB7=X
#define LCD_SEG2(X)	PB6=X
#define LCD_SEG3(X)	PB5=X
#define LCD_SEG4(X)	PB4=X
#define LCD_SEG5(X)	PB1=X
#define LCD_SEG6(X)	PB0=X
#define LCD_SEG7(X)	PA11=X


#define LCD_COM1(X)	PB12=X
#define LCD_COM2(X)	PC14=X
#define LCD_COM3(X)	PB14=X
#define LCD_COM4(X)	PB13=X



#define LCD_COM1_DIR(X)		{if(X) GPIO_SetMode(PB, BIT12, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT12, GPIO_MODE_INPUT);}
#define LCD_COM2_DIR(X)		{if(X) GPIO_SetMode(PC, BIT14, GPIO_MODE_OUTPUT);else GPIO_SetMode(PC, BIT14, GPIO_MODE_INPUT);}
#define LCD_COM3_DIR(X)		{if(X) GPIO_SetMode(PB, BIT14, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT14, GPIO_MODE_INPUT);}
#define LCD_COM4_DIR(X)		{if(X) GPIO_SetMode(PB, BIT13, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT13, GPIO_MODE_INPUT);}



#define NBR1_BC		LcdRamBuf[0]|=1
#define NBR2_D		LcdRamBuf[0]|=2
#define COLON		LcdRamBuf[4]|=3
#define NBR3_D		LcdRamBuf[0]|=8
#define BOLD		LcdRamBuf[0]|=16
#define NBR4_D		LcdRamBuf[0]|=32
#define REGULAR		LcdRamBuf[0]|=64


#define NBR2_E		LcdRamBuf[1]|=1
#define NBR2_C		LcdRamBuf[1]|=2
#define NBR3_E		LcdRamBuf[1]|=4
#define NBR3_C		LcdRamBuf[1]|=8
#define NBR4_E		LcdRamBuf[1]|=16
#define NBR4_C		LcdRamBuf[1]|=32
#define CUPS1_4		LcdRamBuf[1]|=64

#define NBR2_G		LcdRamBuf[2]|=1
#define NBR2_B		LcdRamBuf[2]|=2
#define NBR3_G		LcdRamBuf[2]|=4
#define NBR3_B		LcdRamBuf[2]|=8
#define NBR4_G		LcdRamBuf[2]|=16
#define NBR4_B		LcdRamBuf[2]|=32
#define PM			LcdRamBuf[4]|=8

#define NBR2_F		LcdRamBuf[3]|=1
#define NBR2_A		LcdRamBuf[3]|=2
#define NBR3_F		LcdRamBuf[3]|=4
#define NBR3_A		LcdRamBuf[3]|=8
#define NBR4_F		LcdRamBuf[3]|=16
#define NBR4_A		LcdRamBuf[3]|=32
#define AM			LcdRamBuf[4]|=4



static void lcd_ram_reload()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRam[i]=LcdRamBuf[i];
}

void LcdPortInit()
{
}

static void lcd_nbr1(unsigned char nbr)
{
	if(nbr>1 || !nbr)
		return;	
	LcdRamBuf[0]|=NBR_TAB[nbr];
}
static void lcd_nbr2(unsigned char nbr)
{
	if(nbr>9)
		return;
	LcdRamBuf[1]|=NBR_TAB[nbr];
}
static void lcd_nbr2_word(unsigned char word)
{
	LcdRamBuf[1]|=word;
}
static void lcd_nbr3(unsigned char nbr)
{
	if(nbr>9)
		return;
	LcdRamBuf[2]|=NBR_TAB[nbr];
}
static void lcd_nbr3_word(unsigned char word)
{
	LcdRamBuf[2]|=word;
}

static void lcd_nbr4(unsigned char nbr)
{
	if(nbr>9)
		return;
	LcdRamBuf[3]|=NBR_TAB[nbr];
}

static void lcd_nbr4_word(unsigned char word)
{
	LcdRamBuf[3]|=word;
}

static void lcd_nbr12(unsigned char nbr)
{
	if(nbr>19)
		return;
	lcd_nbr1(nbr/10);
	lcd_nbr2(nbr%10);
}
static void lcd_nbr34(unsigned char nbr)
{
	if(nbr>99)
		return;
	lcd_nbr3(nbr/10);
	lcd_nbr4(nbr%10);
}
static void lcd_nbr34_remove_pre_0(unsigned char nbr)
{
	if(nbr>99)
		return;
	if(nbr>9)
		lcd_nbr3(nbr/10);
	lcd_nbr4(nbr%10);
}
static void lcd_test()
{
	lcd_nbr1(1);
	lcd_nbr2(2);
	lcd_nbr3(3);
	lcd_nbr4(4);
}

static void lcd_full()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRamBuf[i]=0xff;
}
static void lcd_clear()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRamBuf[i]=0;
}
static uint16_t LcdTicks_Nbr1234=0;
static void lcd_TimeNotValid()
{
	if(LcdTicks_Nbr1234>100)
	{
		lcd_nbr2_word(DEF_WORD_LINE);
		lcd_nbr3_word(DEF_WORD_LINE);
		lcd_nbr4_word(DEF_WORD_LINE);
	}
	COLON;
}
static void lcd_TimeValid()
{
	if(LcdTicks_Nbr1234>100)
	{
		COLON;
	}
	lcd_nbr12(sTime.hh);
	lcd_nbr34(sTime.mm);
	if(sTime.am)
		AM;
	else
		PM;
}
static void lcd_TimeCfg()
{
	if(!sTime.cfg_idx)
		return;
	
	COLON;
	if(sTime.am)
		AM;
	else
		PM;
	if(sTime.cfg_idx==1)
	{
		if(TimeGetCfgDisp())
			lcd_nbr12(sTime.hh);
		lcd_nbr34(sTime.mm);
	}
	if(sTime.cfg_idx==2)
	{
		if(TimeGetCfgDisp())
			lcd_nbr34(sTime.mm);
		lcd_nbr12(sTime.hh);
	}
}

typedef enum
{
	eLcdNbr1234_TimeNotValid,
	eLcdNbr1234_TimeValid,
	eLcdNbr1234_TimeCfg,
	eLcdNbr1234_None,
}eLcdNbr1234_t;

eLcdNbr1234_t eLcdNbr1234;
eLcdNbr1234_t eLcdNbr1234Bkp;

void ReloadLcdTicks_Nbr1234()
{
	switch(eLcdNbr1234)
	{
		case eLcdNbr1234_TimeNotValid:
		case eLcdNbr1234_TimeValid:
			LcdTicks_Nbr1234=200;
		break;
		
		case eLcdNbr1234_TimeCfg:
			LcdTicks_Nbr1234=100;
		break;
		
		default:
			break;
	}
}


//#define DEF_WORD_C		0X39
//#define DEF_WORD_L		0X38
//#define DEF_WORD_E		0X79
//#define DEF_WORD_A		0X77
//#define DEF_WORD_n		0X54
static uint16_t lcd_clean_ticks=0;
static uint16_t lcd_clean_step=0;
static bool lcd_clean()
{
	bool b_ret=true;
	
	if(++lcd_clean_ticks>=1700)
	{
		lcd_clean_ticks=0;
	}
	lcd_clean_step=lcd_clean_ticks/100;
	
	switch(lcd_clean_step)
	{
		case 0:
			lcd_nbr4_word(DEF_WORD_C);
		break;
		case 1:
			lcd_nbr3_word(DEF_WORD_C);
			lcd_nbr4_word(DEF_WORD_L);
		break;
		case 2:
			lcd_nbr2_word(DEF_WORD_C);
			lcd_nbr3_word(DEF_WORD_L);
			lcd_nbr4_word(DEF_WORD_E);
		break;
		case 3:
			lcd_nbr2_word(DEF_WORD_L);
			lcd_nbr3_word(DEF_WORD_E);
			lcd_nbr4_word(DEF_WORD_A);
		break;
		case 4:
			lcd_nbr2_word(DEF_WORD_E);
			lcd_nbr3_word(DEF_WORD_A);
			lcd_nbr4_word(DEF_WORD_N);
		break;
		case 5:
			lcd_nbr2_word(DEF_WORD_A);
			lcd_nbr3_word(DEF_WORD_N);
		break;
		case 6:
			lcd_nbr2_word(DEF_WORD_N);
		break;
		
		default:
			b_ret=false;
		break;
	}
	return b_ret;
}




static uint16_t lcd_self_check_ticks=0;
static uint16_t lcd_self_check_step=1;

static void lcd_self_check_version()
{
	if(lcd_self_check_ticks<LCD_1S)
	{
		lcd_nbr2_word(DEF_WORD_U);
		lcd_nbr34(FIRMWARE_VERSION);
		#if(FIRMWARE_VERSION_MINOR>0)
		COLON;
		#endif
	}
	if(lcd_self_check_ticks>LCD_1S*2)
		SelfCheckStepsPlus();
}
static void lcd_self_check_hw_version()
{
	if(lcd_self_check_ticks<LCD_1S)
	{
		lcd_nbr2_word(DEF_WORD_P);
		lcd_nbr34(HARDWARE_VERSION);
	}
	if(lcd_self_check_ticks>LCD_1S*2)
		SelfCheckStepsPlus();
}



static void lcd_self_check()
{
	if(++lcd_self_check_ticks>=70)
	{
		lcd_self_check_ticks=0;
		if(++lcd_self_check_step>7)
			SelfCheckStepsPlus();
	}
	
	if(lcd_self_check_step)
		lcd_nbr1(1);
	if(lcd_self_check_step>1)
		lcd_nbr2(8);
	if(lcd_self_check_step>2)
		COLON;
	if(lcd_self_check_step>3)
		lcd_nbr3(8);
	if(lcd_self_check_step>4)
		lcd_nbr4(8);
	if(lcd_self_check_step>5)
		AM;
	if(lcd_self_check_step>6)
		PM;
}



static void lcd_show_str3(u8 *str)
{
	lcd_nbr2_word(*str++);
	lcd_nbr3_word(*str++);
	lcd_nbr4_word(*str++);
}

static void lcd_show_nbr_dyn(uint32_t nbr)
{
	static u8 str_ori[20];
	static u8 str_idx=0;
	static u8 len=0;
	static u32 nbr_bkp=0xffffffff;
	
	if(nbr_bkp!=nbr)
	{
		nbr_bkp=nbr;
		str_idx=0;
		str_ori[str_idx++]=0;
		str_ori[str_idx++]=0;
		if(nbr>999999999)
			str_ori[str_idx++]=NBR_TAB[nbr/1000000000];
		if(nbr>99999999)
			str_ori[str_idx++]=NBR_TAB[nbr%1000000000/100000000];
		if(nbr>9999999)
			str_ori[str_idx++]=NBR_TAB[nbr%100000000/10000000];
		if(nbr>999999)
			str_ori[str_idx++]=NBR_TAB[nbr%10000000/1000000];
		if(nbr>99999)
			str_ori[str_idx++]=NBR_TAB[nbr%1000000/100000];
		if(nbr>9999)
			str_ori[str_idx++]=NBR_TAB[nbr%100000/10000];
		if(nbr>999)
			str_ori[str_idx++]=NBR_TAB[nbr%10000/1000];
		if(nbr>99)
			str_ori[str_idx++]=NBR_TAB[nbr%1000/100];
		if(nbr>9)
			str_ori[str_idx++]=NBR_TAB[nbr%100/10];
		str_ori[str_idx++]=NBR_TAB[nbr%10];
		str_ori[str_idx++]=DEF_WORD_DOWN_LINE;
		str_ori[str_idx++]=DEF_WORD_DOWN_LINE;
		str_ori[str_idx++]=0;
		str_ori[str_idx++]=0;
		len=str_idx-2;
		str_idx=0;
	}
	
	if(++lcd_self_check_ticks>=LCD_1S)
	{
		lcd_self_check_ticks=0;
		if(++str_idx>=len)
			str_idx=0;
	}
	
	lcd_show_str3(&str_ori[str_idx]);
}
static void lcd_show_FILLH2O_dyn(bool reset)
{
	static u8 str_ori[]={0,0,DEF_WORD_F,DEF_WORD_I,DEF_WORD_L,DEF_WORD_L,0,DEF_WORD_H,DEF_WORD_2,DEF_WORD_0,0,0};
	static u8 str_idx=0;
	static u8 len=10;
	static u8 ticks=0;
	
	if(reset)
	{
		ticks=0;
		str_idx=0;
		return;
	}
	
	if(++ticks>=LCD_1S)
	{
		ticks=0;
		if(++str_idx>=len)
			str_idx=0;
	}
	lcd_show_str3(&str_ori[str_idx]);
}
static void lcd_show_nEEdLE_dyn(bool reset)
{
	static u8 str_ori[]={0,0,DEF_WORD_n,DEF_WORD_E,DEF_WORD_E,DEF_WORD_d,DEF_WORD_L,DEF_WORD_E,0,0};
	static u8 str_idx=0;
	static u8 len=8;
	static u8 ticks=0;
	
	if(reset)
	{
		ticks=0;
		str_idx=0;
		return;
	}
	
	if(++ticks>=LCD_1S)
	{
		ticks=0;
		if(++str_idx>=len)
			str_idx=0;
	}
	lcd_show_str3(&str_ori[str_idx]);
}
static void lcd_show_CloseLid_dyn(bool reset)
{
	static u8 str_ori[]={0,0,DEF_WORD_C,DEF_WORD_L,DEF_WORD_0,DEF_WORD_S,DEF_WORD_E,0,DEF_WORD_L,DEF_WORD_I,DEF_WORD_d,0,0};
	static u8 str_idx=0;
	static u8 len=11;
	static u8 ticks=0;
	
	if(reset)
	{
		ticks=0;
		str_idx=0;
		return;
	}
	
	if(++ticks>=LCD_1S)
	{
		ticks=0;
		if(++str_idx>=len)
			str_idx=0;
	}
	lcd_show_str3(&str_ori[str_idx]);
}
static bool lcd_show_CLEAn_dyn()
{
	static u8 str_ori[]={0,0,DEF_WORD_C,DEF_WORD_L,DEF_WORD_E,DEF_WORD_A,DEF_WORD_N,0,0};
	static u8 str_idx=0;
	const u8 len=7;
	static u8 ticks=0;
	
	if(++ticks>=LCD_1S)
	{
		ticks=0;
		if(++str_idx>=len+10)
			str_idx=0;
	}
	
	if(str_idx<7)
	{
		lcd_show_str3(&str_ori[str_idx]);
		return true;
	}
	return false;
}


#define LCD_EC1		{lcd_nbr2_word(DEF_WORD_E);\
					lcd_nbr3_word(DEF_WORD_C);\
					lcd_nbr4(1);}
#define LCD_EC2		{lcd_nbr2_word(DEF_WORD_E);\
					lcd_nbr3_word(DEF_WORD_C);\
					lcd_nbr4(2);}
#define LCD_N10		{lcd_nbr2_word(DEF_WORD_n);\
					lcd_nbr3(1);\
					lcd_nbr4(0);}
#define LCD_N11		{lcd_nbr2_word(DEF_WORD_n);\
					lcd_nbr3(1);\
					lcd_nbr4(1);}
#define LCD_N20		{lcd_nbr2_word(DEF_WORD_n);\
					lcd_nbr3(2);\
					lcd_nbr4(0);}
#define LCD_N21		{lcd_nbr2_word(DEF_WORD_n);\
					lcd_nbr3(2);\
					lcd_nbr4(1);}
#define LCD_OT		{lcd_nbr2_word(DEF_WORD_H);\
					lcd_nbr3_word(DEF_WORD_o);\
					lcd_nbr4_word(DEF_WORD_t);}
static void lcd_show_selfcheck()
{
	static bool b_key_succ=false;
	switch(eSelfCheck)
	{
		case eSelfCheck_Display:
			lcd_full();
		break;
		case eSelfCheck_FwV:
			lcd_self_check_version();
		break;
		case eSelfCheck_HwV:
			lcd_self_check_hw_version();
		break;
		case eSelfCheck_CarafeCounts:
			lcd_show_nbr_dyn(CarafeCounts);
		break;
		case eSelfCheck_SingleCounts:
			lcd_show_nbr_dyn(SingleCounts);
		break;	
		case eSelfCheck_ButtonClock:	if(geKey==eKey_TIME)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(1);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonCarafe:	if(geKey==eKey_CARAFE)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(2);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonSingle:	if(geKey==eKey_SINGLE)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(3);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonWifi:		if(geKey==eKey_WIFI)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(4);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonReady:	if(geKey==eKey_READY)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(5);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonBold:		if(geKey==eKey_BOLD)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(6);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		case eSelfCheck_ButtonRegular:	if(geKey==eKey_REGULAR)	{lcd_nbr2_word(DEF_WORD_LINE);lcd_nbr3(7);lcd_nbr4_word(DEF_WORD_LINE);b_key_succ=true;}
			else if(b_key_succ && geKey==eKey_Null)		{b_key_succ=false;SelfCheckStepsPlus();}
		break;
		
		case eSelfCheck_CarafeTest:
			if(gbSelfCheckRelayOn)
				break;
			if(gSelfCheckError&SELF_CHECK_ERROR_EC1)
			{
				LCD_EC1;
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_EC2)
			{
				LCD_EC2;
				break;
			}
		break;
			
		case eSelfCheck_SingleServeTest:
			if(gSelfCheckError&SELF_CHECK_ERROR_EC2)
			{
				LCD_EC2;
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_b10)
			{
				lcd_nbr2_word(DEF_WORD_b);
				lcd_nbr3(1);
				lcd_nbr4(0);
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_F01)
			{
				lcd_nbr2_word(DEF_WORD_F);
				lcd_nbr3(0);
				lcd_nbr4(1);
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_A10)
			{
				lcd_nbr2_word(DEF_WORD_A);
				lcd_nbr3(1);
				lcd_nbr4(0);
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_A11)
			{
				lcd_nbr2_word(DEF_WORD_A);
				lcd_nbr3(1);
				lcd_nbr4(1);
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_n10)
			{
				LCD_N10;
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_n11)
			{
				LCD_N11;
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_n20)
			{
				LCD_N20;
				break;
			}
			if(gSelfCheckError&SELF_CHECK_ERROR_n21)
			{
				LCD_N21;
				break;
			}
//			lcd_nbr12(PumpCurrentAdcRes/100);
//			lcd_nbr34(PumpCurrentAdcRes%100);
		break;
		
		case eSelfCheck_Over:
			lcd_nbr2_word(DEF_WORD_P);
			lcd_nbr3_word(DEF_WORD_A);
			lcd_nbr4_word(DEF_WORD_S);
		break;
		
		default:
			break;
	}
}

#if TEMP_SHOW
u16 GetShowTemp(float temp)
{
	static float temp_sum=0;
	static u8 sum_idx=0;
	static float ret=0;
	
	temp_sum+=temp;
	if(++sum_idx>=50)
	{
		sum_idx=0;
		ret=temp_sum/50;
		temp_sum=0;
	}
	return (u16)ret;
}
#endif
uint16_t SingleCupSizeDynDisplay=0;
void LcdHandle()
{
	static uint8_t step=0xff;
	
	
	
	lcd_clear();
	
	if(SelfCheckRetStatus())
	{
		if(step!=eSelfCheck)
		{
			step=eSelfCheck;
			lcd_self_check_ticks=0;
		}
		lcd_show_selfcheck();
		goto Step_lcd_ram_reload;
	}
	
	
//	lcd_nbr12(sKey.key_now/100);
//	lcd_nbr34(sKey.key_now%100);
//	goto Step_lcd_ram_reload;
	
	if(gKeyStuck)
	{
		lcd_nbr2_word(DEF_WORD_E);
		lcd_nbr34(gKeyStuck);
		goto Step_lcd_ram_reload;
	}
	if(LcdFullTime)
	{
		lcd_full();
		goto Step_lcd_ram_reload;
	}
	
	#if AC_ZERO_SHOW
	lcd_nbr12(GetAcZeroCounts()/100);
	lcd_nbr34(GetAcZeroCounts()%100);
	goto Step_lcd_ram_reload;
	#endif
	
	#if CURRENT_SHOW
//	extern sMtDrive_t sMtDrive;
//	PumpCurrentAdcRes=sMtDrive.period;
	lcd_nbr12(PumpCurrentAdcRes/100);
	lcd_nbr34(PumpCurrentAdcRes%100);
	goto Step_lcd_ram_reload;
	#endif
	#if DUTY_SHOW
	extern uint8_t SingleMtDutyReal;
	lcd_nbr34(SingleMtDutyReal);
	goto Step_lcd_ram_reload;
	#endif
	#if TEMP_SHOW
//	u16 temp=GetShowTemp(WaterTemp);
	u16 temp=WaterTempForXb;
//	u16 temp=HeatTemp;
//	u16 temp=OverTempProtectCounts;
	lcd_nbr12(temp/100);
	lcd_nbr34(temp%100);
	goto Step_lcd_ram_reload;
	#endif
	#if FM_SHOW
	lcd_nbr12(GetFlowmeter()/100);
	lcd_nbr34(GetFlowmeter()%100);
	goto Step_lcd_ram_reload;
	#endif
	
	if(!DevAwake)
		goto time_show;
	
	
	/*
	DEVICE ERROR
	#define DEV_ERROR_WATER_NTC_OC	(1<<0)
	#define DEV_ERROR_WATER_NTC_SC	(1<<1)
	#define DEV_ERROR_HEAT_NTC_OC	(1<<2)
	#define DEV_ERROR_HEAT_NTC_SC	(1<<3)
	#define DEV_ERROR_FILL_H2O		(1<<4)
	#define DEV_ERROR_NEEDLE		(1<<5)
	#define DEV_ERROR_OVER_TEMP		(1<<6)
	#define DEV_ERROR_CLOSE_LID		(1<<7)
	#define DEV_ERROR_CLEAN			(1<<8)

	#define DEV_ERROR_EC1	(1<<9)
	#define DEV_ERROR_EC2	(1<<10)
	#define DEV_ERROR_A10	(1<<11)
	#define DEV_ERROR_A11	(1<<12)
	*/
	if(gDevError&DEV_ERROR_WATER_NTC_OC)
	{
		LCD_N21;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_WATER_NTC_SC)
	{
		LCD_N20;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_HEAT_NTC_OC)
	{
		LCD_N11;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_HEAT_NTC_SC)
	{
		LCD_N10;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_EC1)
	{
		LCD_EC1;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_EC2)
	{
		LCD_EC2;
		goto Step_lcd_ram_reload;
	}
	if(gDevError&DEV_ERROR_OVER_TEMP)
	{
		LCD_OT;
		goto Step_lcd_ram_reload;
	}
	
	
	if(gCleaningRequiredLcd==CLEANING_REQUIRED_YES || gSingleCleaningRequiredLcd==CLEANING_REQUIRED_YES)
	{
		if(lcd_clean())
			goto Step_lcd_ram_reload;
		else
			goto time_show;
	}
	else
	{
		lcd_clean_ticks=0;
		lcd_clean_step=0;
	}
	
	
	if(gDevError&DEV_ERROR_FILL_H2O)
	{
		lcd_show_FILLH2O_dyn(false);
		goto Step_lcd_ram_reload;
	}
	else
		lcd_show_FILLH2O_dyn(true);
	
	if(gDevError&DEV_ERROR_NEEDLE)
	{
		lcd_show_nEEdLE_dyn(false);
		goto Step_lcd_ram_reload;
	}
	else
		lcd_show_nEEdLE_dyn(true);
	
	if(gDevError&DEV_ERROR_CLOSE_LID && eBrewSetup>=eBrewSetup_Single8)
	{
		lcd_show_CloseLid_dyn(false);
		goto Step_lcd_ram_reload;
	}
	else
		lcd_show_CloseLid_dyn(true);
	
	if(SingleCupFmCountsUnitCfgTicks)
	{
		lcd_nbr12(SingleCupFmCountsUnit/100);
		lcd_nbr34(SingleCupFmCountsUnit%100);
		goto Step_lcd_ram_reload;
	}
	
	
	if(sTime.cfg_idx)
	{
		eLcdNbr1234=eLcdNbr1234_TimeCfg;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234;
		lcd_TimeCfg();
		goto Step_lcd_ram_reload;
	}
	
	
	
	if(eBrewSetup>=eBrewSetup_Single8)
	{
		if(eDevStatus>eDevStatus_ReadyToBrew)
		{
			lcd_nbr34_remove_pre_0(SingleGetCupSizeDyn());
//			SingleCupSizeDynDisplay=17*100;
			goto Step_lcd_ram_reload;
		}
		if(SingleCupSizeDynDisplay)
		{
			SingleCupSizeDynDisplay--;
			lcd_nbr34_remove_pre_0(SingleGetCupSizeDyn());
			goto Step_lcd_ram_reload;
		}
	}
	
	time_show:
	if(!gbTimeShow)
	{
		goto Step_lcd_ram_reload;
	}
	if(sTime.valid)
	{
		eLcdNbr1234=eLcdNbr1234_TimeValid;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234;
		lcd_TimeValid();
		goto Step_lcd_ram_reload;
	}
	if(!sTime.valid)
	{
		if(sTime.invalid_ticks>=(5*60*100))
		{
			gbTimeShow=false;
			goto Step_lcd_ram_reload;
		}
		
		eLcdNbr1234=eLcdNbr1234_TimeNotValid;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234;
		lcd_TimeNotValid();
		goto Step_lcd_ram_reload;
	}
	Step_lcd_ram_reload:
	if(gDevError || eBrewSetup<eBrewSetup_Single8)
		SingleCupSizeDynDisplay=0;
	lcd_ram_reload();
}

void LcdHandleForTmrInt()
{
	if(LcdFullTime)
		LcdFullTime--;
	if(LcdTicks_Nbr1234)
		LcdTicks_Nbr1234--;
	else
		ReloadLcdTicks_Nbr1234();
	lcd_self_check_ticks++;
}





















































