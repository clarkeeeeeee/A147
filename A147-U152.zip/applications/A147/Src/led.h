#ifndef _LED_H_
#define _LED_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbWifiLost;
extern bool gbResetWiFiCredentials;
extern bool gbUgsNoOpThenReboot;


typedef enum
{
	eLed_Off,
	eLed_Dim,
	eLed_On,
}eLed_t;

typedef struct
{
	eLed_t eWifiLed_White;
	eLed_t eWifiLed_Red;
	eLed_t eWifiLed_Blue;
	eLed_t ePowerLed_Red;
	eLed_t ePowerLed_White;
	eLed_t eReadyToBrewLed_White;
	eLed_t eReadyToBrewLed_Green;
	eLed_t eCarafeLed;
	eLed_t eSingleLed;
	eLed_t eRegularLed;
	eLed_t eBoldLed;
	eLed_t eTimeLed;
	//以上为按键灯
}sKeyLed_t;
extern sKeyLed_t sKeyLed;

typedef struct
{
	uint8_t WifiLed_White;
	uint8_t WifiLed_Red;
	uint8_t WifiLed_Blue;
	uint8_t PowerLed_Red;
	uint8_t PowerLed_White;
	uint8_t ReadyToBrewLed_White;
	uint8_t ReadyToBrewLed_Green;
	uint8_t CarafeLed;
	uint8_t SingleLed;
	uint8_t RegularLed;
	uint8_t BoldLed;
	uint8_t TimeLed;
	//以上为按键灯
}sKeyLedDuty_t;
extern sKeyLedDuty_t sKeyLedDuty;

typedef struct
{
	eLed_t eTubeLed;
//	eLed_t eLeftTubeLed;
//	eLed_t eRightTubeLed;
//	eLed_t eColonLed;
//	eLed_t eAmLed;
//	eLed_t ePmLed;
	eLed_t eArrowLed_8;
	eLed_t eArrowLed_10;
	eLed_t eArrowLed_12;
	eLed_t eArrowLed_14;
	eLed_t eLed_Nbr8;
	eLed_t eLed_Nbr10;
	eLed_t eLed_Nbr12;
	eLed_t eLed_Nbr14;
	eLed_t eBrewingLed;
	eLed_t eKeepLed;
	eLed_t eWarmLed;
}sCtxLed_t;
extern sCtxLed_t sCtxLed;

typedef struct
{
	uint8_t TubeLed;
	uint8_t ArrowLed_8;
	uint8_t ArrowLed_10;
	uint8_t ArrowLed_12;
	uint8_t ArrowLed_14;
	uint8_t Led_Nbr8;
	uint8_t Led_Nbr10;
	uint8_t Led_Nbr12;
	uint8_t Led_Nbr14;
	uint8_t BrewingLed;
	uint8_t KeepLed;
	uint8_t WarmLed;
}sCtxLedDuty_t;
extern sCtxLedDuty_t sCtxLedDuty;

void LedInit();
void LedHandle();
void LedHandleForTmrInt();
bool LedResetWifiSearchTicks();
bool GetWifiSearchTicks();
void LedScan();

#endif








