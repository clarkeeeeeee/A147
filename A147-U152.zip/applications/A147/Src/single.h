#ifndef _SINGLE_H_
#define _SINGLE_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include <top.h>

typedef struct
{
	uint8_t duty;
	uint8_t period;
}sMtDrive_t;

typedef enum
{
	eSingleWorkStep_None,
	eSingleWorkStep_Init,
	eSingleWorkStep_FillHeaterWithWater,
	eSingleWorkStep_TempComp,
	eSingleWorkStep_ErrCheck,
	eSingleWorkStep_ReleaseWater,
	eSingleWorkStep_ReleaseWaterCauseSteam,
	eSingleWorkStep_DisplayOz,
	eSingleWorkStep_PreHeat,
}eSingleWorkStep_t;

extern uint16_t SingleCupFmCountsUnit;
extern uint16_t SingleCupFmCountsUnitCfgTicks;
extern uint8_t gSingleCleaningRequired;
extern uint8_t gSingleCleaningRequiredLcd;
extern bool gbForceCoolHeater;
extern eSingleWorkStep_t eSingleWorkStep;
extern bool gbForceSingleHeat;
extern uint16_t OverTempProtectCounts;
extern uint16_t SingleCoffeeReady;


typedef struct
{
	bool flag;
	uint32_t fm_bkp;
}sRestartBrew_t;
extern sRestartBrew_t sRestartBrew;

#if FM_DEBUG
extern bool gbFmDebug_SingleErrCheckNeedle;
#endif

void SingleMtDrive();
void SingleWorkHandle();
bool Single_GetHeatRelay();
bool Single_GetKeepWarm();
void ClearCoolHeaterTicks();
bool SingleGetClearWater();
void SingleSet_ClearWaterTicks();
void SingleClear_ClearWaterTicks();
bool CheckResetPreHeatTicksCauseSingleOp();
uint8_t SingleGetCupSizeDyn();


#endif








