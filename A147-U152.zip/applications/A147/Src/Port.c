#include "board.h"
#include "port.h"
#include "dev.h"


TYPEDEF_TURN_RIGHT TurnR;
TYPEDEF_TURN_DIRECTION TURN_DIR;
TYPEDEF_TURN_DIRECTION SAVE_TURN_DIR;

void Port_Init(void)
{
	GPIO_SetMode(PF, BIT3, GPIO_MODE_OUTPUT);	//RELAY
	PF3=0;
	GPIO_SetMode(PF, BIT2, GPIO_MODE_OUTPUT);	//RELAY
	PF2=0;
	
//	GPIO_SetMode(PF, BIT4, GPIO_MODE_QUASI);PF4=1;	//ZERO
//	GPIO_SetMode(PF, BIT5, GPIO_MODE_QUASI);PF5=1;
	
	#if PCB_VER>1
	GPIO_SetMode(PA, BIT11, GPIO_MODE_QUASI);	//BrewChamberMicroswitch
	#else
	GPIO_SetMode(PA, BIT10, GPIO_MODE_QUASI);	//BrewChamberMicroswitch
	#endif
	
	#if PCB_VER>1
	#if MT_IO_WRONG
	GPIO_SetMode(PB, BIT15, GPIO_MODE_OUTPUT);	//MOTOR
	PB15=0;
	#else
	#if PCB_VER>=3
	GPIO_SetMode(PB, BIT4, GPIO_MODE_OUTPUT);	//MOTOR
	PB4=0;
	#else
	GPIO_SetMode(PA, BIT10, GPIO_MODE_OUTPUT);	//MOTOR
	PA10=0;
	#endif
	#endif
	#else
	GPIO_SetMode(PA, BIT9, GPIO_MODE_OUTPUT);	//MOTOR
	PA9=0;
	#endif
	
	#if PCB_VER>1
	GPIO_SetMode(PA, BIT8, GPIO_MODE_INPUT);
	GPIO_SetMode(PA, BIT9, GPIO_MODE_INPUT);
	GPIO_EnableInt(PA, 8, GPIO_INT_FALLING);
	GPIO_EnableInt(PA, 9, GPIO_INT_FALLING);
	NVIC_EnableIRQ(GPIO_PAPBPGPH_IRQn);
	#else
	GPIO_SetMode(PF, BIT4, GPIO_MODE_INPUT);
	GPIO_SetMode(PF, BIT5, GPIO_MODE_INPUT);
	GPIO_EnableInt(PF, 4, GPIO_INT_FALLING);
	GPIO_EnableInt(PF, 5, GPIO_INT_FALLING);
	NVIC_EnableIRQ(GPIO_PCPDPEPF_IRQn);
	#endif
	
	#if PCB_VER>1
	GPIO_SetMode(PB, BIT7, GPIO_MODE_INPUT);	//HALL
	GPIO_EnableInt(PB, 7, GPIO_INT_FALLING);
    NVIC_EnableIRQ(GPIO_PAPBPGPH_IRQn);
	#else
	GPIO_SetMode(PA, BIT8, GPIO_MODE_INPUT);	//HALL
	GPIO_EnableInt(PA, 8, GPIO_INT_FALLING);
    NVIC_EnableIRQ(GPIO_PAPBPGPH_IRQn);
	#endif
	
    /* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 1024 clocks of LIRC clock */
    GPIO_SET_DEBOUNCE_TIME(GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_4);
    #if PCB_VER>1
	GPIO_ENABLE_DEBOUNCE(PB, BIT7);
	GPIO_ENABLE_DEBOUNCE(PA, BIT8);
	GPIO_ENABLE_DEBOUNCE(PA, BIT9);
	#else
	GPIO_ENABLE_DEBOUNCE(PA, BIT8);
	GPIO_ENABLE_DEBOUNCE(PF, BIT4);
	GPIO_ENABLE_DEBOUNCE(PF, BIT5);
	#endif
	
	
	//XW09A
	#if PCB_VER>=3
	GPIO_SetMode(PA, BIT10, GPIO_MODE_QUASI);
	#else
	GPIO_SetMode(PB, BIT4, GPIO_MODE_QUASI);
	#endif
	GPIO_SetMode(PB, BIT1, GPIO_MODE_QUASI);PB1=1;
	GPIO_SetMode(PB, BIT0, GPIO_MODE_QUASI);PB0=1;
	
//	GPIO_SetMode(PF, BIT1, GPIO_MODE_QUASI);PF1=1;
}



/**
 * @brief       GPIO PA/PB/PG/PH IRQ
 *
 * @param       None
 *
 * @return      None
 *
 * @details     The PA/PB/PG/PH default IRQ, declared in startup_M031Series.s.
 */
void GPABGH_IRQHandler(void)
{
    volatile uint32_t temp;
	bool valid=false;

    /* To check if PB.2 interrupt occurred */
	#if PCB_VER>1
    if(GPIO_GET_INT_FLAG(PB, BIT7))
    {
        GPIO_CLR_INT_FLAG(PB, BIT7);
//        printf("PB.7 INT occurred.\n");
		UpdateFlowmeter();
		valid=true;
    }
	if(GPIO_GET_INT_FLAG(PA, BIT8))
    {
        GPIO_CLR_INT_FLAG(PA, BIT8);
//        printf("PA.8 INT occurred.\n");
		UpdateAcZeroCounts();
		valid=true;
    }
	if(GPIO_GET_INT_FLAG(PA, BIT9))
    {
        GPIO_CLR_INT_FLAG(PA, BIT9);
//        printf("PA.9 INT occurred.\n");
		UpdateHeatZeroCounts();
		valid=true;
    }
	#else
	if(GPIO_GET_INT_FLAG(PA, BIT8))
    {
        GPIO_CLR_INT_FLAG(PA, BIT8);
        printf("Pa.8 INT occurred.\n");
		UpdateFlowmeter();
    }
	#endif
    if(!valid)
    {
        /* Un-expected interrupt. Just clear all PB interrupts */
        temp = PA->INTSRC;
        PA->INTSRC = temp;
		temp = PB->INTSRC;
        PB->INTSRC = temp;
        printf("%s Un-expected interrupts.\n",__func__);
    }
}
/**
 * @brief       GPIO PC/PD/PE/PF IRQ
 *
 * @param       None
 *
 * @return      None
 *
 * @details     The PC/PD/PE/PF default IRQ, declared in startup_M031Series.s.
 */
#if PCB_VER==1
void GPCDEF_IRQHandler(void)
{
    bool valid=false;
	volatile uint32_t temp;
    /* To check if PB.2 interrupt occurred */
    if(GPIO_GET_INT_FLAG(PF, BIT4))
    {
        GPIO_CLR_INT_FLAG(PF, BIT4);
        printf("PF.4 INT occurred.\n");
		UpdateAcZeroCounts();
		valid=true;
    }
	if(GPIO_GET_INT_FLAG(PF, BIT5))
    {
        GPIO_CLR_INT_FLAG(PF, BIT5);
        printf("PF.5 INT occurred.\n");
		UpdateHeatZeroCounts();
		valid=true;
    }
	
    if(!valid)
    {
        /* Un-expected interrupt. Just clear all PB interrupts */
        temp = PF->INTSRC;
        PF->INTSRC = temp;
        printf("%s Un-expected interrupts.\n",__func__);
    }
}
#endif
