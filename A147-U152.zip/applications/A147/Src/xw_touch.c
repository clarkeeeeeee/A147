#include "xw_touch.h"

sXwTouch_t sXwTouch={0,0,0xffff};

#define XW_TOUCH_ADDR		0X81

#define XW_TOUCH_DAT_SET		PB0=1
#define XW_TOUCH_DAT_CLR		PB0=0
#define XW_TOUCH_CLK_SET		PB1=1
#define XW_TOUCH_CLK_CLR		PB1=0
#define XW_TOUCH_DAT_IO_IN		
#define XW_TOUCH_DAT_IO_OUT
#define XW_TOUCH_DAT_IO_READ	PB0
#if PCB_VER>=3
#define XW_TOUCH_INT_VALID		(PA10==0)
#else
#define XW_TOUCH_INT_VALID		(PB4==0)
#endif
u16 XwTouchGet()
{
	return sXwTouch.KeyMsk;
}
void XwTouchHandle()
{
	static u16 msk=0;
	static u16 wait_stable=5000;
	
	static u32 wake_up=0;
	
	if(wait_stable)
	{
		wait_stable--;
		return;
	}
	
	if(XW_TOUCH_INT_VALID)
	{
		#if C_PRINT
		if(!sXwTouch.bAnyKey)
			printf("%s -> Set sXwTouch.bAnyKey\r\n",__func__);
		#endif
		sXwTouch.bAnyKey=true;
		if(sXwTouch.eXwTouchComm==eXwTouchComm_Idle)
			sXwTouch.eXwTouchComm++;
	}
	else
	{
		if(sXwTouch.bAnyKey)
		{
			sXwTouch.bAnyKey=false;
			sXwTouch.KeyMsk=0xffff;
		}
	}
	
	switch(sXwTouch.eXwTouchComm)
	{
		case eXwTouchComm_Idle:
			XW_TOUCH_DAT_SET;
			XW_TOUCH_CLK_SET;
			msk=0;
		
			if(++wake_up>=(10*1000*10))
			{
				XW_TOUCH_DAT_CLR;
				wake_up=0;
			}
		break;
		
		case eXwTouchComm_Start:
			wake_up=0;
			XW_TOUCH_DAT_CLR;
			sXwTouch.eXwTouchComm++;
		break;
		
		case eXwTouchComm_Addr1_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x80)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr2_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x40)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr3_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x20)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr4_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x10)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr5_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x08)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr6_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x04)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr7_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x02)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		case eXwTouchComm_Addr8_1:	XW_TOUCH_CLK_CLR;	if(XW_TOUCH_ADDR&0x01)	XW_TOUCH_DAT_SET;	else 	XW_TOUCH_DAT_CLR;	sXwTouch.eXwTouchComm++;break;
		
		case eXwTouchComm_Addr1_2:
		case eXwTouchComm_Addr2_2:
		case eXwTouchComm_Addr3_2:
		case eXwTouchComm_Addr4_2:
		case eXwTouchComm_Addr5_2:
		case eXwTouchComm_Addr6_2:
		case eXwTouchComm_Addr7_2:
		case eXwTouchComm_Addr8_2:
			XW_TOUCH_CLK_SET;
			sXwTouch.eXwTouchComm++;
		break;
		
		
		case eXwTouchComm_GetAck1:
			XW_TOUCH_CLK_CLR;
			XW_TOUCH_DAT_IO_IN;
			sXwTouch.eXwTouchComm++;
		break;
		case eXwTouchComm_GetAck2:
			XW_TOUCH_CLK_SET;
			if(XW_TOUCH_DAT_IO_READ)
			{
				sXwTouch.eXwTouchComm=eXwTouchComm_Idle;
				XW_TOUCH_DAT_IO_OUT;
			}
			else
				sXwTouch.eXwTouchComm++;
		break;
			
		case eXwTouchComm_Data1_1:
		case eXwTouchComm_Data2_1:
		case eXwTouchComm_Data3_1:
		case eXwTouchComm_Data4_1:
		case eXwTouchComm_Data5_1:
		case eXwTouchComm_Data6_1:
		case eXwTouchComm_Data7_1:
		case eXwTouchComm_Data8_1:
		case eXwTouchComm_Data9_1:
		case eXwTouchComm_Data10_1:
		case eXwTouchComm_Data11_1:
		case eXwTouchComm_Data12_1:
		case eXwTouchComm_Data13_1:
		case eXwTouchComm_Data14_1:
		case eXwTouchComm_Data15_1:
		case eXwTouchComm_Data16_1:	
			XW_TOUCH_CLK_CLR;
			sXwTouch.eXwTouchComm++;
		break;
		
		
		case eXwTouchComm_Data1_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data2_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data3_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data4_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data5_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data6_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data7_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data8_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data9_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data10_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data11_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data12_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data13_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data14_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data15_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		case eXwTouchComm_Data16_2:	msk<<=1;	XW_TOUCH_CLK_SET;	if(XW_TOUCH_DAT_IO_READ)	msk|=1;	sXwTouch.eXwTouchComm++;	break;
		
		case eXwTouchComm_SendNoAck:	
			XW_TOUCH_CLK_CLR;
			if(sXwTouch.bAnyKey)
				sXwTouch.KeyMsk=msk;
			XW_TOUCH_DAT_IO_OUT;
			XW_TOUCH_DAT_SET;
			sXwTouch.eXwTouchComm=eXwTouchComm_Idle;
		break;
		
		default:
		break;
	}
}


































