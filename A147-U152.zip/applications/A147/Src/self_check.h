#ifndef _SELF_CHECK_H_
#define _SELF_CHECK_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbSelfCheckRelayOn;
extern bool gbSelfCheckGetModuleInf;
extern uint8_t SelfCheckKeyCode;
extern uint8_t SelfCheckErrorCode;
extern bool gbSelfCheckComplete;
extern uint16_t SelfCheckOt;
extern bool gbSelfCheckPumpOn;
extern bool gbSelfCheckSingleRelayOn;


#define SELF_CHECK_ERROR_EC1	(1<<0)
#define SELF_CHECK_ERROR_EC2	(1<<1)
#define SELF_CHECK_ERROR_b10	(1<<2)
#define SELF_CHECK_ERROR_F01	(1<<3)
#define SELF_CHECK_ERROR_A10	(1<<4)
#define SELF_CHECK_ERROR_A11	(1<<5)
#define SELF_CHECK_ERROR_n10	(1<<6)
#define SELF_CHECK_ERROR_n11	(1<<7)
#define SELF_CHECK_ERROR_n20	(1<<8)
#define SELF_CHECK_ERROR_n21	(1<<9)

extern uint16_t gSelfCheckError;

typedef enum
{
	eSelfCheck_None,
	eSelfCheck_Display,
	eSelfCheck_FwV,
	eSelfCheck_HwV,
	eSelfCheck_CarafeCounts,
	eSelfCheck_SingleCounts,
	eSelfCheck_Communication,
	eSelfCheck_ButtonClock,
	eSelfCheck_ButtonCarafe,
	eSelfCheck_ButtonSingle,
	eSelfCheck_ButtonWifi,
	eSelfCheck_ButtonReady,
	eSelfCheck_ButtonBold,
	eSelfCheck_ButtonRegular,
//	eSelfCheck_ButtonPower,
	eSelfCheck_CarafeTest,
	eSelfCheck_SingleServeTest,
	eSelfCheck_Over,
}eSelfCheck_t;
extern eSelfCheck_t eSelfCheck;



bool SelfCheckRetStatus();
uint8_t SelfCheckRetSteps();
void SelfCheckHandle();
void SelfCheckHandleForTmrInt();
void SelfCheckStart();
void SelfCheckStop();
void SelfCheckStepsPlus();

bool WaitSlefCheck();

#endif