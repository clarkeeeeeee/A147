#ifndef _LCD_H_
#define _LCD_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

extern unsigned char LcdRam[];
extern uint16_t SingleCupSizeDynDisplay;

void LcdPortInit();
void LcdHandle();
void LcdHandleForTmrInt();


#endif



