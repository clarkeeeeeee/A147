#ifndef _XB_UART_H_
#define _XB_UART_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "top.h"

#if XB_UART

typedef enum
{
	eXbUartErrCodeAtByte11_none,
	eXbUartErrCodeAtByte11_200,
	eXbUartErrCodeAtByte11_170,
	eXbUartErrCodeAtByte11_130,
	eXbUartErrCodeAtByte11_100,
}eXbUartErrCodeAtByte11_t;

typedef enum
{
	eXbUartErrCheck_None,
	eXbUartErrCheck_Needle,
	eXbUartErrCheck_H2o,
}eXbUartErrCheck_t;

extern eXbUartErrCheck_t eXbUartErrCheck;
extern eXbUartErrCodeAtByte11_t eXbUartErrCodeAtByte11;
extern uint8_t gXbUartErrorMask_CloseLid;

void XbUartFromIsr();
void XbUartLoop();

#endif

#endif



