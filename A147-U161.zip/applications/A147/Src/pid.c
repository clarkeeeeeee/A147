#include "pid.h"




PID pid;

#if !PID_INC

void PID_Init()
{
	pid.Kp=0.5;
	pid.T=5;//PID计算周期
  	pid.Ti=1500;//3899;//积分时间
	pid.Td=50;//微分时间
	pid.C1ms=0;
	pid.Ek_1=0;
	pid.SEk=0;
	
	pid.Pout=0;
	pid.Iout=0;
	pid.Dout=0;
	
	pid.ki=pid.Kp*pid.T/pid.Ti;
	pid.kd=pid.Kp*pid.Td/pid.T;
//	pid.SEk=-15/pid.ki;
}


//void PID_Init()
//{
//	pid.Kp=1.0;
//	pid.T=10;//PID计算周期
//  	pid.Ti=1500;//积分时间
//	pid.Td=10;//微分时间
//	pid.C1ms=0;
//	pid.Ek_1=0;
//	pid.SEk=0;
//	
//	pid.Pout=0;
//	pid.Iout=0;
//	pid.Dout=0;
//}



bool PID_Calc(float dest,float now)  //pid计算
{
 	float DelEk;
	float out;
	
 	if(++pid.C1ms<(pid.T))  	//计算周期未到
		return false;
	pid.C1ms=0;
 
 	pid.Ek=(dest-now);   			//得到当前的偏差值
	if(pid.Ek<0)
		pid.Ek*=3.5;
	
	pid.Pout=pid.Kp*pid.Ek;     //比例输出
//	pid.Pout=0;
 
	#if PID_MODE>1
 	
//	pid.Iout=pid.ki*pid.SEk; 
//	if(pid.Iout>-60)
		pid.SEk+=pid.Ek;        	//历史偏差总和
 	DelEk=pid.Ek-pid.Ek_1;  	//最近两次偏差之差
 
//	if(pid.Ek>=0)
//		pid.SEk/=2;
//	else
		pid.Iout=pid.ki*pid.SEk;  		//积分输出
//	printf("...%s pid.iout=%f\r\n",__func__,pid.Iout);
	#endif

	#if PID_MODE>2
//	if(DelEk<0)
//		DelEk=0;
//  	if(pid.Ek>0 && DelEk>0)
	{
		pid.Dout=pid.kd*DelEk;    		//微分输出
		
	}
	#endif
	
 	out= pid.Pout+ pid.Iout+ pid.Dout;
  	pid.OUT=out;
	
//	if(pid.OUT<(-60))
//		pid.OUT=-60;
	
 	pid.Ek_1=pid.Ek; 			//更新偏差
	return true;
 	
}

#else
void PID_Init()
{
    pid.error = 0.0;
    pid.error_next = 0.0;
    pid.error_last = 0.0;
   
	//可调节PID 参数。使跟踪曲线慢慢接近阶跃函数200.0 // 
    pid.kp = 0.0;
    pid.ki = 0.08;
    pid.kd = 0.0;
	
	pid.C1ms=0;
	pid.T=10;
	
	pid.value=100;
}


bool PID_Calc(float dest,float now)
{
    if(++pid.C1ms<(pid.T))  	//计算周期未到
		return false;
	pid.C1ms=0;
	
	pid.error = dest - now;
     
    pid.OUT =  pid.kp*(pid.error-pid.error_next);
	pid.OUT += pid.ki*pid.error;
	pid.OUT += pid.kd*(pid.error-2*pid.error_next+pid.error_last);
	
	pid.value+=pid.OUT;
    
    pid.error_last = pid.error_next;//下一次迭代  
    pid.error_next = pid.error;
    return true; 
}
#endif














