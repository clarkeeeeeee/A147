#include "self_check.h"
#include "dev.h"
#include "led.h"

eSelfCheck_t eSelfCheck;

#define SELF_CHECK_WAIT_COUNTS		100*30
static uint16_t SelfCheckWaitCounts=SELF_CHECK_WAIT_COUNTS;

bool WaitSlefCheck()	//allow get in self check mode
{
	return (SelfCheckWaitCounts>0?true:false);
}

bool gbSelfCheckRelayOn=false;
bool gbSelfCheckComplete=false;
bool gbSelfCheckSingleRelayOn=false;
bool gbSelfCheckPumpOn=false;

uint16_t gSelfCheckError=0;

bool bSelfCheckStatus=false;
static uint32_t SelfCheckTicks=0;
static uint16_t SelfCheckSteps=0;

uint8_t SelfCheckKeyCode=0;
uint8_t SelfCheckErrorCode=0;

uint16_t SelfCheckOt=0;

bool gbSelfCheckGetModuleInf=false;

static bool bSelfCheckLock=false;

void SelfCheckStart()
{
	if(eSelfCheck==eSelfCheck_None)
	{
		eSelfCheck=eSelfCheck_Display;
		SelfCheckTicks=0;
		SelfCheckSteps=0;
	}
}
void SelfCheckStop()
{
	if(eSelfCheck)
	{
		eSelfCheck=eSelfCheck_None;
		SelfCheckTicks=0;
	}
}
bool SelfCheckRetStatus()
{
	return (eSelfCheck==eSelfCheck_None?false:true);
}
uint8_t SelfCheckRetSteps()
{
	return eSelfCheck;
}
void SelfCheckStepsPlus()
{
	if(gSelfCheckError || bSelfCheckLock)
		return;
	eSelfCheck++;
	if(eSelfCheck>eSelfCheck_Over)
		eSelfCheck=eSelfCheck_None;
	if(eSelfCheck==eSelfCheck_Over)
	{
		gbSelfCheckRelayOn=false;
		gbSelfCheckSingleRelayOn=false;
		gbSelfCheckPumpOn=false;
	}
	SelfCheckTicks=0;
	SelfCheckWaitCounts=SELF_CHECK_WAIT_COUNTS;
}
void SelfCheckHandleForTmrInt()
{
	if(SelfCheckWaitCounts && !bSelfCheckLock)
		SelfCheckWaitCounts--;
	
	if(eSelfCheck==eSelfCheck_Communication)
	{
		if(gbSelfCheckGetModuleInf)
			SelfCheckTicks++;
		else
			return;
	}
	SelfCheckTicks++;
}

#define SELF_CHECK_1S		100

uint32_t SelfCheck_Flowmeter=0;

void SelfCheckHandle()
{
	if(++SelfCheckOt>=(30*100) && !gSelfCheckError)
		eSelfCheck=eSelfCheck_None;
	
	if(eSelfCheck==eSelfCheck_None)
	{
		gbSelfCheckRelayOn=false;
		return;
	}
	
	switch(eSelfCheck)
	{
		case eSelfCheck_CarafeTest:
			if(SelfCheckTicks<SELF_CHECK_1S)
			{
				gbSelfCheckRelayOn=true;
				bSelfCheckLock=true;
			}
			else
			{
				gbSelfCheckRelayOn=false;
				bSelfCheckLock=false;
				if(gbThermostatOff)
					gSelfCheckError|=SELF_CHECK_ERROR_EC1;
				if(gbAcOff)
					gSelfCheckError|=SELF_CHECK_ERROR_EC2;
				if(gSelfCheckError&SELF_CHECK_ERROR_EC1 || gSelfCheckError&SELF_CHECK_ERROR_EC2)
					;
				else
					SelfCheckStepsPlus();
			}
		break;
		case eSelfCheck_SingleServeTest:
			if(HeatTemp==NTC_SC)
			{
				gSelfCheckError|=SELF_CHECK_ERROR_n10;
				break;
			}
			else
				gSelfCheckError&=~SELF_CHECK_ERROR_n10;
			if(HeatTemp==NTC_OC)
			{
				gSelfCheckError|=SELF_CHECK_ERROR_n11;
				break;
			}
			else
				gSelfCheckError&=~SELF_CHECK_ERROR_n11;
			
			if(WaterTemp==NTC_SC)
			{
				gSelfCheckError|=SELF_CHECK_ERROR_n20;
				break;
			}
			else
				gSelfCheckError&=~SELF_CHECK_ERROR_n20;
			if(WaterTemp==NTC_OC)
			{
				gSelfCheckError|=SELF_CHECK_ERROR_n21;
				break;
			}
			else
				gSelfCheckError&=~SELF_CHECK_ERROR_n21;
			
			if(gSelfCheckError&SELF_CHECK_ERROR_EC2)
			{
				gbSelfCheckSingleRelayOn=false;
				break;
			}
			
			if(SelfCheckTicks<SELF_CHECK_1S*4+1)		//2s relay + 2s pump
				bSelfCheckLock=true;
			else
			{
				bSelfCheckLock=false;
				if(!gbSelfCheckPumpOn)
				{
					SelfCheckStepsPlus();
					break;
				}
			}
			
			static bool b_wait_chamber_open=false;
		
			if(SelfCheckTicks<SELF_CHECK_1S*2)
			{
				gbSelfCheckSingleRelayOn=true;
//				if(SelfCheckTicks>=SELF_CHECK_1S && !gbThermostatOff)
//					gSelfCheckError|=SELF_CHECK_ERROR_EC2;
			}
			else
			{
				gbSelfCheckSingleRelayOn=false;
				
				if(!b_wait_chamber_open)
				{
					SelfCheckTicks=SELF_CHECK_1S*2;
					gbSelfCheckPumpOn=false;
					gSelfCheckError|=SELF_CHECK_ERROR_b10;
					if(!gbBrewChamberMicroswitch)
						break;
					b_wait_chamber_open=true;
				}
				
//				if(gbBrewChamberMicroswitch==false)
//				{
//					gSelfCheckError|=SELF_CHECK_ERROR_b10;
//					SelfCheckTicks=SELF_CHECK_1S*2;
//					gbSelfCheckPumpOn=false;
//				}
//				else
				{
					gSelfCheckError&=~SELF_CHECK_ERROR_b10;
					if(SelfCheckTicks<SELF_CHECK_1S*4)
					{
						if(!gbSelfCheckPumpOn)
						{
							gbSelfCheckPumpOn=true;
							SelfCheck_Flowmeter=GetFlowmeter();
							
						}
						#if C_PRINT
						printf("%s PumpCurrentAdcRes=%d\n",__func__,PumpCurrentAdcRes);
						#endif
					}
					else
					{
						if(gbSelfCheckPumpOn)
						{
							gbSelfCheckPumpOn=false;
							if(PumpCurrentAdcRes<10)
								gSelfCheckError|=SELF_CHECK_ERROR_A10;
							else if(PumpCurrentAdcRes>550)
								gSelfCheckError|=SELF_CHECK_ERROR_A11;
							else if(GetFlowmeter()-SelfCheck_Flowmeter<=3)
								gSelfCheckError|=SELF_CHECK_ERROR_F01;
						}
					}
				}
			}
		break;

			
		default:
			gbSelfCheckRelayOn=false;
			gbSelfCheckSingleRelayOn=false;
		break;
	}
}



