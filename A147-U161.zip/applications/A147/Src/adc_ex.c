#include "adc_ex.h"
#include "top.h"
#include "dev.h"
#include "adc.h"

extern uint32_t ADC_temperature;

uint16_t AdcRes=0;

#ifdef NTC_10K
const uint16_t NTC_ADC_TAB[]={
3137	,
3099	,
3061	,
3021	,
2981	,
2940	,
2899	,
2857	,
2814	,
2771	,
2727	,
2683	,
2639	,
2594	,
2549	,
2504	,
2458	,
2413	,
2367	,
2321	,
2275	,
2229	,
2184	,
2138	,
2093	,
2048	,
2003	,
1958	,
1914	,
1870	,
1826	,
1783	,
1741	,
1699	,
1657	,
1616	,
1576	,
1536	,
1497	,
1459	,
1421	,
1384	,
1347	,
1312	,
1277	,
1242	,
1209	,
1176	,
1143	,
1112	,
1081	,
1051	,
1022	,
993	,
965	,
938	,
911	,
885	,
860	,
836	,
812	,
788	,
766	,
744	,
722	,
702	,
681	,
662	,
643	,
624	,
606	,
588	,
571	,
555	,
539	,
523	,
508	,
494	,
480	,
466	,
452	,
439	,
427	,
415	,
403	,
391	,
380	,
369	,
359	,
349	,
339	,
330	,
320	,
311	,
303	,
294	,
286	,
278	,
271	,
263	,
256	,
249	,
242	,
235	,
229	,
223	,
217	,
211	,
205	,
200	,
195	,
189	,
184	,
180	,
175	,
170	,
166	,
162	,
157	,
153	,
};
#else
const uint16_t NTC_ADC_TAB[]={
3858	,
3847	,
3835	,
3823	,
3810	,
3797	,
3783	,
3769	,
3754	,
3739	,
3723	,
3706	,
3689	,
3671	,
3653	,
3634	,
3615	,
3595	,
3574	,
3553	,
3531	,
3509	,
3486	,
3462	,
3438	,
3413	,
3387	,
3361	,
3335	,
3307	,
3279	,
3251	,
3222	,
3193	,
3163	,
3132	,
3101	,
3070	,
3038	,
3005	,
2972	,
2939	,
2905	,
2871	,
2837	,
2802	,
2767	,
2732	,
2696	,
2661	,
2625	,
2588	,
2552	,
2516	,
2479	,
2443	,
2406	,
2369	,
2332	,
2296	,
2259	,
2222	,
2186	,
2149	,
2113	,
2077	,
2041	,
2005	,
1969	,
1934	,
1898	,
1863	,
1829	,
1794	,
1760	,
1727	,
1693	,
1660	,
1627	,
1595	,
1563	,
1531	,
1500	,
1469	,
1439	,
1409	,
1379	,
1349	,
1320	,
1292	,
1264	,
1236	,
1209	,
1182	,
1156	,
1131	,
1106	,
1081	,
1057	,
1033	,
1010	,
987	,
965	,
943	,
922	,
901	,
881	,
861	,
842	,
823	,
804	,
786	,
768	,
751	,
734	,
717	,
701	,
685	,
669	,
654	,
639	,
625	,
610	,
597	,
583	,
570	,
556	,
543	,
530	,
517	,
504	,
492	,
480	,
469	,
458	,
447	,
436	,
426	,
416	,
406	,
396	,
387	,
378	,
369	,
361	,
352	,
344	,
337	,
329	,
321	,
314	,
307	,
300	,
294	,
287	,
281	,
275	,
269	,
263	,
257	,
252	,
247	,
241	,
236	,
231	,
226	,
222	,
217	,
213	,
208	,
204	,
200	,
196	,
192	,
188	,
184	,
180	,
176	,
172	,
169	,
165	,
162	,
158	,
155	,
151	,
148	,
145	,
142	,
139	,
136	,
134	,
131	,
128	,
126	,
123	,
121	,
118	,
116	,
114	,
112	,
109	,
107	,
105	,
103	,
102	,
100	,
98	,
96	,
94	,
93	,
91	,
89	,
88	,
86	,
85	,
83	,
82	,
80	,
79	,
78	,
76	,
75	,
74	,
72	,
71	,
70	,
69	,
67	,
66	,
65	,

};
#endif

const uint16_t NTC50K_ADC_TAB[]={
3647	,
3626	,
3605	,
3583	,
3560	,
3537	,
3513	,
3488	,
3462	,
3436	,
3409	,
3382	,
3353	,
3324	,
3294	,
3264	,
3233	,
3201	,
3169	,
3136	,
3102	,
3068	,
3033	,
2998	,
2962	,
2925	,
2888	,
2851	,
2813	,
2775	,
2736	,
2697	,
2658	,
2619	,
2579	,
2539	,
2498	,
2458	,
2418	,
2377	,
2336	,
2296	,
2255	,
2215	,
2174	,
2134	,
2093	,
2053	,
2013	,
1974	,
1934	,
1895	,
1856	,
1818	,
1780	,
1742	,
1705	,
1668	,
1631	,
1595	,
1560	,
1524	,
1490	,
1456	,
1422	,
1389	,
1356	,
1324	,
1293	,
1262	,
1232	,
1202	,
1173	,
1144	,
1116	,
1088	,
1061	,
1035	,
1009	,
984	,
959	,
935	,
911	,
888	,
865	,
843	,
822	,
801	,
780	,
760	,
740	,
721	,
703	,
685	,
667	,
650	,
633	,
616	,
600	,
585	,
570	,
555	,
540	,
526	,
513	,
499	,
486	,
474	,
462	,
450	,
438	,
427	,
416	,
405	,
395	,
384	,
375	,
365	,
356	,
347	,
338	,
329	,
321	,
313	,
305	,
297	,
290	,
282	,
275	,
268	,
262	,
255	,
249	,
242	,
236	,
231	,
225	,
219	,
214	,
209	,
204	,
199	,
194	,
189	,
185	,
180	,
176	,
172	,
167	,
163	,
160	,
156	,
152	,
148	,
145	,
142	,
138	,
135	,
132	,
129	,
126	,
123	,
120	,
117	,
115	,
112	,
109	,
107	,
104	,
102	,
100	,
98	,
95	,
93	,
91	,
89	,
87	,
85	,
83	,
82	,
80	,
78	,
76	,
75	,
73	,
71	,
70	,
68	,
67	,
66	,
64	,
63	,
61	,
60	,
59	,
58	,
56	,
55	,
54	,
53	,
52	,
51	,
50	,
49	,
48	,
47	,
46	,
45	,
44	,
43	,
42	,
41	,
41	,
40	,
39	,
38	,
37	,
37	,
36	,
35	,
35	,
34	,
33	,
33	,
32	,
31	,
31	,
30	,
30	,
29	,

};

typedef enum
{
	ADC_CHN0=(1<<0),
	ADC_CHN1=(1<<1),
	ADC_CHN2=(1<<2),
	ADC_CHN3=(1<<3),
	ADC_CHN4=(1<<4),
	ADC_CHN5=(1<<5),
	ADC_CHN6=(1<<6),
	ADC_CHN7=(1<<7),
	ADC_CHN8=(1<<8),
	ADC_CHN9=(1<<9),
	ADC_CHN10=(1<<10),
	ADC_CHN11=(1<<11),
	ADC_CHN12=(1<<12),
	ADC_CHN13=(1<<13),
	ADC_CHN14=(1<<14),
	ADC_CHN15=(1<<15)
}eADC_CHN_DEF;

#define ADC_CVT_TOUNTS		100

volatile uint32_t g_u32AdcIntFlag;

u16 TempCvtDelay=1000;

u16 TempCelsius=0;
u16 TempFahr=0;


bool Round45(u16 ctx)
{
	if((ctx%10)>=5)
		return true;
	return false;
}

u16 CelsiusToFahr(u16 c,bool Neg)
{
	u16 buf;

	if(Neg)
	{
		buf=c;
		buf*=18;
		if(buf>=3200)
			buf=3200;
		buf=3200-buf;

		buf/=10;
		
		if(Round45(buf))
			return (buf/10+1);
		return (buf/10);
	}

	buf=c;
	buf*=18;
	buf=3200+buf;

	buf/=10;
	
	if(Round45(buf))
		return (buf/10+1);
	return (buf/10);
}

void ADC_IRQHandler(void)
{
    g_u32AdcIntFlag = 1;
    ADC_CLR_INT_FLAG(ADC, ADC_ADF_INT); /* Clear the A/D interrupt flag */
}


void AdcInit()
{
	/* Enable ADC module clock */
    CLK_EnableModuleClock(ADC_MODULE);
    /* ADC clock source is PCLK1, set divider to 1 */
    CLK_SetModuleClock(ADC_MODULE, CLK_CLKSEL2_ADCSEL_PCLK1, CLK_CLKDIV0_ADC(20));
	/* Set PB.2 - PB.3 to input mode */
	GPIO_SetMode(PB, BIT5, GPIO_MODE_INPUT);
	GPIO_SetMode(PB, BIT6, GPIO_MODE_INPUT);
	#if PCB_VER>1
	GPIO_SetMode(PB, BIT15, GPIO_MODE_INPUT);
	#else
	GPIO_SetMode(PB, BIT7, GPIO_MODE_INPUT);
	#endif
	/* Configure the PB.2 - PB.3 ADC analog input pins.  */
	#if PCB_VER>1
	SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB5MFP_Msk|SYS_GPB_MFPL_PB6MFP_Msk)) |
					(SYS_GPB_MFPL_PB5MFP_ADC0_CH5|SYS_GPB_MFPL_PB6MFP_ADC0_CH6);
	#if !MT_IO_WRONG
	SYS->GPB_MFPH = (SYS->GPB_MFPH & ~(SYS_GPB_MFPH_PB15MFP_Msk)) |
					(SYS_GPB_MFPH_PB15MFP_ADC0_CH15);
	#endif
	#else
	SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB5MFP_Msk|SYS_GPB_MFPL_PB6MFP_Msk|SYS_GPB_MFPL_PB7MFP_Msk)) |
					(SYS_GPB_MFPL_PB5MFP_ADC0_CH5|SYS_GPB_MFPL_PB6MFP_ADC0_CH6|SYS_GPB_MFPL_PB7MFP_ADC0_CH7);
	#endif
	/* Disable the PB.2 - PB.3 digital input path to avoid the leakage current. */
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT5);
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT6);
	#if PCB_VER>1
	#if !MT_IO_WRONG
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT15);
	#endif
	#else
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT7);
	#endif
	/* Enable ADC converter */
    ADC_POWER_ON(ADC);
	/* Set input mode as single-end, Single mode, and select channel 2 */
    ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT5);
	ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT6);
	#if PCB_VER>1
	#if !MT_IO_WRONG
	ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT15);
	#endif
	#else
	ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT7);
	#endif
    /* Clear the A/D interrupt flag for safe */
//    ADC_CLR_INT_FLAG(ADC, ADC_ADF_INT);

    /* Enable the sample module interrupt */
//    ADC_ENABLE_INT(ADC, ADC_ADF_INT);  /* Enable sample module A/D interrupt. */
//    NVIC_EnableIRQ(ADC_IRQn);
}

u16 AdcGetRes(u8 chn,uint8_t counts)
{
	u8 i;
	u32 sum=0;

	if(chn>15)
		return 0;

	ADC_SET_INPUT_CHANNEL(ADC,1<<chn);
	/* Set input mode as single-end, Single mode, and select channel 2 */
//    ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, (1<<chn));

	for(i=0;i<counts;i++)
	{
		/* Reset the ADC interrupt indicator and trigger sample module 0 to start A/D conversion */
        g_u32AdcIntFlag = 0;
        ADC_START_CONV(ADC);

        /* Wait ADC interrupt (g_u32AdcIntFlag will be set at IRQ_Handler function) */
//        while(g_u32AdcIntFlag == 0);
		while(!ADC_IS_DATA_VALID(ADC,chn));
        /* Disable the sample module interrupt */
        //ADC_DISABLE_INT(ADC, ADC_ADF_INT);

        /* Get the conversion result of ADC channel 2 */
		sum += ADC_GET_CONVERSION_DATA(ADC, chn);
		
		//printf("AdcGetRes chn=%d  res=%d",chn,sum/counts);
	}

	return sum/counts;
}

static int16_t GetTemp(u16 adc)
{
	u8 i=0;
	
	#if FM_DEBUG
//	if(adc>4000 || adc<10)
		return 0;
	#else
	if(adc>4000)
		return NTC_OC;
	if(adc<10)
		return NTC_SC;
	#endif
	if(adc>=NTC_ADC_TAB[0])
		return 0;
	
	for(i=0;i<sizeof(NTC_ADC_TAB)/2-1;i++)
	{
		if(adc<=NTC_ADC_TAB[i] && adc>NTC_ADC_TAB[i+1])
			break;
	}
	return i;
}
static float GetTempWithDot(u16 adc)
{
	u8 i=0;
	float diff;
	float diff2;
	float ret;
	
	if(adc>4000)
		return NTC_OC;
	if(adc<10)
		return NTC_SC;
	
	if(adc>=NTC50K_ADC_TAB[0])
		return 0;
	
	for(i=0;i<sizeof(NTC50K_ADC_TAB)/2-1;i++)
	{
		if(adc<=NTC50K_ADC_TAB[i] && adc>NTC50K_ADC_TAB[i+1])
		{
			diff=NTC50K_ADC_TAB[i]-NTC50K_ADC_TAB[i+1];
			diff2=NTC50K_ADC_TAB[i]-adc;
			ret=diff2/diff;
			ret+=i;
			break;
		}
	}
	
	return ret;
}


static void TempratureSmooth2(u16 tmp)
{
	static u8 up=0;
	static u8 down=0;
	
	static u32 up_sum=0;
	static u32 down_sum=0;
	
	static bool ntc_open=false;
	
	uint32_t u32_tmp;
	
	if(tmp==0xffff)
	{
		up=down=0;
		up_sum=down_sum=0;
		ntc_open=true;
		goto update_TempNowWithDot_Celsius;
	}
	
	if(ntc_open)
	{
		up_sum+=tmp;
		if(++up>=10)
		{
			up=0;
			up_sum/=10;
			tmp=up_sum;
			up_sum=0;
			ntc_open=false;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}
	
	if(tmp>=TempNowWithDot_Celsius)
	{
		down=0;
		down_sum=0;
		
		up_sum+=tmp;
		if(++up>=150)
		{
			up=0;
			up_sum/=150;
			tmp=up_sum;
			up_sum=0;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}
	else
	{
		up=0;
		up_sum=0;
		
		down_sum+=tmp;
		if(++down>=150)
		{
			down=0;
			down_sum/=150;
			tmp=down_sum;
			down_sum=0;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}	
	
	update_TempNowWithDot_Celsius:
	
	if(tmp==0xffff)
	{
		//printf("TempratureSmooth2 -->> off base\n");
		TempNowWithDot_Celsius=tmp;
		TempNow_Celsius=0xff;
		return;
	}
//	TempNowWithDot_Celsius=(TempNowWithDot_Celsius*2+tmp)/3;
	
	TempNowWithDot_Celsius=u32_tmp;
	
	TempNow_Celsius=TempNowWithDot_Celsius/10;
	
}



void WaterTempForXbHandle()
{
	static float f_sum=0;
	static uint16_t idx=0;
	
	f_sum+=WaterTemp;
	if(++idx>=20)
	{
		WaterTempForXb=f_sum/idx;
		f_sum=idx=0;
	}
}

#define ADC_SMOOTH_TICKS	25
#define ADC_SMOOTH_TICKS2	100
static void HeatTempratureSmooth(int16_t tmp)
{
	static u8 up=0;
	static u8 down=0;
	
	#if 0
	if(tmp==NTC_OC || tmp==NTC_SC)
	{
		up=down=0;
		goto HeatTempratureSmooth__end;
	}
	#endif
	if(tmp>=HeatTemp)
	{
		down=0;
		if(++up>=ADC_SMOOTH_TICKS2)
		{
			up=0;
			goto HeatTempratureSmooth__end;
		}
		return;
	}
	else
	{
		up=0;
		if(++down>=ADC_SMOOTH_TICKS2)
		{
			down=0;
			goto HeatTempratureSmooth__end;
		}
		return;
	}	
	HeatTempratureSmooth__end:
	if(HeatTemp!=tmp)
	{
		HeatTemp=tmp;
		#if C_PRINT
//		printf("\r\n %s update HeatTemp = %d C\n",__func__, HeatTemp);
		#endif
	}
}


#if 1
static void WaterTempratureSmooth(float tmp)
{
	float f_tmp=tmp;
	static float f_sum=0;
	static uint16_t idx=0;
	
	static uint16_t oc_sc_counts=0;
	if(f_tmp==NTC_OC || f_tmp==NTC_SC)
	{
		f_sum=idx=0;
		if(++oc_sc_counts>=500)
			goto WaterTempratureSmooth__end;
		return;
	}
	else
		oc_sc_counts=0;
	
	f_sum+=f_tmp;
	if(++idx>=ADC_SMOOTH_TICKS)
	{
		f_tmp=f_sum/ADC_SMOOTH_TICKS;
		f_sum=idx=0;
		goto WaterTempratureSmooth__end;
	}
	return;
	WaterTempratureSmooth__end:
	if(WaterTemp!=f_tmp)
	{
		WaterTemp=f_tmp;
		
		#if C_PRINT
//		printf("\r\n %s update WaterTemp = %.1f C\n",__func__, WaterTemp);
		#endif
	}
	WaterTempForXbHandle();
}
#else
static void WaterTempratureSmooth(float tmp)
{
	static u8 up=0;
	static u8 down=0;
	
	if(tmp==NTC_OC || tmp==NTC_SC)
	{
		up=down=0;
		goto WaterTempratureSmooth__end;
	}
	
	if(tmp>=WaterTemp)
	{
		down=0;
		if(++up>=ADC_SMOOTH_TICKS)
		{
			up=0;
			goto WaterTempratureSmooth__end;
		}
		return;
	}
	else
	{
		up=0;
		if(++down>=ADC_SMOOTH_TICKS)
		{
			down=0;
			goto WaterTempratureSmooth__end;
		}
		return;
	}	
	WaterTempratureSmooth__end:
	if(WaterTemp!=tmp)
	{
		WaterTemp=tmp;
		WaterTempForXbHandle();
		#if C_PRINT
//		printf("\r\n %s update WaterTemp = %.1f C\n",__func__, WaterTemp);
		#endif
	}
}
#endif

#if PCB_VER>1
#define PUMP_CURRENT_ADC_CHN	15
#else
#define PUMP_CURRENT_ADC_CHN	7
#endif
#define WATER_TEMP_ADC_CHN		6
#define HEAT_TEMP_ADC_CHN		5
#define ADC_X_COUNTS			10

static void current_adc_smooth(u16 value)
{
	static u8 ticks=0;
	static u32 sum=0;
	
	sum+=value;
	if(++ticks>=100)
	{
		ticks=0;
		PumpCurrentAdcRes=sum/100;
		PumpCurrentAdcRes>>=0;
		sum=0;
	}
}

void AdcHandle()
{
	static u8 step=0;
	
	switch(step)
	{
		case 0:
			HeatTempratureSmooth(GetTemp(AdcRes=AdcGetRes(HEAT_TEMP_ADC_CHN,ADC_X_COUNTS)));
		break;
		case 1:
		case 3:
			WaterTempratureSmooth(GetTempWithDot(AdcRes=AdcGetRes(WATER_TEMP_ADC_CHN,ADC_X_COUNTS)));
		break;
		case 2:
			#if !MT_IO_WRONG
			current_adc_smooth(AdcGetRes(PUMP_CURRENT_ADC_CHN,ADC_X_COUNTS));
			#endif
		break;
		
		default:
			break;
	}
	if(++step>3)
		step=0;
}

uint16_t KeyAdcRes=0xffff;


void AdcHandleForTmrInt()
{
	if(TempCvtDelay)
		TempCvtDelay--;
}


//adc end
















