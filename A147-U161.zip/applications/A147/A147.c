/*
 * Copyright 2018-2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

/*
    Note: this application is a sample only. It may omit functionality that would be required in a
    real device. The application's source code is structured to maximize illustrative utility, and not
    to suggest a reference design for any category of device or to provide a definitive framework for
    a device's firmware.
*/

/*
 *   ACK Host MCU sample application showing implementation of a Smart Light.
 *   The usage of the following capabilities is demonstrated:
 *    * Power - powers the light on/off.
 *    * Brightness - controls the brightness of the LED using PWM output.
 *    * Mode (Shutoff time) - shuts the light of after the specified time.
 *    * Mode (Blinking Speed) - sets the light blinking speed.
*/

#include "ack.h"
#include "ack_brightness_controller.h"
#include "ack_user_device.h"
#include "ack_logging.h"
#include "ack_mode_controller.h"
#include "ack_power_controller.h"
#include "ack_range_controller.h"
#include <inttypes.h>
#include <stdint.h>


#include "top.h"
#include "dev.h"
#include "connect.h"
#include "metrics.h"
#include "single.h"

// Component name used for logs originated from this file.
#define LOG_COMPONENT_NAME "KettleApplication"

// Forward declarations.
bool AddPowerProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightBrightnessProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightTimerProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightBlinkingProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
ACKPropertiesBits_t ResetBlinkingMode(void);
ACKPropertiesBits_t ResetShutdownTimeMode(void);

void ProcessSetSpeedModeDirective(int32_t correlationId, bool isDelta, int32_t value);
void ProcessSetTimerModeDirective(int32_t correlationId, bool isDelta, int32_t value);
ACKPropertiesBits_t SetKettleToOnIfOff(void);
void CheckShutoffTimer(void);
void CheckBlinkingMode(void);
void Hardware_TurnLightOn(void);
void Hardware_TurnLightOff(void);


//eDevStatus_t eDevStatus;
//eBrewStrength_t eBrewStrength;
//eTimeSinceBrew_t eTimeSinceBrew;
//extern bool gCleaningRequired;
bool AddDevStatusProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddBrewStrengthProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddTimeSinceBrewProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddCleaningRequiredProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddBrewSetupProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddCarafeKeepWarmProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddCoffeeFreshnessProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddPowerSaverProperty(uint32_t propertyOrdinal, unsigned propertyFlags);

// Application-specific property ordinals.
#define PROPERTY_POWER_STATE 		0
#define PROPERTY_DEV_STATUS 		1  
#define PROPERTY_BREW_STRENGTH 		2 
#define PROPERTY_TIME_SINCE_BREW 	3  
#define PROPERTY_CLEANING_REQUIRED	4
#define PROPERTY_BREW_SETUP			5
#define PROPERTY_CARAFE_KEEP_WARM	6
#define PROPERTY_CARAFE_COFFEE_FRESHNESS	7
#define PROPERTY_POWER_SAVER		8


// Maps an Alexa capability in this application to a routine used to add the capability's properties
// when an outbound event is being built.
ACKPropertyTableEntry_t ACKUser_PropertyTable[] =
{
    { PROPERTY_POWER_STATE, 		AddPowerProperty },
	{ PROPERTY_DEV_STATUS, 			AddDevStatusProperty },
	{ PROPERTY_BREW_STRENGTH, 		AddBrewStrengthProperty },
	{ PROPERTY_TIME_SINCE_BREW, 	AddTimeSinceBrewProperty },
	{ PROPERTY_CLEANING_REQUIRED, 	AddCleaningRequiredProperty },
	{ PROPERTY_BREW_SETUP, 			AddBrewSetupProperty },
	{ PROPERTY_CARAFE_KEEP_WARM, 	AddCarafeKeepWarmProperty },
	{ PROPERTY_CARAFE_COFFEE_FRESHNESS, 	AddCoffeeFreshnessProperty },
	{ PROPERTY_POWER_SAVER, 		AddPowerSaverProperty },
    { 0, NULL }
};

// All Light related properties.
static const ACKPropertiesBits_t c_lightPropertiesBits =
    ACK_PROPERTY_BIT(PROPERTY_POWER_STATE)
    | ACK_PROPERTY_BIT(PROPERTY_DEV_STATUS)
	| ACK_PROPERTY_BIT(PROPERTY_BREW_STRENGTH)
	| ACK_PROPERTY_BIT(PROPERTY_TIME_SINCE_BREW)
	| ACK_PROPERTY_BIT(PROPERTY_BREW_SETUP)
	| ACK_PROPERTY_BIT(PROPERTY_CARAFE_KEEP_WARM)
	| ACK_PROPERTY_BIT(PROPERTY_CARAFE_COFFEE_FRESHNESS)
	| ACK_PROPERTY_BIT(PROPERTY_POWER_SAVER)
	| ACK_PROPERTY_BIT(PROPERTY_CLEANING_REQUIRED);

// Mode controller instance ids.
// When multiple mode controllers are registered, each is assigned with a unique instance id.
// DO NOT CHANGE the instance ids, since they must match the device type configuration.
#define MODE_INSTANCE_DEV_STATUS 		3
#define MODE_INSTANCE_BREW_STRENGTH 	2
#define MODE_INSTANCE_TIME_SINCE_BREW 	7
#define MODE_INSTANCE_CLEANING_REQUIRED 5
#define MODE_INSTANCE_BREW_SETUP		8
#define MODE_INSTANCE_CARAFE_KEEP_WARM	9
#define MODE_INSTANCE_COFFEE_FRESHNESS	10
#define MODE_INSTANCE_POWER_SAVER		11

// Timer modes.
// Same as with the instance ids, these values must match the device type configuration.
#define TIMER_MODE_NONE 0
#define TIMER_MODE_5_MIN 1
#define TIMER_MODE_10_MIN 2
#define TIMER_MODE_60_MIN 3

// Blinking modes.
// Same as with the instance ids, these values must match the device type configuration.
#define SPEED_MODE_NONE 0
#define SPEED_MODE_LOW 1
#define SPEED_MODE_MEDIUM 2
#define SPEED_MODE_HIGH 3

#define MAXIMUM_BRIGHTNESS 100
#define MINIMUM_BRIGHTNESS 0

// Global variables.
uint32_t g_previousTick = 0;   // Previous Tick (used by timers logic).
uint32_t g_timerGap = 0;   // Milliseconds since the last loop.
uint8_t g_brightness = MAXIMUM_BRIGHTNESS; // Brightness.
uint8_t g_blinkingMode = SPEED_MODE_NONE;    // Blinking mode.
uint8_t g_timerMode = TIMER_MODE_NONE;   // Timer mode.
int32_t g_timerModeCountdown = 0;  // Timer countdown.
int32_t g_blinkingCountdown = 0; // Blinking countdown.
bool g_blinkingPower = false;     // Indicates power for blinking mode.





const char CanUseAppErr[]="Please press ready to brew button on your coffee maker";


// Called once, for one-time initialization.
void setup(void)
{
    // Initialize ACK Host MCU Implementation Core.
    ACK_Initialize();

    // Initialize the previous tick.
    g_previousTick = ACKPlatform_TickCount();
}

// Called over and over, for main processing.
void loop(void)
{
    ACK_Process();

    // Timers are checked every loop iteration.
//    CheckShutoffTimer();
//    CheckBlinkingMode();

    // In order to work with timers, we save time of the previous tick and calculate the difference.
    uint32_t newTick = ACKPlatform_TickCount();
    g_timerGap = newTick - g_previousTick;
    g_previousTick = newTick;
}


void Alexa_SendChangeReportDueToLocalControl(void)
{
    // A change report has both changed properties and "related" properties. Since we have only the one
    // property (power state), and we're here to report that it changed, there are never any "related"
    // properties.
	
	ACK_SendChangeReport(
        ack_alexa_change_report_cause_type_physical_interaction,
        c_lightPropertiesBits,
        0);
}
// We designate the device "in use" if (simulated) power is on.
bool ACKUser_IsDeviceInUse(void)
{
    return gbPower || (eDevStatus>eDevStatus_ReadyToBrew);
}

// Power Controller directive callback, turns on a small LED.
void ACKUser_OnPowerControllerDirective(int32_t correlationId, bool powerOn)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
    bool changed;
	
	#if C_PRINT
	printf("ACKUser_OnPowerControllerDirective  %d \n", powerOn);
	#endif
	
	DevAwake=DEV_AWAKE;
	
	gbMetrics__ready_to_brew_state=true;
	
	if(powerOn==false)
		goto ACKUser_OnPowerControllerDirective_if_changed;
	
	
	
	if(gDevError && eBrewSetup>=eBrewSetup_Single8)
	{
		gDevError=0;
		ACK_CompleteDirectiveWithNotSupportedInCurrentModeError(
		correlationId,
		ack_alexa_device_mode_other,
		"device has issue now");
		gbforceReport=true;
		return;
	}
	
	if(powerOn && eDevStatus!=eDevStatus_ReadyToBrew)
	{
		ACK_CompleteDirectiveWithNotSupportedInCurrentModeError(
		correlationId,
		ack_alexa_device_mode_other,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}
	

#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling power directive: %s",
        powerOn ? "ON" : "OFF");
#endif

	ACKUser_OnPowerControllerDirective_if_changed:
    changed = (0 == gbPower) != (0 == powerOn);
    if (changed)
    {
        // In case of power mode change, the logic stops blinking and the timer is stopped.
//        changedPropertiesBits |= ResetShutdownTimeMode();
//        changedPropertiesBits |= ResetBlinkingMode();
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
        if (powerOn)
        {
            DevPowerOn();
			
			sMetricPowerOnPending.debounce=300;
			sMetricPowerOnPending.method=eMetrics_StartMethod_remote;
        }
        else
        {
            DevPowerOff();
			MetricBrewEnd(eMetrics_EndMethod_alexa);
        }
    }

    // Indicate that processing the directive completed successfully,
    // including a change report if and only if the power state actually changed.
    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}




ACKPropertiesBits_t SetKettleToOnIfOff(void)
{
    if (!gbPower)
    {
//        gbRemotePowerOn=true;
		
		gbPower = true;
		DevClrTempSetTicks();
        return ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
    }

    return 0;
}



//#define PROPERTY_POWER_STATE 		0
//#define PROPERTY_DEV_STATUS 		1  
//#define PROPERTY_BREW_STRENGTH 		2 
//#define PROPERTY_TIME_SINCE_BREW 	3  
//#define PROPERTY_CLEANING_REQUIRED	4
void ProcessSetBrewStrengthModeDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

//	printf("\n\n ProcessSetBrewStrengthModeDirective  %d \n", value);
	
	DevAwake=DEV_AWAKE;
	
	const char set_berw_strength_fail[]="eDevStatus>=eDevStatus_ReadyToBrew";
	if(eDevStatus>eDevStatus_ReadyToBrew)
	{
		ACK_CompleteDirectiveWithNotSupportedInCurrentModeError(
		correlationId,
		ack_alexa_device_mode_other,
		set_berw_strength_fail);
		gbforceReport=true;
		return;
	}
	
	if (isDelta)
    {
        if ((eBrewStrength + value > eBrewStrength_Bold) || (eBrewStrength + value < eBrewStrength_Regular))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                eBrewStrength_Regular,
                eBrewStrength_Bold,
                NULL);

            return;
        }
        eBrewStrength += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BREW_STRENGTH);
    }
    else
    {
        if (eBrewStrength != value)
        {
            eBrewStrength = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BREW_STRENGTH);
        }
    }

    if (changedPropertiesBits)
    {
		if(eBrewSetup==eBrewSetup_Carafe)
			eBrewStrength_Carafe=eBrewStrength;
		if(eBrewSetup>=eBrewSetup_Single8 && eBrewSetup<=eBrewSetup_Single14)
			eBrewStrength_Single=eBrewStrength;
		CheckResetPreHeatTicksCauseSingleOp();
		DevAwake=DEV_AWAKE;
		sRestartBrew.flag=false;
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}
void ProcessSetCarafeKeepWarmModeDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	
	DevAwake=DEV_AWAKE;

	#if C_PRINT
	printf("%s value = %d \n", __func__,value);
	#endif
	
	if (isDelta)
    {
        if ((eCarafeKeepWarm + value > eCarafeKeepWarm_4h) || (eCarafeKeepWarm + value < eCarafeKeepWarm_1h))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                eCarafeKeepWarm_1h,
                eCarafeKeepWarm_4h,
                NULL);

            return;
        }
        eCarafeKeepWarm += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_CARAFE_KEEP_WARM);
    }
    else
    {
        if (eCarafeKeepWarm != value)
        {
            eCarafeKeepWarm = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_CARAFE_KEEP_WARM);
        }
    }

    if (changedPropertiesBits)
    {
		DevAwake=DEV_AWAKE;
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}
void ProcessSetPowerSaverModeDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	
	DevAwake=DEV_AWAKE;

	#if C_PRINT
	printf("%s value = %d \n", __func__,value);
	#endif
	
	if (isDelta)
    {
        if ((ePowerSaver + value > ePowerSaver_economyModeOff) || (ePowerSaver + value < ePowerSaver_economyModeOn))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                ePowerSaver_economyModeOn,
                ePowerSaver_economyModeOff,
                NULL);

            return;
        }
        ePowerSaver += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_SAVER);
    }
    else
    {
        if (ePowerSaver != value)
        {
            ePowerSaver = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_SAVER);
        }
    }

    if (changedPropertiesBits)
    {
//		CheckResetPreHeatTicksCauseSingleOp();
		DevAwake=DEV_AWAKE;
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}
// Example: Mode Controller.
// In this example two instances are supported:
//   12 to control light timer
//   13 to control light blinking mode
void ACKUser_OnModeControllerDirective(int32_t correlationId, uint32_t instance, bool isDelta, int32_t value)
{
#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Mode directive: %"PRIu32" isDelta: %u value: %d",
        instance,
        isDelta,
        value);
#endif
//#define MODE_INSTANCE_DEV_STATUS 		3
//#define MODE_INSTANCE_BREW_STRENGTH 	2
//#define MODE_INSTANCE_TIME_SINCE_BREW 	7
//#define MODE_INSTANCE_CLEANING_REQUIRED 5
    switch (instance)
    {
    case MODE_INSTANCE_POWER_SAVER:
		ProcessSetPowerSaverModeDirective(correlationId, isDelta, value);
        break;
	
	 case MODE_INSTANCE_CARAFE_KEEP_WARM:
		ProcessSetCarafeKeepWarmModeDirective(correlationId, isDelta, value);
        break;
	 
    case MODE_INSTANCE_BREW_STRENGTH:
        ProcessSetBrewStrengthModeDirective(correlationId, isDelta, value);
        break;
	
	case MODE_INSTANCE_TIME_SINCE_BREW:
        break;
	
	case MODE_INSTANCE_CLEANING_REQUIRED:
        break;
	
    default:
        ACK_DEBUG_PRINT_E("Mode controller - not supported instance id: %u", instance);
        break;
    }
}
void ACKUser_OnRangeControllerDirective(
    int32_t correlationId,
    uint32_t instance,
    bool isDelta,
    double value,
    bool isDefaultDelta)
{
#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Range directive: %"PRIu32" isDelta: %u value: %d",
        instance,
        isDelta,
        value);
#endif

//    switch (instance)
//    {
//		case RANGE_INSTANCE_TEMP_SET:
//			break;
//		case RANGE_INSTANCE_KEEP_WARM_MINUTES:
//			break;
//		
//    default:
//        ACK_DEBUG_PRINT_E("Range controller - not supported instance id: %u", instance);
//        break;
//    }
}






// State-report callback.
void ACKUser_OnReportStateDirective(int32_t correlationId)
{
		// This sends all properties demonstrated in this application.
    ACK_CompleteStateReportWithSuccess(correlationId);
}

bool AddPowerProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddPowerControllerProperty(&common, gbPower);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding power property to event", error);
        return false;
    }

    return true;
}



//#define MODE_INSTANCE_DEV_STATUS 		3
//#define MODE_INSTANCE_BREW_STRENGTH 	2
//#define MODE_INSTANCE_TIME_SINCE_BREW 	7
//#define MODE_INSTANCE_CLEANING_REQUIRED 5

//    { PROPERTY_POWER_STATE, 		AddPowerProperty },
//	{ PROPERTY_DEV_STATUS, 			AddDevStatusProperty },
//	{ PROPERTY_BREW_STRENGTH, 		AddBrewStrengthProperty },
//	{ PROPERTY_TIME_SINCE_BREW, 	AddTimeSinceBrewProperty },
//	{ PROPERTY_CLEANING_REQUIRED, 	AddCleaningRequiredProperty },
bool AddCleaningRequiredProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

	extern uint8_t CleaningRequired;
    error = ACK_AddModeControllerProperty(MODE_INSTANCE_CLEANING_REQUIRED,&common, CleaningRequired);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding CleaningRequired property to event", error);
        return false;
    }
    return true;
}
bool AddTimeSinceBrewProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_TIME_SINCE_BREW,&common, eTimeSinceBrew);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eTimeSinceBrew property to event", error);
        return false;
    }
    return true;
}
bool AddBrewStrengthProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_BREW_STRENGTH,&common, eBrewStrength);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eBrewStrength property to event", error);
        return false;
    }
    return true;
}
bool AddDevStatusProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_DEV_STATUS,&common, DevStatusFromConn);//eDevStatus);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eDevStatus property to event", error);
        return false;
    }
    return true;
}
bool AddBrewSetupProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_BREW_SETUP,&common, eBrewSetup);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eBrewSetup property to event", error);
        return false;
    }
    return true;
}
bool AddCarafeKeepWarmProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_CARAFE_KEEP_WARM,&common, eCarafeKeepWarm);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eCarafeKeepWarm property to event", error);
        return false;
    }
    return true;
}
bool AddCoffeeFreshnessProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_COFFEE_FRESHNESS,&common, eCoffeeFreshness);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding eCoffeeFreshness property to event", error);
        return false;
    }
    return true;
}
bool AddPowerSaverProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_POWER_SAVER,&common, ePowerSaver);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding ePowerSaver property to event", error);
        return false;
    }
    return true;
}
// Turns light on.
// This function is hardware specific. In the current implementation it assumes PWM pin
// with 0 as off and 255 as maximum value.
void Hardware_TurnLightOn(void)
{
    uint8_t brightness = (uint8_t)(255 * (uint16_t)g_brightness / 100);
    ACKPlatform_SetDigitalPinPWMLevel(ACK_HW_PIN_SAMPLE_APPLICATIONS_LED, brightness);
}

// Turns light off.
// This function is hardware specific. In the current implementation it assumes PWM pin
// with 0 as off and 255 as maximum value.
void Hardware_TurnLightOff(void)
{
    ACKPlatform_SetDigitalPinPWMLevel(ACK_HW_PIN_SAMPLE_APPLICATIONS_LED, 0);
}
