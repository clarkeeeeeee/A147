#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "led.h"
#include "connect.h"
#include "time.h"
#include "metrics.h"
#include "ack.h"
#include "xw_touch.h"
#include "single.h"
#include "brew.h"

#define KEY_TRIG_METRIC

sKey_t sKey={0,0,0,0,0};
bool KeyLongFlag=0;
eKey_t geKey;

#define SW1_DOWN	0//(!PF5)
#define SW2_DOWN	0//(!PC2)
#define SW3_DOWN	0//(!PC5)
#define SW4_DOWN	0//(!PC4)
#define SW5_DOWN	0//(!PF15)
#define SW6_DOWN	0//(!PC5)
#define SW7_DOWN	0//(!PC4)
#define SW8_DOWN	0//(!PF15)


#define LONG_TRIG		20
#define KEY_LONG_TH		50
#define KEY_DEBOUNCE	1

uint8_t SetTicks=0;

bool gbKeyUgsEn=false;
bool gbKeyFrsEn=false;
bool gbKeyFrsDown=false;
bool gbKeyUgsDown=false;

#define KEY_CODE_NONE		0

#if PCB_VER>=3
#define KEY_CODE_IO			1
#define KEY_CODE_WIFI		128
#define KEY_CODE_TIME		4
#define KEY_CODE_READY		64
#define KEY_CODE_CARAFE		16
#define KEY_CODE_SINGLE		32
#define KEY_CODE_REGULAR	2
#define KEY_CODE_BOLD		8
#else
#define KEY_CODE_IO			1
#define KEY_CODE_WIFI		2
#define KEY_CODE_TIME		4
#define KEY_CODE_READY		8
#define KEY_CODE_CARAFE		16
#define KEY_CODE_SINGLE		32
#define KEY_CODE_REGULAR	64
#define KEY_CODE_BOLD		128
#endif
uint8_t gKeyStuck=0;

static u8 GetKeyTmp()
{
	u8 key_tmp=0;
	u16 msk;
	
	msk=XwTouchGet();
	msk^=0xffff;
	
	if(msk&(1<<5))
		key_tmp+=16;
	if(msk&(1<<6))
		key_tmp+=4;
	if(msk&(1<<7))
		key_tmp+=1;
	if(msk&(1<<8))
		key_tmp+=2;
	if(msk&(1<<9))
		key_tmp+=8;
	if(msk&(1<<10))
		key_tmp+=128;
	if(msk&(1<<11))
		key_tmp+=64;
	if(msk&(1<<12))
		key_tmp+=32;
	
	return key_tmp;
}
void KeyInit()
{
	uint8_t key_num=0; 
	
//	key_num=GetKeyTmp();
	
	if(key_num)
	{
		if(key_num==KEY_CODE_TIME)
			gKeyStuck=1;
		else if(key_num==KEY_CODE_READY)
			gKeyStuck=2;
		else if(key_num==KEY_CODE_WIFI)
			gKeyStuck=3;
		else if(key_num==KEY_CODE_IO)
			gKeyStuck=5;
		else 
			gKeyStuck=8;
//		if(sKey.key_cnts==KEY_DEBOUNCE)
//			gbMetrics__ERR_stuck_button=true;
	}
}
static void key_scan()
{
	uint8_t tmp=0;
	
	tmp=GetKeyTmp();
	
	if(tmp)
	{
		sKey.key_now=tmp;
		
		if(sKey.key_now!=sKey.key_pre)
		{
			sKey.key_cnts=1;
			sKey.key_pre=sKey.key_now;
			#if C_PRINT
			printf("\r\n %s -> sKey.key_now=%d\r\n",__func__,sKey.key_now);
			#endif
		}
		else
		{
			sKey.key_cnts++;
		}
	}
	else
	{
		#if C_PRINT
		if(sKey.key_now)
			printf("\r\n %s -> Release Key\r\n",__func__);
		#endif
		sKey.key_now=0;
	}
	
	if(sKey.key_cnts>=KEY_DEBOUNCE)
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_IO:
				geKey=eKey_IO;
			break;
			case KEY_CODE_TIME:
				geKey=eKey_TIME;
			break;
			case KEY_CODE_WIFI:
				geKey=eKey_WIFI;
			break;
			case KEY_CODE_READY:
				geKey=eKey_READY;
			break;
			
			case KEY_CODE_CARAFE:
				geKey=eKey_CARAFE;
			break;
			case KEY_CODE_SINGLE:
				geKey=eKey_SINGLE;
			break;
			case KEY_CODE_REGULAR:
				geKey=eKey_REGULAR;
			break;
			case KEY_CODE_BOLD:
				geKey=eKey_BOLD;
			break;
			
			default:
				geKey=eKey_Null;
			break;
		}
	}
}

bool gbUgsWait=false;
int32_t gUgsWaitCounts=0;
int16_t gWifiLed_NoWifiWarnTicks=-1;
static uint16_t frs_led_delay_on=0;

#define SINGLE_CUP_FM_COUNTS_UNIT_CFG_TICKS		500

void KeyHandle()
{
	key_scan();
	
	if(sKey.key_now != KEY_CODE_WIFI)
	{
		gbKeyFrsDown=false;
		gbKeyUgsDown=false;
		if(!frs_led_delay_on)
			gbResetWiFiCredentials=false;
	}
	if(frs_led_delay_on)
		frs_led_delay_on--;
	
	if(!DevAwake)
	{
		if(sKey.key_now)
		{
			DevAwake=DEV_AWAKE;
			sKey.key_lock=1;
		}
		return;
	}
	
	if(sKey.key_now)
	{
		DevAwake=DEV_AWAKE;
		if(SingleCupFmCountsUnitCfgTicks)
			SingleCupFmCountsUnitCfgTicks=SINGLE_CUP_FM_COUNTS_UNIT_CFG_TICKS;
		
		if(eSelfCheck>eSelfCheck_None)
			SelfCheckOt=0;
	}
	
	if(gKeyStuck)
	{
		if(sKey.key_now)
			return;
		gKeyStuck=0;
	}

Key_SelfCheck:	
	if(eSelfCheck)
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_NONE:
				if(!sKey.key_lock)
				{
					
				}
				sKey.key_cnts=0;
				sKey.key_lock=0;
				sKey.key_pre=0;
			break;
				
			case KEY_CODE_IO:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						if (!(eSelfCheck>=eSelfCheck_ButtonClock && eSelfCheck<=eSelfCheck_ButtonRegular) && eSelfCheck!=eSelfCheck_Communication)
							SelfCheckStepsPlus();
						sKey.key_lock=1;
					}
				}
			break;
			
			default:
				if(!sKey.key_lock && (eSelfCheck==eSelfCheck_Display || eSelfCheck==eSelfCheck_CarafeCounts || eSelfCheck==eSelfCheck_SingleCounts))
					SelfCheckStepsPlus();
				sKey.key_lock=1;
			break;
		}
		return;
	}

Key_Handle:	
	switch(sKey.key_now)
	{
		case KEY_CODE_NONE:
			gbForceCoolHeater=false;
			if(!sKey.key_lock && sKey.key_cnts>=KEY_DEBOUNCE)
			{
				if(sKey.key_pre==KEY_CODE_IO)
				{
					if(gbPower)
					{
						DevPowerOff();
						MetricBrewEnd(eMetrics_EndMethod_manual);
					}
					else
					{
						if(eBrewSetup<eBrewSetup_Single8 || !(gDevError&(DEV_ERROR_CLOSE_LID|DEV_ERROR_OVER_TEMP)))
						{
							if(gDevError)
							{
								gDevError=0;
//								goto NoAnyKey;
							}
							
							if(SingleCounts>=SINGLE_COUNTS_CLEAN && (SingleCounts%SINGLE_COUNTS_CLEAN)>=1)	//eg 101->102
								gSingleCleaningRequired=CLEANING_REQUIRED_NO;
							gSingleCleaningRequiredLcd=CLEANING_REQUIRED_NO;
							
							DevPowerOn();
							if(gCleaningRequired==CLEANING_REQUIRED_YES)
								gbPending_ToClear_gCleaningRequired=true;
							
							sMetricPowerOnPending.debounce=300;
							sMetricPowerOnPending.method=eMetrics_StartMethod_manual;
						}
						
					}
				}
				else if(sKey.key_pre==KEY_CODE_WIFI)
				{
					if(GetWifiSearchTicks())
					{
						LedResetWifiSearchTicks();
						goto NoAnyKey;
					}
					
					if(Conn_ModuleRegistered())
					{
					}
				}
				else if(sKey.key_pre==KEY_CODE_TIME)
				{
					if(TimeGetCfg()) 
						goto NoAnyKey;
					gbTimeShow=!gbTimeShow;
					sTime.invalid_ticks=0;
				}
				else if(sKey.key_pre==KEY_CODE_READY)
				{
					gDevError=0;
					if(SingleGetClearWater() || gbForceSingleHeat)
						goto NoAnyKey;
					if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
					{
						gWifiLed_NoWifiWarnTicks=60;
						goto NoAnyKey;
					}
					if(eDevStatus<eDevStatus_ReadyToBrew)
					{
						eDevStatus=eDevStatus_ReadyToBrew;
					}
					else if(eDevStatus==eDevStatus_ReadyToBrew)
					{
						eDevStatus=eDevStatus_NotReadyToBrew;
					}
					#if C_PRINT
					printf("KEY_CODE_READY   eDevStatus=%d",eDevStatus);
					#endif
				}
				else if(sKey.key_pre==KEY_CODE_SINGLE)
				{
					if(gDevError)
						goto NoAnyKey;
					if(eDevStatus>=eDevStatus_ReadyToBrew)
					{
						goto NoAnyKey;
					}
					if(SingleGetClearWater() || gbForceSingleHeat)
					{
						sKey.key_lock=1;
						goto NoAnyKey;
					}
					if(eBrewSetup<eBrewSetup_Single8)
					{
						if(eBrewSetupBkp>=eBrewSetup_Single8)
							eBrewSetup=eBrewSetupBkp;
						else
							eBrewSetup=eBrewSetup_Single8;
						goto KEY_CODE_SINGLE__end;
					}
					if(eBrewSetup<eBrewSetup_Single14)
						eBrewSetup++;
					else
						eBrewSetup=eBrewSetup_Single8;
					eBrewSetupBkp=eBrewSetup;
					
					KEY_CODE_SINGLE__end:
					CheckResetPreHeatTicksCauseSingleOp();
					sRestartBrew.flag=false;
					SingleCoffeeReady=0;
					if(gbPower)
					{
						DevPowerOff();
						MetricBrewEnd(eMetrics_EndMethod_manual);
					}
					eBrewStrength=eBrewStrength_Single;
				}
			}
			
NoAnyKey:
			sKey.key_cnts=0;
			sKey.key_lock=0;
			sKey.key_pre=0;
		break;
			
		case KEY_CODE_IO:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(SingleGetClearWater() || gbForceSingleHeat)
					{
						sKey.key_lock=1;
						SingleClear_ClearWaterTicks();
						break;
					}
					if(sKey.key_cnts>=300 && !gbPower && eBrewSetup>=eBrewSetup_Single8)
					{
						sKey.key_lock=1;
						if(!gbBrewChamberMicroswitch)
						{
							gDevError|=DEV_ERROR_CLOSE_LID;
							break;
						}
						SingleSet_ClearWaterTicks();
						if(eDevStatus>=eDevStatus_ReadyToBrew)
							eDevStatus=eDevStatus_NotReadyToBrew;
						break;
					}
					if(sKey.key_cnts>=2000)
					{
//						SmgFirmwareVersionDispTicksReload();
						sKey.key_lock=1;
					}
				}
			}
		break;
			
		case KEY_CODE_TIME:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(TimeGetCfg()) 
					{
						if(sKey.key_cnts==KEY_DEBOUNCE || (sKey.key_cnts>=KEY_LONG_TH && ((sKey.key_cnts-KEY_LONG_TH)%LONG_TRIG)==0))
							TimeUpdateCauseKey();
//						sKey.key_lock=1;
						break;
					}
					
					if(sKey.key_cnts>=200 && ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
					{
						TimeSetCfg();
						sKey.key_lock=1;
					}
				}
			}
		break;
			
		case KEY_CODE_WIFI:
			if(sKey.key_cnts>=KEY_DEBOUNCE)
				if(gbWifiLost)
					LedResetWifiSearchTicks();
				
			
			LedResetWifiSearchTicks();
				
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
//					if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_REGISTERED || ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
					{
						if(sKey.key_cnts>=200)
						{
							gUgsWaitCounts=1000;
							Conn_StartUgs();
							gbKeyUgsDown=true;
							gbKeyUgsEn=true;
							sKey.key_lock=1;
							#if C_PRINT
							printf("\n\n ...............Conn_StartUgs \n");
							#endif
						}
					}
//					else
//						sKey.key_lock=1;
				}
			}
			else //if(gbResetWiFiCredentials)
			{
				if(sKey.key_cnts>=1000)
					gbResetWiFiCredentials=true;
				if(sKey.key_cnts>=1200)
				{
					frs_led_delay_on=500;
					if(sKey.key_cnts==1200)
					{
						Conn_StartFrs();
						gbKeyFrsEn=true;
						gbKeyFrsDown=true;
						gbKeyUgsEn=gbKeyUgsDown=false;
						#if C_PRINT
						printf("\n\n ...............Conn_StartFrs \n");
						#endif
					}
				}
			}
		break;
			
		case KEY_CODE_READY:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_LONG_TH)
				{
//					gbForceCoolHeater=true;
					break;
				}
			}
		break;
			
		case KEY_CODE_REGULAR:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(SingleGetClearWater() || gbForceSingleHeat)
					{
						sKey.key_lock=1;
						break;
					}
					if(SingleCupFmCountsUnitCfgTicks)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE || (sKey.key_cnts>=KEY_LONG_TH && ((sKey.key_cnts-KEY_LONG_TH)%LONG_TRIG)==0))
							if(SingleCupFmCountsUnit<999)
								SingleCupFmCountsUnit++;
						break;
					}
					if(eDevStatus>eDevStatus_ReadyToBrew || (eBrewSetup>=eBrewSetup_Single8 && gDevError))
					{
						sKey.key_lock=1;
						break;
					}
					sRestartBrew.flag=false;
					eBrewStrength=eBrewStrength_Regular;
					if(eBrewSetup==eBrewSetup_Carafe)
						eBrewStrength_Carafe=eBrewStrength;
					if(eBrewSetup>=eBrewSetup_Single8 && eBrewSetup<=eBrewSetup_Single14)
						eBrewStrength_Single=eBrewStrength;
					CheckResetPreHeatTicksCauseSingleOp();
					sKey.key_lock=1;
					break;
				}
			}
		break;
		case KEY_CODE_BOLD:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(SingleGetClearWater() || gbForceSingleHeat)
					{
						sKey.key_lock=1;
						break;
					}
					if(SingleCupFmCountsUnitCfgTicks)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE || (sKey.key_cnts>=KEY_LONG_TH && ((sKey.key_cnts-KEY_LONG_TH)%LONG_TRIG)==0))
							if(SingleCupFmCountsUnit>1)
								SingleCupFmCountsUnit--;
						break;
					}
					if(eDevStatus>eDevStatus_ReadyToBrew || (eBrewSetup>=eBrewSetup_Single8 && gDevError))
					{
						sKey.key_lock=1;
						break;
					}
					sRestartBrew.flag=false;
					eBrewStrength=eBrewStrength_Bold;
					if(eBrewSetup==eBrewSetup_Carafe)
						eBrewStrength_Carafe=eBrewStrength;
					if(eBrewSetup>=eBrewSetup_Single8 && eBrewSetup<=eBrewSetup_Single14)
						eBrewStrength_Single=eBrewStrength;
					CheckResetPreHeatTicksCauseSingleOp();
					sKey.key_lock=1;
					break;
				}
			}
		break;
		case KEY_CODE_CARAFE:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					gDevError=0;
					if(eDevStatus>=eDevStatus_ReadyToBrew)
					{
						break;
					}
					if(SingleGetClearWater() || gbForceSingleHeat)
					{
						sKey.key_lock=1;
						break;
					}
					if(eBrewSetup!=eBrewSetup_Carafe)
					{
						eBrewSetup=eBrewSetup_Carafe;
						eBrewStrength=eBrewStrength_Carafe;
						sRestartBrew.flag=false;
						if(gbPower)
						{
							DevPowerOff();
							MetricBrewEnd(eMetrics_EndMethod_manual);
						}
					}
					sKey.key_lock=1;
					break;
				}
			}
		break;
		case KEY_CODE_SINGLE:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=300 && eDevStatus<eDevStatus_Brewing && !gbForceSingleHeat)
				{
					//SingleCupFmCountsUnitCfgTicks=SINGLE_CUP_FM_COUNTS_UNIT_CFG_TICKS;
					sKey.key_lock=1;
				}
			}
		break;	
			
		case KEY_CODE_SINGLE+KEY_CODE_READY:
			if(!sKey.key_lock)
			{
				if(gbForceSingleHeat)
				{
					gbForceSingleHeat=false;
					sKey.key_lock=1;
					break;
				}
				if(sKey.key_cnts>=300 && eDevStatus<eDevStatus_Brewing)
				{
					gbForceSingleHeat=1;
					sKey.key_lock=1;
				}
			}
		break;	
		
		#if(0)	
		case KEY_CODE_PLUS:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					#ifdef KEY_UPDATE_TEMP_EN
					if(TempNow_Celsius<100)
						TempNow_Celsius+=1;
					TempNow_Fahrenheit=T_DegConvFromCToF(TempNow_Celsius);
					sKey.key_lock=1;
					#endif
					
					
					if(!DevGetTempSetStatus())
						break;
					DevReloadTempSetTicks();
					
					if(TempUnit==2)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE)
							DevTempSet_CelsiusPlus(eKeyStatus_Down);
						else if(sKey.key_cnts>=1000)
							DevTempSet_CelsiusPlus(eKeyStatus_Long);
						break;
					}
					
					if(sKey.key_cnts==KEY_DEBOUNCE)
						DevTempSet_FahrenheitPlus(eKeyStatus_Down);
					else if(sKey.key_cnts>=1000)
						DevTempSet_FahrenheitPlus(eKeyStatus_Long);
				}
			}
		break;
			
		case KEY_CODE_MINUS:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					#ifdef KEY_UPDATE_TEMP_EN
					if(TempNow_Celsius)
						TempNow_Celsius--;
					TempNow_Fahrenheit=T_DegConvFromCToF(TempNow_Celsius);
					sKey.key_lock=1;
					#endif
					
					if(!DevGetTempSetStatus())
						break;
					DevReloadTempSetTicks();
					
					if(TempUnit==2)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE)
							DevTempSet_CelsiusMinus(eKeyStatus_Down);
						else if(sKey.key_cnts>=1000)
							DevTempSet_CelsiusMinus(eKeyStatus_Long);
						break;
					}
					
					if(sKey.key_cnts==KEY_DEBOUNCE)
						DevTempSet_FahrenheitMinus(eKeyStatus_Down);
					else if(sKey.key_cnts>=1000)
						DevTempSet_FahrenheitMinus(eKeyStatus_Long);
				}
			}
		break;
		#endif	
		case KEY_CODE_TIME+KEY_CODE_READY:
//			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(WaitSlefCheck())
					{
						if(sKey.key_cnts==300)
						{
							SelfCheckStart();
							sKey.key_lock=1;
						}
						break;
					}
				}
			}
		break;
		
		default:
			if(sKey.key_now)
				sKey.key_lock=1;
			
			if(sKey.key_cnts==1500)
			{
				gbMetrics__ERR_stuck_button=true;
				#if C_PRINT
				printf("\r\n %s -> SET gbMetrics__ERR_stuck_button key_now=%d\r\n",__func__,sKey.key_now);
				#endif
			}
		break;
	}
}



