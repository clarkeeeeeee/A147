#include "metrics.h"
#include "ack_metrics.h"
#include "ack.h"
#include "dev.h"
#include "time.h"
#include "brew.h"

#define METRICS_BUSY		100
uint16_t MetricsBusy=METRICS_BUSY;


void Metrics_ReloadMetricsBusy(uint8_t multi)
{
	MetricsBusy=METRICS_BUSY*multi;
}

extern ACKLifecycleState_t ACK_LifecycleState;

sMetricsRtc_t sMetricsRtc;


uint16_t Metrics__PreSetBkp;
uint16_t Metrics__PreSetDelayReport=0;











const char kettle_cycle_count[]="kettle_cycle_count";

const char kettle_start_method[]="kettle_start_method";
const char manual[]="manual";
const char remote[]="remote";


const char kettle_preset[]="kettle_preset";

bool gbMetrics__kettle_temp_units=false;
const char kettle_temp_units[]="kettle_temp_units";
const char kettle_temp_units_C[]="C";
const char kettle_temp_units_F[]="F";


bool gbMetrics__kettle_target_temp=false;
uint16_t Metrics__TempSet_FahrenheitBkp;
uint16_t Metrics__TempSet_FahrenheitDelayReport=0;
const char kettle_target_temp[]="kettle_target_temp";

bool Metrics__gbHeatingBkp=false;
const char kettle_start_temp[]="kettle_start_temp";
const char kettle_end_temp[]="kettle_end_temp";

bool Metrics__gbKeepWarmBkp=false;
const char kettle_KW_program[]="kettle_KW_program";







uint32_t Metrics__Kettle_heater_life=0;

bool gbMetrics__Kettle_heater_life=false;

const char Kettle_heater_life[]="Kettle_heater_life";

uint32_t Metrics__carafe_relay_cycle_counts=0;
bool gbMetrics__carafe_relay_cycle_counts=false;
const char carafe_relay_cycle_counts[]="relay_cycle_count_carafe";

uint32_t Metrics__single_relay_cycle_counts=0;
bool gbMetrics__single_relay_cycle_counts=false;
const char single_relay_cycle_counts[]="relay_cycle_count_single";

const char end_method_manual[]="manual";
const char end_method_ASO[]="ASO";
const char end_method_remote[]="remote";
const char end_method_Error[]="error";


sMetricPowerOnPending_t sMetricPowerOnPending={0,-2};
static void check_power_on_metric()
{
	if(sMetricPowerOnPending.debounce!=0)
		return;
	
	Metrics_BrewCycleCountAdd();
	sMetricPowerOnPending.debounce=-1;
	
	
	gbMetrics__brew_start_method=true;
	Metrics__start_method=sMetricPowerOnPending.method;
	gbMetrics__brew_mode=true;
	gbMetrics__brew_setup=true;
	gbMetrics__brew_start_end=true;
	if(eBrewSetup<eBrewSetup_Single8)
		gbMetrics__keep_warm_setting_hr=true;
	if(eBrewSetup>=eBrewSetup_Single8)
	{
		gbMetrics__brew_heater_preheat_min=true;
		gbMetrics__brew_economy_mode=true;
	}
}

void MetricBrewEnd(eMetrics_EndMethod_t method)
{
	if(sMetricPowerOnPending.debounce==-1)
	{
		gbMetrics__brew_start_end=true;
		Metrics_SetEndMethod(method);
		Metrics_ReloadMetricsBusy(2);
	}
	sMetricPowerOnPending.debounce=-2;
}



//brew_end_method
const char brew_end_method[]="brew_end_method";
bool gbMetrics__brew_end_method=false;
eMetrics_EndMethod_t eMetrics_EndMethod=eMetrics_EndMethod_manual;
void Metrics_SetEndMethod(eMetrics_EndMethod_t method)
{
	eMetrics_EndMethod=method;
	gbMetrics__brew_end_method=true;
}
static bool Metrics_brew_end_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_end_method)
	{
		gbMetrics__brew_end_method=false;
		
		switch(eMetrics_EndMethod)
		{
			case eMetrics_EndMethod_manual:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_manual);
			break;
			case eMetrics_EndMethod_ASO:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_ASO);
			break;
			case eMetrics_EndMethod_alexa:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_remote);
			break;
			case eMetrics_EndMethod_Error:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_Error);
			break;
			
			default:
				break;
		}
		
		#if C_PRINT
		printf("Metric....brew_end_method:[%d]\n",eMetrics_EndMethod);
		#endif
		return true;
	}
	return false;
}
//

static void Kettle_heater_life_handle()
{
	static uint32_t ticks=0;
	
	if(gbRelay)
	{
		if(++ticks>=(1000*60))
		{
			ticks=0;
			Metrics__Kettle_heater_life+=60;
			if(Metrics__Kettle_heater_life>5000000)
				Metrics__Kettle_heater_life=5000000;
		}
	}
}
static void relay_cycle_handle()
{
	static bool status=false;
	static bool status2=false;
	
	if(gbRelay)
	{
		if(!status)
		{
			status=true;
			Metrics__carafe_relay_cycle_counts++;
			if(Metrics__carafe_relay_cycle_counts>200000)
				Metrics__carafe_relay_cycle_counts=200000;
			gbMetrics__carafe_relay_cycle_counts=true;
		}
	}
	else
		status=false;
	
	if(gbDevSingleHeatRelay)
	{
		if(!status2)
		{
			status2=true;
			Metrics__single_relay_cycle_counts++;
			if(Metrics__single_relay_cycle_counts>200000)
				Metrics__single_relay_cycle_counts=200000;
			gbMetrics__single_relay_cycle_counts=true;
		}
	}
	else
		status2=false;
}



//keep_warm_duration
const char keep_warm_duration[]="keep_warm_duration";
bool gbMetrics__KW_duration=false;
uint16_t Metrics__KW_duration=0;

static void KW_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	

	if(eBrewSetup!=eBrewSetup_Carafe)
		return;
	
//	if(eDevStatus==eDevStatus_KeepWarm || eDevStatus==eDevStatus_CoffeeReady)	
	if(eDevStatus>=eDevStatus_Brewing)
	{
		on=true;
		ticks++;
		return;
	}
	if(on)
	{
		ticks/=100;
		if(ticks>14400)
			ticks=14400;
		if(ticks>AUTO_POWER_OFF_DELAY_SECONDS)
			ticks=AUTO_POWER_OFF_DELAY_SECONDS;
		Metrics__KW_duration=ticks;
		ticks=0;
		on=false;
		gbMetrics__KW_duration=true;
	}
}
static bool Metrics_KW_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__KW_duration)
	{
		gbMetrics__KW_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(keep_warm_duration,Metrics__KW_duration);
		#if C_PRINT
		printf("Metric....keep_warm_duration:[%d]\n",Metrics__KW_duration);
		#endif
		return true;
	}
	return false;
}


//brew_duration
const char brew_duration[]="brew_duration";
bool gbMetrics__brew_duration=false;
uint32_t Metrics__brew_duration=0;

static void brew_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	
	if(eDevStatus==eDevStatus_Brewing && sMetricPowerOnPending.debounce<0)
	{
		on=true;
		ticks++;
	}
	else if(on)
	{
		ticks/=100;
		if(ticks>1200)
			ticks=1200;
		Metrics__brew_duration=ticks;
		ticks=0;
		on=false;
		gbMetrics__brew_duration=true;
	}
}
static bool Metrics_brew_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_duration)
	{
		gbMetrics__brew_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(brew_duration,Metrics__brew_duration);
		#if C_PRINT
		printf("Metric....brew_duration:[%d]\n",Metrics__brew_duration);
		#endif
		return true;
	}
	return false;
}
//


//ready_to_brew_state
bool gbMetrics__ready_to_brew_state=false;
const char ready_to_brew_state[]="ready_to_brew_state";
const char ready_to_brew_state1[]="TRUE";
const char ready_to_brew_state0[]="FALSE";
static bool Metrics_ready_to_brew_state()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__ready_to_brew_state)
	{
		gbMetrics__ready_to_brew_state=false;
		
		if(eDevStatus==eDevStatus_ReadyToBrew)
			ACK_SendUsageReportMetricWithStringValue(ready_to_brew_state,ready_to_brew_state1);
		else
			ACK_SendUsageReportMetricWithStringValue(ready_to_brew_state,ready_to_brew_state0);
		#if C_PRINT
		printf("Metric....ready_to_brew_state\n");
		#endif
		return true;
	}
	return false;
}


//


//brew_start
bool gbMetrics__brew_start_end=false;
const char brew_start[]="brew_start_time";
const char brew_end[]="brew_end_time";

static bool Metrics_brew_start_end(bool start)
{
	uint8_t hh,mm,ss;
	float time=-1;
	char time_string[6];
	bool time_valid=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(sTime.valid)
	{
		hh=sTime.hh;
		if(!sTime.am)
			if(hh<12)
				hh+=12;
		if(hh>=24)
			hh=0;
		mm=sTime.mm;
		ss=sTime.ss;
		time=hh*10000+mm*100+ss;
		
		time_string[0]=hh/10+'0';
		time_string[1]=hh%10+'0';
		time_string[2]=':';
		time_string[3]=mm/10+'0';
		time_string[4]=mm%10+'0';
		time_string[5]=0;
		time_valid=true;
	}
	
	if(eDevStatus==eDevStatus_Brewing && !start)
		return false;
	if(!(eDevStatus==eDevStatus_Brewing) && start)
		return false;
	
	if(gbMetrics__brew_start_end)
	{
		gbMetrics__brew_start_end=false;
		
		if(!time_valid)
			return true;
		
		if(eDevStatus==eDevStatus_Brewing && start)
		{
			ACK_SendUsageReportMetricWithStringValue(brew_start,time_string);
			#if C_PRINT
			printf("Metric....%s %s \n",brew_start,time_string);
			#endif
		}
		if(!(eDevStatus==eDevStatus_Brewing) && !start)
		{
			ACK_SendUsageReportMetricWithStringValue(brew_end,time_string);
			#if C_PRINT
			printf("Metric....%s %s \n",brew_end,time_string);
			#endif
		}
		
		return true;
	}
	return false;
}


//


//brew_count
static bool b_carafe_brew_count_send=false;
static bool b_single_brew_count_send=false;
const char carafe_brew_count[]="brew_count_carafe";
const char single_brew_count[]="brew_count_single";
void Metrics_BrewCycleCountAdd()
{
	if(eBrewSetup<eBrewSetup_Single8)
	{
		if(CarafeCounts<METRICS_KETTLE_CYCLE_COUNT_MAX)
		{
			CarafeCounts++;
			b_carafe_brew_count_send=true;
		}
	}
	else if(SingleCounts<METRICS_KETTLE_CYCLE_COUNT_MAX)
	{
		SingleCounts++;
		b_single_brew_count_send=true;
	}
}
static bool Metrics_cycle_count()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA || gbPower)
		return false;
	
	if(b_carafe_brew_count_send)
	{
		b_carafe_brew_count_send=false;
		ACK_SendUsageReportMetricWithNumericValue(carafe_brew_count,CarafeCounts);
		#if C_PRINT
		printf("Metric....carafe_brew_count:[%d]\n",CarafeCounts);
		#endif
		return true;
	}
	if(b_single_brew_count_send)
	{
		b_single_brew_count_send=false;
		ACK_SendUsageReportMetricWithNumericValue(single_brew_count,SingleCounts);
		#if C_PRINT
		printf("Metric....single_brew_count:[%d]\n",SingleCounts);
		#endif
		return true;
	}
	return false;
}
//

//brew_start_method
const char brew_start_method[]="brew_start_method";
bool gbMetrics__brew_start_method=false;
eMetrics_StartMethod_t Metrics__start_method;
static bool Metrics_brew_start_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_start_method)
	{
		gbMetrics__brew_start_method=false;
		
		if(Metrics__start_method==eMetrics_StartMethod_manual)
			ACK_SendUsageReportMetricWithStringValue(brew_start_method,manual);
		else
			ACK_SendUsageReportMetricWithStringValue(brew_start_method,remote);
		#if C_PRINT
		printf("Metric....brew_start_method:[%d]\n",Metrics__start_method);
		#endif
		return true;
	}
	return false;
}
//

//brew_mode
const char brew_mode[]="brew_mode";
const char regular[]="regular";
const char bold[]="bold";
bool gbMetrics__brew_mode=false;
static bool Metrics_brew_mode()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_mode)
	{
		gbMetrics__brew_mode=false;
		
		if(eBrewStrength==eBrewStrength_Regular)
			ACK_SendUsageReportMetricWithStringValue(brew_mode,regular);
		else
			ACK_SendUsageReportMetricWithStringValue(brew_mode,bold);
		#if C_PRINT
		printf("Metric....brew_mode:[%d]\n",eBrewStrength);
		#endif
		return true;
	}
	return false;
}
//

//brew_setup
const char brew_setup[]="brew_setup";
const char carafe[]="carafe";
const char single_8oz[]="single_8oz";
const char single_10oz[]="single_10oz";
const char single_12oz[]="single_12oz";
const char single_14oz[]="single_14oz";
bool gbMetrics__brew_setup=false;
static bool Metrics_brew_setup()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_setup)
	{
		gbMetrics__brew_setup=false;
		
		switch(eBrewSetup)
		{
			case eBrewSetup_Carafe:
				ACK_SendUsageReportMetricWithStringValue(brew_setup,carafe);
			break;
			case eBrewSetup_Single8:
				ACK_SendUsageReportMetricWithStringValue(brew_setup,single_8oz);
			break;
			case eBrewSetup_Single10:
				ACK_SendUsageReportMetricWithStringValue(brew_setup,single_10oz);
			break;
			case eBrewSetup_Single12:
				ACK_SendUsageReportMetricWithStringValue(brew_setup,single_12oz);
			break;
			case eBrewSetup_Single14:
				ACK_SendUsageReportMetricWithStringValue(brew_setup,single_14oz);
			break;
			default:
				return false;
			break;
		}
		#if C_PRINT
		printf("Metric....brew_setup:[%d]\n",eBrewSetup);
		#endif
		return true;
	}
	return false;
}
//

//brew_economy_mode
const char brew_economy_mode[]="brew_economy_mode";
const char brew_economy_mode_on[]="on";
const char brew_economy_mode_off[]="off";
bool gbMetrics__brew_economy_mode=false;
static bool Metrics_brew_economy_mode()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_economy_mode)
	{
		gbMetrics__brew_economy_mode=false;
		
		switch(ePowerSaver)
		{
			case ePowerSaver_economyModeOn:
				ACK_SendUsageReportMetricWithStringValue(brew_economy_mode,brew_economy_mode_on);
			break;
			case ePowerSaver_economyModeOff:
				ACK_SendUsageReportMetricWithStringValue(brew_economy_mode,brew_economy_mode_off);
			break;
			default:
				return false;
			break;
		}
		#if C_PRINT
		printf("Metric....brew_economy_mode:[%d]\n",ePowerSaver);
		#endif
		return true;
	}
	return false;
}
//


//keep_warm_setting_hr
const char keep_warm_setting_hr[]="keep_warm_setting_hr";
bool gbMetrics__keep_warm_setting_hr=false;
static bool Metrics_keep_warm_setting_hr()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__keep_warm_setting_hr)
	{
		gbMetrics__keep_warm_setting_hr=false;
		
		ACK_SendUsageReportMetricWithNumericValue(keep_warm_setting_hr, eCarafeKeepWarm);
		#if C_PRINT
		printf("Metric....keep_warm_setting_hr:[%d]\n",eCarafeKeepWarm);
		#endif
		return true;
	}
	return false;
}
//


//keep_warm_setting_hr
const char brew_heater_preheat_min[]="brew_heater_preheat";
bool gbMetrics__brew_heater_preheat_min=false;
uint16_t gMetric_BrewHeaterPreheat=0;
static bool Metrics_brew_heater_preheat_min()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_heater_preheat_min)
	{
		gbMetrics__brew_heater_preheat_min=false;
		
		ACK_SendUsageReportMetricWithNumericValue(brew_heater_preheat_min, gMetric_BrewHeaterPreheat);
		#if C_PRINT
		printf("Metric....brew_heater_preheat:[%d]\n",gMetric_BrewHeaterPreheat);
		#endif
		return true;
	}
	return false;
}
//


static bool Metrics_Kettle_heater_life()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__Kettle_heater_life)
	{
		gbMetrics__Kettle_heater_life=false;
		
		ACK_SendUsageReportMetricWithNumericValue(Kettle_heater_life,Metrics__Kettle_heater_life);
		#if C_PRINT
		printf("Metric....Kettle_heater_life:[%d]\n",Metrics__Kettle_heater_life);
		#endif
		return true;
	}
	return false;
}
static bool Metrics_relay_cycle()
{
	static bool report=false;
	
	relay_cycle_handle();
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA || gbPower)
		return false;
	
	if(gbMetrics__carafe_relay_cycle_counts)
	{
		gbMetrics__carafe_relay_cycle_counts=false;
		
		ACK_SendUsageReportMetricWithNumericValue(carafe_relay_cycle_counts,Metrics__carafe_relay_cycle_counts);
		#if C_PRINT
		printf("Metric....carafe_relay_cycle_counts:[%d]\n",Metrics__carafe_relay_cycle_counts);
		#endif
		return true;
	}
	
	if(gbMetrics__single_relay_cycle_counts)
	{
		gbMetrics__single_relay_cycle_counts=false;
		
		ACK_SendUsageReportMetricWithNumericValue(single_relay_cycle_counts,Metrics__single_relay_cycle_counts);
		#if C_PRINT
		printf("Metric....single_relay_cycle_counts:[%d]\n",Metrics__single_relay_cycle_counts);
		#endif
		return true;
	}
	return false;
}







const char FirmwareV[]={'U',0X30+FIRMWARE_VERSION/10,0X30+FIRMWARE_VERSION%10};
const char FW_HMCU[]="FW_HMCU";
static bool Metrics_FW_HMCU()
{
	static bool reported=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	if(reported)
		return false;
	
	reported=true;
	ACK_SendUsageReportMetricWithStringValue(FW_HMCU,FirmwareV);
	return true;
}

//ERR_Clean
const char ERR_Clean[]="ERR_Clean";
bool gbMetric__Clean=false;
static bool Metrics_ERR_Clean()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__Clean)
	{
		gbMetric__Clean=false;
		ACK_SendErrorMetric(ERR_Clean);
		#if C_PRINT
		printf("Metric....ERR_Clean\n");
		#endif
		return true;
	}
	return false;
}

//ERR_stuck_button
const char ERR_stuck_button[]="ERR_stuck_button";
bool gbMetrics__ERR_stuck_button=false;
static bool Metrics_ERR_stuck_button()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__ERR_stuck_button)
	{
		gbMetrics__ERR_stuck_button=false;
		ACK_SendErrorMetric(ERR_stuck_button);
		#if C_PRINT
		printf("Metric....ERR_stuck_button\n");
		#endif
		return true;
	}
	return false;
}
//ERR_ESO_Cnt
const char ERR_ESO_Cnt[]="ERR_ESO_Cnt";
bool gbMetric__Eso=false;
uint16_t MetricEsoCounts=0;
static bool Metrics_ERR_ESO_Cnt()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__Eso)
	{
		gbMetric__Eso=false;
		ACK_SendUsageReportMetricWithNumericValue(ERR_ESO_Cnt,MetricEsoCounts);
		#if C_PRINT
		printf("Metric....ERR_ESO_Cnt:[%d]\n",MetricEsoCounts);
		#endif
		return true;
	}
	return false;
}


//ERR_ESO_Cnt
#define METRIC_CHANGE_REPORT_UPLOAD_DELAY		(6*60*60*100)
const char change_report[]="change_report";
uint32_t MetricChangeRepoerCounts=0;
static uint32_t MetricChangeReportUploadDelay=METRIC_CHANGE_REPORT_UPLOAD_DELAY;
static bool Metrics_change_report()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(MetricChangeReportUploadDelay==0)
	{
		MetricChangeReportUploadDelay=METRIC_CHANGE_REPORT_UPLOAD_DELAY;
		ACK_SendUsageReportMetricWithNumericValue(change_report,MetricChangeRepoerCounts);
		#if C_PRINT
		printf("Metric....change_report:[%d]\n",MetricChangeRepoerCounts);
		#endif
		return true;
	}
	return false;
}



//ERR_brew_chamber
const char ERR_brew_chamber[]="ERR_brew_chamber";
bool gbMetric__ERR_brew_chamber=false;
static bool Metrics_ERR_brew_chamber()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__ERR_brew_chamber)
	{
		gbMetric__ERR_brew_chamber=false;
		ACK_SendErrorMetric(ERR_brew_chamber);
		#if C_PRINT
		printf("Metric....ERR_brew_chamber\n");
		#endif
		return true;
	}
	return false;
}
//ERR_brew_chamber
const char ERR_needle[]="ERR_needle";
bool gbMetric__ERR_needle=false;
static bool Metrics_ERR_needle()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__ERR_needle)
	{
		gbMetric__ERR_needle=false;
		ACK_SendErrorMetric(ERR_needle);
		#if C_PRINT
		printf("Metric....ERR_needle\n");
		#endif
		return true;
	}
	return false;
}
//ERR_brew_chamber
const char ERR_out_of_water[]="ERR_out_of_water";
bool gbMetric__ERR_out_of_water=false;
static bool Metrics_ERR_out_of_water()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__ERR_out_of_water)
	{
		gbMetric__ERR_out_of_water=false;
		ACK_SendErrorMetric(ERR_out_of_water);
		#if C_PRINT
		printf("Metric....ERR_out_of_water\n");
		#endif
		return true;
	}
	return false;
}


//EER_long_brew
const char EER_long_brew[]="EER_long_brew";
bool gbMetric__EER_long_brew=false;
static bool Metrics_EER_long_brew()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__EER_long_brew)
	{
		gbMetric__EER_long_brew=false;
		ACK_SendErrorMetric(EER_long_brew);
		#if C_PRINT
		printf("Metric....EER_long_brew\n");
		#endif
		return true;
	}
	return false;
}



void MetricsHandle()
{
	bool status=false;
	
	check_power_on_metric();
	
	if(MetricsBusy)
		return;
	
	status=Metrics_FW_HMCU();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_start_end(true);
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_start_method();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_heater_preheat_min();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_economy_mode();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_setup();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_mode();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_keep_warm_setting_hr();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	
	status=Metrics_brew_duration();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	
	status=Metrics_KW_duration();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_end_method();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	
	
	status=Metrics_relay_cycle();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_cycle_count();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_start_end(false);
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_ERR_Clean();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_ERR_stuck_button();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
//	status=Metrics_ERR_ESO_Cnt();
//	if(status)
//	{
//		MetricsBusy=METRICS_BUSY;
//		return;
//	}
//	status=Metrics_ready_to_brew_state();
//	if(status)
//	{
//		MetricsBusy=METRICS_BUSY;
//		return;
//	}
	
	status=Metrics_ERR_out_of_water();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_ERR_brew_chamber();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_ERR_needle();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	
	status=Metrics_EER_long_brew();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_change_report();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
}

void MetricsHandleForTmrInt()
{
	if(MetricsBusy)
		MetricsBusy--;
	if(MetricChangeReportUploadDelay)
		MetricChangeReportUploadDelay--;
	if(sMetricPowerOnPending.debounce>0)
		sMetricPowerOnPending.debounce--;
	
	brew_duration_handle();
	KW_duration_handle();
}
