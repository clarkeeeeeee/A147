#ifndef _TIMER_PROCESS_
#define _TIMER_PROCESS_

#include "board.h"

typedef struct
{
	bool sFlip_1s;
	bool sFlip_500ms;
	bool sFlip_250ms;
	bool ugs_led_on;
	
	uint16_t Flip_1s_counts;
	uint16_t Flip_500ms_counts;
	uint16_t Flip_250ms_counts;
	uint16_t Flip_ticks_for_ugs;
}sFlip_t;

extern sFlip_t sFlip;


void Timer_0_Init(void);
void Timer_1_Init(void);
void Timer_2_Init(void);


#endif

