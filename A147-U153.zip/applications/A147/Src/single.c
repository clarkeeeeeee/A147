#include "single.h"
#include "dev.h"
#include "pid.h"
#include "self_check.h"
#include "metrics.h"
#include "top.h"
#include "new_algorithm.h"
#include "lcd.h"
/*
1��Ԥ��
2������
3������
4��bold
5��needle
6��
*/

#if XB_UART
#include "xb_uart.h"
#endif



#define SINGLE_CUP_FM_COUNTS_UNIT		117
const uint16_t SingleCupFmCounts[4]={	SINGLE_CUP_FM_COUNTS_UNIT*8,
										SINGLE_CUP_FM_COUNTS_UNIT*10,
										SINGLE_CUP_FM_COUNTS_UNIT*12,
										SINGLE_CUP_FM_COUNTS_UNIT*14};

sMtDrive_t sMtDrive={0,SINGLE_MT_PERIOD};
eSingleWorkStep_t eSingleWorkStep=eSingleWorkStep_None;

#if MT_IO_WRONG
#define SINGLE_MT_ON	PB15=1
#define SINGLE_MT_OFF	PB15=0
#else
#if PCB_VER>=3
#define SINGLE_MT_ON	PB4=1
#define SINGLE_MT_OFF	PB4=0
#else
#define SINGLE_MT_ON	PA10=1
#define SINGLE_MT_OFF	PA10=0
#endif
#endif

bool bSinglePreHeat=false;
bool bSingleHeat=false;
uint8_t SingleMtDuty=0;
static uint16_t BrewSecondsTotal=0;
static int16_t BoldSeconds=-1;
bool gbForceCoolHeater=false;

uint16_t SingleCupFmCountsUnit=SINGLE_CUP_FM_COUNTS_UNIT;
uint16_t SingleCupFmCountsUnitCfgTicks=0;
uint8_t gSingleCleaningRequired=CLEANING_REQUIRED_NO;
uint8_t gSingleCleaningRequiredLcd=CLEANING_REQUIRED_NO;

bool bTurnOffHeaterForLessSteam=false;

uint16_t CoolHeaterTicks=0;
uint16_t OverTempProtectCounts=0;

bool gbForceSingleHeat=false;

sRestartBrew_t sRestartBrew={false};

#define SINGLE_COFFEE_READY		(5*60*100)
uint16_t SingleCoffeeReady=0;

static uint8_t SingleCupSizeDyn=0;
uint16_t FmCountsDes;
#if FIRMWARE_VERSION>9
uint8_t WaterCheckRet=0;
#endif

uint8_t SingleGetCupSizeDyn()
{
	return SingleCupSizeDyn;
}
static void UpdateSingleCupSizeDyn(uint16_t counts)
{
	SingleCupSizeDyn=counts/SingleCupFmCountsUnit;
}

static int16_t gClearWaterTicks=-1;
bool SingleGetClearWater()
{
	return gClearWaterTicks>0?true:false;
}
void SingleSet_ClearWaterTicks()
{
	gClearWaterTicks=60*100;
}
void SingleClear_ClearWaterTicks()
{
	gClearWaterTicks=0;
} 

void SingleMtDrive()
{
	static uint8_t ticks=0;
	
	if(gbForceCoolHeater || SingleGetClearWater() || CoolHeaterTicks || gbSelfCheckPumpOn)
		SINGLE_MT_ON;
	else
	{
		if(ticks<sMtDrive.duty)
			SINGLE_MT_ON;
		else
			SINGLE_MT_OFF;
	}
	
	if(++ticks>=sMtDrive.period)
		ticks=0;
}

static void SingleMtUpdateDuty(uint8_t percent)
{
	uint16_t tmp=sMtDrive.period;
	tmp*=percent;
	tmp/=SINGLE_MT_PERIOD;
	sMtDrive.duty=tmp;
}



uint8_t SingleMtDutyReal=0;
static void SingleMtDutyHandle()
{
	if(CoolHeaterTicks)
	{
		CoolHeaterTicks--;
		return;
	}
	
	if(SingleGetClearWater() && eSingleWorkStep==eSingleWorkStep_None)
	{
//		SingleMtDuty=100;
		if(gClearWaterTicks==-1)
			gClearWaterTicks=0;
	}
	else if(gClearWaterTicks==0)
	{
//		SingleMtDuty=0;
		gClearWaterTicks=-1;
	}
	
	if(SingleMtDutyReal!=SingleMtDuty)
	{
		SingleMtDutyReal=SingleMtDuty;
		SingleMtUpdateDuty(SingleMtDutyReal);
		#if C_PRINT
//		printf("\r\n %s -> SingleMtDuty=%d \r\n",__func__,SingleMtDuty);
		#endif
	}
}
#define PRE_HEAT_TICKS_1S		100
static uint32_t GetSingleWarmTicks(ePowerSaver_t power_saver)
{
	switch(power_saver)
	{
		case ePowerSaver_economyModeOn:
			return 0;
		break;
		
		#if FM_DEBUG
		case ePowerSaver_Medium:
			return PRE_HEAT_TICKS_1S*60*1;
		break;
		case ePowerSaver_Low:
			return PRE_HEAT_TICKS_1S*60*2;
		break;
		case ePowerSaver_Off:
			return PRE_HEAT_TICKS_1S*60*3;
		break;
		#else
		case ePowerSaver_economyModeOff:
			return PRE_HEAT_TICKS_1S*60*30;
		break;
		#endif
		default:
		break;
	}
	return 0;
}

int16_t giPreHeatTicks=-1;
static uint16_t pre_heat_remain_ticks=0; 
int16_t giTempCompPreHeatTicks=-1;
#define SINGLE_PRE_HEAT_RELAY_TICKS_MIN		(15*100)
#define SINGLE_PRE_HEAT_RELAY_TICKS_MAX		(25*100)

static bool gbResetPreHeatTicksCauseSingleOp=false;
bool CheckResetPreHeatTicksCauseSingleOp()
{
	if(eBrewSetup>=eBrewSetup_Single8)
		return gbResetPreHeatTicksCauseSingleOp=true;
	return false;
}
static void SingleHeat()
{
	static eDevStatus_t dev_status;
	static uint32_t pre_heat_ticks=0;
	static bool bPreHeat10Minutes=false;
	
	if(gbForceSingleHeat || WaterTemp<0 || HeatTemp<0 || eBrewSetup<eBrewSetup_Single8 || (gDevError&~DEV_ERROR_CLOSE_LID)!=0 || SingleGetClearWater())
	{
		bSinglePreHeat=false;
		bSingleHeat=false;
		pre_heat_ticks=0;
		bPreHeat10Minutes=false;
		return;
	}
	
	
	switch(eDevStatus)
	{
		case eDevStatus_NotReadyToBrew:
		case eDevStatus_ReadyToBrew:
			bSingleHeat=false;
			if(gbResetPreHeatTicksCauseSingleOp)
			{
				gbResetPreHeatTicksCauseSingleOp=false;
				if(!bSinglePreHeat)
				{
					pre_heat_ticks=0;
					bPreHeat10Minutes=true;
					bSinglePreHeat=true;
				}
			}
			if(dev_status==eDevStatus_Brewing)
				bSinglePreHeat=true;
			
			if(bSinglePreHeat)
				pre_heat_ticks++;
			if(bPreHeat10Minutes)
				gMetric_BrewHeaterPreheat=pre_heat_ticks/100;
			if(bSinglePreHeat && !bPreHeat10Minutes)
				gMetric_BrewHeaterPreheat=0;
			if(bSinglePreHeat && pre_heat_ticks>=(bPreHeat10Minutes?(10*60*100):(GetSingleWarmTicks(ePowerSaver))))
			{
				bSinglePreHeat=false;
				bPreHeat10Minutes=false;
				#if C_PRINT
				printf("\r\n %s -> SinglePreHeat end , total pre_heat_ticks = %d\r\n",__func__,pre_heat_ticks);
				#endif
			}
		break;
			
		case eDevStatus_Brewing:
		
			if(giPreHeatTicks>=0 && giPreHeatTicks<SINGLE_PRE_HEAT_RELAY_TICKS_MAX)
			{
				bSinglePreHeat=true;
				bSingleHeat=false;
				break;
			}
			if(eSingleWorkStep!=eSingleWorkStep_ReleaseWaterCauseSteam)
			{
				#if FIRMWARE_VERSION>9
				if(!WaterCheckRet)
				{
					#if C_PRINT
					if(!bSingleHeat)
						printf("\r\n %s -> set bSingleHeat \r\n",__func__);
					#endif
					bSingleHeat=true;
				}
				else
					bSingleHeat=false;
				#else
				bSingleHeat=true;
				#endif
			}
			else
				bSingleHeat=false;
			pre_heat_ticks=0;
			bSinglePreHeat=false;
			bPreHeat10Minutes=false;
		break;
		default:
			bSinglePreHeat=false;
			bSingleHeat=false;
			pre_heat_ticks=0;
			bPreHeat10Minutes=false;
		break;
	}
	dev_status=eDevStatus;
}

//#define HEAT_TEMP_LOW		88
//#define HEAT_TEMP_HIGH		92

#define PRE_HEAT_TEMP_LOW	63
#define PRE_HEAT_TEMP_HIGH	65
#define TEMP_COMP_PRE_HEAT	65

#define HEAT_TEMP_LOW		PID_STOT
#define HEAT_TEMP_HIGH		140
#define FORCE_SINGLE_HEAT	80


#define OVER_TEMP			120

#define GI_PREHEAT_TICKS	(60*100)

#define SINGLE_WORK_HANDLE_1S		100
#define BOLD_PREHEAT_TICKS		(SINGLE_WORK_HANDLE_1S*2)

bool Single_GetKeepWarm()		//
{
	return bSinglePreHeat || bSingleHeat;
}


bool Single_GetHeatRelay()
{
	static bool ret=false;
	static uint16_t need_pre_heat_ticks;
	
	static bool bOverTempProtect=false;
	
	if(gbSelfCheckSingleRelayOn)
		return true;
	
	if(gbForceSingleHeat)
	{
		if(HeatTemp>FORCE_SINGLE_HEAT)
			return gbForceSingleHeat=false;
		return true;
	}
	
	if(HeatTemp>OVER_TEMP || WaterTemp>HEAT_TEMP_HIGH)
	{
		gDevError|=DEV_ERROR_OVER_TEMP;
		giPreHeatTicks=-1;
		if(!bOverTempProtect)
		{
			bOverTempProtect=true;
			OverTempProtectCounts++;
		}
		return false;
	}
	else if(HeatTemp<80 && WaterTemp<80)
	{
		gDevError&=~DEV_ERROR_OVER_TEMP;		//auto clear
		if(bOverTempProtect)
		{
			bOverTempProtect=false;
			#if C_PRINT
			printf("reset bOverTempProtect : HeatTemp=%d WaterTemp=%d \r\n",HeatTemp,(int16_t)WaterTemp);
			#endif
		}
	}
	if(gDevError&DEV_ERROR_OVER_TEMP)
		return false;
	
//	if(HeatTemp>105 || WaterTemp>110)
//	{
//		return false;
//	}
	
	if(eSingleWorkStep==eSingleWorkStep_FillHeaterWithWater)
	{
		giPreHeatTicks=-1;
		return false;
	}
	if(eSingleWorkStep==eSingleWorkStep_ErrCheck && SingleMtDuty==SINGLE_MT_PERIOD)
	{
		giPreHeatTicks=-1;
		return false;
	}
	
	if(eSingleWorkStep==eSingleWorkStep_TempComp)
	{
		giPreHeatTicks=-1;
		
		if(giTempCompPreHeatTicks==-1)
			giTempCompPreHeatTicks=0;
		if((giTempCompPreHeatTicks<(100+(TEMP_COMP_PRE_HEAT-HeatTemp+5)*31) && giTempCompPreHeatTicks>100))
			ret=true;
		else
			ret=false;
		return ret;
	}
	else
	{
		giTempCompPreHeatTicks=-1;
	}
	
	
	
	if(!bSinglePreHeat)
		pre_heat_remain_ticks=0;
	
	if(bSinglePreHeat)
	{
		#if !FIRMWARE_VERSION>=12
		if(HeatTemp>=PRE_HEAT_TEMP_HIGH || WaterTemp>=82)
		{
			ret=false;
//			giPreHeatTicks=-1;
		}
		else
		{
			if(HeatTemp<=PRE_HEAT_TEMP_HIGH-15 && giPreHeatTicks>=GI_PREHEAT_TICKS)
				giPreHeatTicks=-1;
			
			if(giPreHeatTicks<=0)
			{
				giPreHeatTicks=0;
			}
			if((giPreHeatTicks<(100+(PRE_HEAT_TEMP_HIGH-HeatTemp)*31) && giPreHeatTicks>100) ||\
				(giPreHeatTicks<(4900+(PRE_HEAT_TEMP_HIGH-HeatTemp+5)*31) && giPreHeatTicks>4900))
				ret=true;
			else
				ret=false;
		}
		#else
		if(ret==false && (HeatTemp>=PRE_HEAT_TEMP_HIGH || WaterTemp>=82))
		{
		}
		else
		{
			if(HeatTemp<PRE_HEAT_TEMP_LOW && giPreHeatTicks>=GI_PREHEAT_TICKS)
				giPreHeatTicks=-1;
			
			if(giPreHeatTicks<0)
			{
				giPreHeatTicks=0;
			}
			
			if(HeatTemp>=(PRE_HEAT_TEMP_HIGH-5))
			{
				if(giPreHeatTicks==100)
				{
					pre_heat_remain_ticks=(PRE_HEAT_TEMP_HIGH-HeatTemp)*62;
				}
			}
			else
			{
				if(giPreHeatTicks==100)
				{
					pre_heat_remain_ticks=(PRE_HEAT_TEMP_HIGH-HeatTemp)*31;
				}
				if(giPreHeatTicks==4900)
				{
					pre_heat_remain_ticks=(PRE_HEAT_TEMP_HIGH-HeatTemp+5)*31;
				}
			}
			
			if(pre_heat_remain_ticks)
				ret=true;
			else
				ret=false;
			
//			if((giPreHeatTicks<(100+(PRE_HEAT_TEMP_HIGH-HeatTemp)*31) && giPreHeatTicks>100) ||\
//				(giPreHeatTicks<(4900+(PRE_HEAT_TEMP_HIGH-HeatTemp+5)*31) && giPreHeatTicks>4900))
//				ret=true;
//			else
//				ret=false;
		}
		#endif
	}
	else if(bSingleHeat)
	{
		giPreHeatTicks=-1;
		if(BoldSeconds>BOLD_PREHEAT_TICKS || bTurnOffHeaterForLessSteam)		//bold mode pause or Close early to reduce steam
			return false;
		if(WaterTemp<HEAT_TEMP_HIGH-5)
			ret=true;
		if(WaterTemp>HEAT_TEMP_HIGH)
			ret=false;
	}
	else
	{
		ret=false;
		giPreHeatTicks=-1;
	}
	return ret;
}
void ReloadCoolHeaterTicks()
{
	CoolHeaterTicks=20*100;
}
void ClearCoolHeaterTicks()
{
	CoolHeaterTicks=0;
}

#if FM_DEBUG
bool gbFmDebug_SingleErrCheckNeedle=false;
#endif
#define NEEDLE_CHECK_FM					6

#if FIRMWARE_VERSION>9
#define WATER_CHECK_RET_NONE			0
#define WATER_CHECK_RET_FORCE_FINISH	1
#define WATER_CHECK_RET_PUMP_STRONG		2
#define WATER_CHECK_RET_PUMP_WEAK		3
#define WATER_CHECK_RET_ERROR			4
uint8_t WaterCheck(bool reset)
{
	static uint32_t fm_bkp;
	static uint32_t ticks=0;
	static bool needle_check=false;
	static bool needle_error=false;
	static bool water_error=false;
	
	static uint16_t adc_over_ticks=0;
	
	static bool already_reset=false;
	
//	return WATER_CHECK_RET_NONE;
	
	if(reset)
	{
		if(already_reset)
			return WATER_CHECK_RET_NONE;
		already_reset=true;
		fm_bkp=GetFlowmeter();
		ticks=0;
		adc_over_ticks=0;
		needle_check=false;
		needle_error=false;
		water_error=false;
		#if C_PRINT
		printf("\r\n %s -> reset WaterCheck \r\n",__func__);
		#endif
		return WATER_CHECK_RET_NONE;
	}
	already_reset=false;
	
	if(needle_error || water_error)
	{
		if(!ticks)
			sRestartBrew.fm_bkp=GetFlowmeter();
		
		if(++ticks>=2500)
		{
			if(needle_error)
			{
				gDevError|=DEV_ERROR_NEEDLE;
				gbMetric__ERR_needle=true;
			}
			else
			{
				gDevError|=DEV_ERROR_FILL_H2O;
				gbMetric__ERR_out_of_water=true;
				sRestartBrew.flag=true;
			}
			eDevStatus=eDevStatus_NotReadyToBrew;
			return WATER_CHECK_RET_ERROR;
		}
		if(WaterTemp>=80)
			return WATER_CHECK_RET_PUMP_STRONG;
		return WATER_CHECK_RET_PUMP_WEAK;
	}
	
	if(PumpCurrentAdcRes>PUMP_CURRENT_ADC_RES_MAX)
	{
		if(++adc_over_ticks>=150)
		{
			adc_over_ticks=0;
			needle_error=true;
			#if C_PRINT
			printf("%s set needle_error cause PumpCurrentAdcRes",__func__);
			#endif
		}
	}
	else
	{
		adc_over_ticks=0;
	}
	
	uint32_t diff;
	
	if(needle_check)
	{
		if(++ticks>=150)
		{
			ticks=0;
			
			diff=GetFlowmeter()-fm_bkp;
			#if C_PRINT
			printf("%s GetFlowmeter()-fm_bkp=%d\r\n",__func__,diff);
			#endif
			if(diff<=NEEDLE_CHECK_FM)
			{
				if(FmCountsDes>GetFlowmeter() && (FmCountsDes-GetFlowmeter())>=245)
				{
					water_error=true;
					#if C_PRINT
					printf("%s set water_error",__func__);
					#endif
				}
				else
				{
					#if C_PRINT
					printf("%s set WATER_CHECK_RET_FORCE_FINISH",__func__);
					#endif
					return WATER_CHECK_RET_FORCE_FINISH;
				}
			}
			else
			{
				needle_error=true;
				#if C_PRINT
				printf("%s set needle_error",__func__);
				#endif
			}
//			else
//				water_error=true;
		}
		return WATER_CHECK_RET_PUMP_STRONG;
	}
	
	if(++ticks>=150)
	{
		ticks=0;
		diff=GetFlowmeter()-fm_bkp;
		#if C_PRINT
		printf("%s GetFlowmeter()-fm_bkp=%d\r\n",__func__,diff);
		#endif
		
		if(diff<=3)
		{
			needle_check=true;
			#if C_PRINT
			printf("%s set needle_check",__func__);
			#endif
		}
		fm_bkp=GetFlowmeter();
		
	}
	
	return WATER_CHECK_RET_NONE;
}
#else
void WaterCheck(bool reset)
{
	static uint32_t fm_bkp;
	static uint32_t ticks=0;
	
	if(reset)
	{
		fm_bkp=GetFlowmeter();
		ticks=0;
		#if C_PRINT
		printf("\r\n %s -> reset WaterCheck \r\n",__func__);
		#endif
		return;
	}
	
	if(++ticks>=100*3)
	{
		ticks=0;
		if(GetFlowmeter()-fm_bkp<=5)
		{
			SingleMtDuty=0;
			gDevError|=DEV_ERROR_FILL_H2O;
			eDevStatus=eDevStatus_NotReadyToBrew;
//			ReloadCoolHeaterTicks();
			#if C_PRINT
			printf("\r\n %s -> set DEV_ERROR_FILL_H2O \r\n",__func__);
			#endif
		}
		fm_bkp=GetFlowmeter();
	}
}
#endif
static float duty_fac_for_bold;		//for bold mode
uint32_t SingleWrokTicks=0;
static bool bPidOn=false;
void SingleWorkHandle()
{
	static uint32_t ticks=0;
	static uint32_t fm;
	uint32_t fm_now;
	static eDevStatus_t dev_status;
	static eBrewStrength_t brew_strength;
	static eSingleWorkStep_t single_work_step;
	static float water_temp;
	float fTmp;
	
	
	static bool bAlreadyPreHeat=false;
	
	
	if(SingleCupFmCountsUnitCfgTicks)
		SingleCupFmCountsUnitCfgTicks--;
	if(gClearWaterTicks>0)
		gClearWaterTicks--;
	if(giPreHeatTicks!=-1 && giPreHeatTicks<GI_PREHEAT_TICKS)
		giPreHeatTicks++;
	if(giTempCompPreHeatTicks!=-1 && giTempCompPreHeatTicks<(60*100))
		giTempCompPreHeatTicks++;
	if(pre_heat_remain_ticks)
		pre_heat_remain_ticks--;
	if(SingleCoffeeReady)
		SingleCoffeeReady--;
	
	SingleHeat();
	SingleMtDutyHandle();
	
	if(eBrewSetup<eBrewSetup_Single8 && eSingleWorkStep==eSingleWorkStep_None)
		return;
	
	if(gDevError || WaterTemp<0 || HeatTemp<0 || eDevStatus<eDevStatus_Brewing || eBrewSetup<eBrewSetup_Single8)
	{
		#if FM_DEBUG
		gbFmDebug_SingleErrCheckNeedle=false;
		#endif
		if(eSingleWorkStep!=eSingleWorkStep_None)
		{
			#if C_PRINT
			printf("\r\n %s -> clear eSingleWorkStep :  WaterTemp=%.1f,HeatTemp=%d,eDevStatus=%d,eBrewSetup=%d,gbBrewChamberMicroswitch=%d\r\n",\
			__func__,WaterTemp,HeatTemp,eDevStatus,eBrewSetup,gbBrewChamberMicroswitch);
			#endif
			eSingleWorkStep=eSingleWorkStep_None;
//			eDevStatus=eDevStatus_NotReadyToBrew;
			if(gbPower)
			{
				DevPowerOff();
				MetricBrewEnd(gDevError?eMetrics_EndMethod_Error:eMetrics_EndMethod_ASO);
			}
			
			
			
			if((SingleCounts%SINGLE_COUNTS_CLEAN)==0)
			{
				gSingleCleaningRequiredLcd=gSingleCleaningRequired=CLEANING_REQUIRED_YES;
//				gDevError|=DEV_ERROR_CLEAN;
				gbMetric__Clean=true;
			}
			if(SingleCounts>=SINGLE_COUNTS_CLEAN && (SingleCounts%SINGLE_COUNTS_CLEAN)==1)
			{
				gSingleCleaningRequiredLcd=gSingleCleaningRequired=CLEANING_REQUIRED_YES;
//				gDevError|=DEV_ERROR_CLEAN;
			}
			if(!WaterCheckRet && gDevError && HeatTemp>80)
				ReloadCoolHeaterTicks();
		}
	}
	
	if(brew_strength!=eBrewStrength)
	{
		brew_strength=eBrewStrength;
		BoldSeconds=0;
	}
	
	if(dev_status!=eDevStatus)
	{
		if(eDevStatus==eDevStatus_Brewing && dev_status<eDevStatus_Brewing && eBrewSetup>=eBrewSetup_Single8)
			eSingleWorkStep=eSingleWorkStep_Init;
		dev_status=eDevStatus;
	}
	
	if(single_work_step!=eSingleWorkStep)
	{
		single_work_step=eSingleWorkStep;
		#if C_PRINT
		printf("\r\n %s -> single_work_step=%d \r\n",__func__,single_work_step);
		#endif
	}
	
	switch(eSingleWorkStep)
	{
		case eSingleWorkStep_None:
			ticks++;
			SingleMtDuty=0;
			BrewSecondsTotal=0;
			BoldSeconds=-1;
			if(eDevStatus>=eDevStatus_CoffeeReady)
			{
				if(ticks>=COFFEE_READY_SECONDS*100)
					eDevStatus=eDevStatus_NotReadyToBrew;
			}
		break;
		
		case eSingleWorkStep_Init:
			if(HeatTemp>=PRE_HEAT_TEMP_LOW)
				giPreHeatTicks=-1;
			if(giPreHeatTicks>=0 && giPreHeatTicks<SINGLE_PRE_HEAT_RELAY_TICKS_MAX)
				break;
			#if XB_UART
			eXbUartErrCheck=eXbUartErrCheck_None;
			eXbUartErrCodeAtByte11=eXbUartErrCodeAtByte11_none;
			#endif
			ResetFlowmeter(sRestartBrew.flag?sRestartBrew.fm_bkp:0);
			sRestartBrew.flag=false;
			fm=0;
			SingleMtDuty=0;
			FmCountsDes=SingleCupFmCountsUnit* (eBrewSetup==eBrewSetup_Single8 ? 8 : (eBrewSetup==eBrewSetup_Single10 ? 10 : (eBrewSetup==eBrewSetup_Single12 ? 12 : (eBrewSetup==eBrewSetup_Single14 ? 14 : 0))));
			eSingleWorkStep++;
			ticks=0;
			bTurnOffHeaterForLessSteam=false;
			bAlreadyPreHeat=false;
			#if FIRMWARE_VERSION>9
			WaterCheckRet=WaterCheck(true);
			#else
			WaterCheck(true);	
			#endif
			UpdateSingleCupSizeDyn(GetFlowmeter()-fm);
			ClearCoolHeaterTicks();
			#if C_PRINT
			printf("\r\n %s -> fm=%d \r\n",__func__,fm);
			#endif
		break;
		case eSingleWorkStep_FillHeaterWithWater:
			#if FM_SHOW
			eSingleWorkStep++;
			ticks=0;
			fm=GetFlowmeter();
			break;
			#endif
			ticks++;
			if(ticks<200)
				SingleMtDuty=SINGLE_MT_PERIOD;
			else
			{
				eSingleWorkStep++;
				ticks=0;
				SingleMtDuty=16;
			}
		break;
		case eSingleWorkStep_TempComp:
			#if FM_SHOW
			eSingleWorkStep++;
			ticks=0;
			break;
			#endif
			ticks++;
			if(gbDevSingleHeatRelay)
			{
				ticks=0;
				bAlreadyPreHeat=true;
			}
			else if(ticks>=1000 || HeatTemp>=TEMP_COMP_PRE_HEAT || WaterTemp>=PID_START-5)
			{
				eSingleWorkStep++;
				ticks=0;
			}
		break;
		case eSingleWorkStep_ErrCheck:
			ticks++;
			if(ticks<SINGLE_WORK_HANDLE_1S+SINGLE_WORK_HANDLE_1S/2)
			{
				//SingleMtDuty=SINGLE_MT_DUTY_BASE;
				SingleMtDuty=SINGLE_MT_DUTY_MIN;
				if(GetFlowmeter()>fm+3)
				{
					eSingleWorkStep++;
					ticks=0;
					water_temp=WaterTemp;
					PID_Init();
					NewAlgorithmInit(WaterTemp,&HeatTemp);
					bPidOn=false;
				}
				#if XB_UART
				eXbUartErrCheck=eXbUartErrCheck_Needle;
				#endif
			}
			else if(ticks<SINGLE_WORK_HANDLE_1S*3)
			{
				if(ticks==SINGLE_WORK_HANDLE_1S+SINGLE_WORK_HANDLE_1S/2)
					fm=GetFlowmeter();
				#if FM_DEBUG
				gbFmDebug_SingleErrCheckNeedle=true;
				#endif
				SingleMtDuty=100*SINGLE_MT_PERIOD/100;
				if(GetFlowmeter()>fm+NEEDLE_CHECK_FM || PumpCurrentAdcRes>PUMP_CURRENT_ADC_RES_MAX)
				{
					gDevError|=DEV_ERROR_NEEDLE;
					gbMetric__ERR_needle=true;
					//eSingleWorkStep=eSingleWorkStep_None;
					ticks=0;
					eDevStatus=eDevStatus_NotReadyToBrew;
//					ReloadCoolHeaterTicks();
					#if XB_UART
					eXbUartErrCodeAtByte11=eXbUartErrCodeAtByte11_170;
					#endif
				}
				#if XB_UART
				eXbUartErrCheck=eXbUartErrCheck_H2o;
				#endif
			}
			else
			{
				SingleMtDuty=0;
				gDevError|=DEV_ERROR_FILL_H2O;
				gbMetric__ERR_out_of_water=true;
				//eSingleWorkStep=eSingleWorkStep_None;
				ticks=0;
				eDevStatus=eDevStatus_NotReadyToBrew;
//				ReloadCoolHeaterTicks();
				#if XB_UART
				if(GetFlowmeter()>fm+0)
					eXbUartErrCodeAtByte11=eXbUartErrCodeAtByte11_130;
				else
					eXbUartErrCodeAtByte11=eXbUartErrCodeAtByte11_100;
				#endif
			}
		break;
		case eSingleWorkStep_ReleaseWater:	
			
			fm_now=GetFlowmeter();
		
			#if XB_UART
			eXbUartErrCheck=eXbUartErrCheck_None;
			#endif
			ticks++;
			if(ticks<SINGLE_WORK_HANDLE_1S*240)
			{
				if(eBrewStrength!=eBrewStrength_Bold)
					BoldSeconds=-1;
				if(BoldSeconds>0)
				{
					BoldSeconds--;
					bAlreadyPreHeat=false;
					
					#if FIRMWARE_VERSION>9
					if(BoldSeconds>4*100+BOLD_PREHEAT_TICKS)
					{
						fTmp=duty_fac_for_bold*(WaterTemp-PID_START);
						fTmp=fTmp<SINGLE_MT_DUTY_MIN?SINGLE_MT_DUTY_MIN:fTmp;
					}
					else
						fTmp=8*SINGLE_MT_PERIOD/100;
					SingleMtDuty=fTmp;
					#else
					if(BoldSeconds>4*100)
						fTmp=duty_fac_for_bold*(WaterTemp-PID_START);
					else
						fTmp=SINGLE_MT_DUTY_MIN;
					
//					if(fTmp<(SINGLE_MT_DUTY_MIN+5))
//						SingleMtDuty=fTmp=SINGLE_MT_DUTY_MIN+5;
//					else
//						SingleMtDuty=fTmp;
					if((BoldSeconds%10)==0)
						if(SingleMtDuty>SINGLE_MT_DUTY_MIN+0)
							SingleMtDuty--;
					#endif
					PID_Init();
					NewAlgorithmInit(WaterTemp,&HeatTemp);
					bPidOn=false;
					UpdateSingleCupSizeDyn(fm_now-fm);
					break;
				}
				
				if(WaterTemp<PID_START-2)
					bPidOn=false;
				else if(WaterTemp>PID_START)
					bPidOn=true;
				
				
				
//				NewAlgorithm(HeatTemp>90?HeatTemp:HeatTemp-5,WaterTemp);
				
				bool no_water_check_function=false;
				
				if(!bPidOn)//WaterTemp<PID_START)
				{
					PID_Init();
					NewAlgorithmInit(WaterTemp,&HeatTemp);
					SingleMtDuty=SINGLE_MT_DUTY_MIN;
					if(!bAlreadyPreHeat && WaterTemp<PID_START-10)
					{
						SingleMtDuty>>=1;
						WaterCheck(no_water_check_function=true);
					}
				}
				else if(WaterCheckRet<=WATER_CHECK_RET_FORCE_FINISH && NewAlgorithm((eBrewStrength==eBrewStrength_Bold)?HEAT_TEMP_LOW+0:HEAT_TEMP_LOW,WaterTemp))
				{
					#if PID_INC
					float f_pid=100;
					f_pid-=pid.value;
					#else
					float f_pid=pid.OUT;
					f_pid=25+SINGLE_MT_DUTY_MIN-f_pid;
					f_pid=NewAlgorithm__Duty;
					#endif
					
					if(f_pid<SINGLE_MT_DUTY_MIN)
						f_pid=SINGLE_MT_DUTY_MIN;
					if(f_pid>SINGLE_MT_DUTY_MAX)
						f_pid=SINGLE_MT_DUTY_MAX;
					SingleMtDuty=f_pid;
					water_temp=WaterTemp;
					
					#if C_PRINT
					printf("%s SingleMtDuty=%d\n",__func__,SingleMtDuty);
					#endif
				}
				
				
				
				
				#if FIRMWARE_VERSION>9
				WaterCheckRet=WaterCheck(no_water_check_function);
				if(WaterCheckRet==WATER_CHECK_RET_FORCE_FINISH)
				{
					UpdateSingleCupSizeDyn(FmCountsDes);
					goto eSingleWorkStep_ReleaseWater_end;
				}
				if(WaterCheckRet==WATER_CHECK_RET_PUMP_STRONG)
				{
					SingleMtDuty=100*SINGLE_MT_PERIOD/100;
					break;
				}
				if(WaterCheckRet==WATER_CHECK_RET_PUMP_WEAK)
				{
					SingleMtDuty=8*SINGLE_MT_PERIOD/100;
					break;
				}
				if(WaterCheckRet==WATER_CHECK_RET_ERROR)
				{
					break;
				}
				
				UpdateSingleCupSizeDyn(fm_now-fm);
				
				#else
				if(SingleMtDuty<16)
					WaterCheck(true);	
				else
					WaterCheck(false);	
				#endif
				
				if(BoldSeconds==-1 && eBrewStrength==eBrewStrength_Bold)
				{
					//if(fm_now>fm && (fm_now-fm)>= SingleCupFmCountsUnit* (eBrewSetup==eBrewSetup_Single8 ? 4 : (eBrewSetup==eBrewSetup_Single10 ? 5 : (eBrewSetup==eBrewSetup_Single12 ? 6 : (eBrewSetup==eBrewSetup_Single14 ? 7 : 0)))))
					if(fm_now>fm && (fm_now-fm)>=300)
//					if(ticks>=4000)
					{
						BoldSeconds=20*100+BOLD_PREHEAT_TICKS;
						duty_fac_for_bold=WaterTemp;
						duty_fac_for_bold-=PID_START;
						
						#if FIRMWARE_VERSION>9
						fTmp=SingleMtDuty;
						if(WaterTemp>PID_STOT-5)
							fTmp*=0.85;
						else if(WaterTemp>PID_STOT-10)
							fTmp*=0.75;
						else
							fTmp*=0.65;
						
						duty_fac_for_bold=(duty_fac_for_bold<=0)?0:(fTmp/duty_fac_for_bold);
						#else
						fTmp=SingleMtDuty-SINGLE_MT_DUTY_MIN;
						duty_fac_for_bold=(duty_fac_for_bold==0)?0:(fTmp/duty_fac_for_bold);
						#endif
						#if C_PRINT
						printf("\r\n %s -> Set BoldSeconds=%d \r\n",__func__,BoldSeconds);
						printf("\r\n %s -> %f %d %d %d   calc duty_fac_for_bold=%f \r\n",__func__,WaterTemp,PID_START,SingleMtDuty,SINGLE_MT_DUTY_MIN,duty_fac_for_bold);
						#endif
						#if FIRMWARE_VERSION>9
						WaterCheckRet=WaterCheck(true);
						#else
						WaterCheck(true);	
						#endif
						break;
					}
				}
				
				
				
				if(!bTurnOffHeaterForLessSteam)
				{
					#if FIRMWARE_VERSION>=12 || (FIRMWARE_VERSION>=11 && FIRMWARE_VERSION_MINOR>=3)
					fTmp=SingleCupFmCountsUnit;
					fTmp*=(SingleMtDuty/2);
					fTmp/=70;
					#elif FIRMWARE_VERSION>9
					fTmp=SingleCupFmCountsUnit;
					fTmp*=(SingleMtDuty/2);
					fTmp*=PumpCurrentAdcRes;
					fTmp/=2100;
					#else
					fTmp=SingleCupFmCountsUnit;
					fTmp*=SingleMtDuty;
					fTmp/=100;
					#endif
					if(fm_now>fm && (fm_now-fm+fTmp)>= FmCountsDes)
					{
						#if C_PRINT
						printf("\r\n %s -> set bTurnOffHeaterForLessSteam done = 1 \r\n",__func__);
						printf("\r\n %s -> fm_now=%d \r\n",__func__,fm_now);
						#endif
						bTurnOffHeaterForLessSteam=true;
					}
				}
				else
				{
					if(fm_now>fm && (fm_now-fm)>= FmCountsDes)
					{
						#if C_PRINT
						printf("\r\n %s -> ReleaseWater done : fm_now=%d \r\n",__func__,fm_now);
						#endif
						goto eSingleWorkStep_ReleaseWater_end;
					}
				}
				break;
			}
			else
				gbMetric__EER_long_brew=true;
			#if C_PRINT
			printf("\r\n %s -> ReleaseWater ot at %d s : fm_now=%d \r\n",__func__,ticks/SINGLE_WORK_HANDLE_1S,fm_now);
			#endif
			eSingleWorkStep_ReleaseWater_end:
			SingleMtDuty=0;
			eSingleWorkStep++;
			ticks=0;
		break;
		case eSingleWorkStep_ReleaseWaterCauseSteam:
			ticks++;
			if(ticks>SINGLE_WORK_HANDLE_1S*17)
			{
				eSingleWorkStep++;
				ticks=0;
				//eDevStatus=eDevStatus_NotReadyToBrew;
			}
		break;
		case eSingleWorkStep_DisplayOz:
			ticks++;
//			if(ticks>SINGLE_WORK_HANDLE_1S*17)
			{
				eSingleWorkStep++;
				ticks=0;
				eDevStatus=eDevStatus_NotReadyToBrew;
				SingleCoffeeReady=SINGLE_COFFEE_READY;
				#if C_PRINT
				printf("%s -> SingleCoffeeReady = %d \r\n",__func__,SingleCoffeeReady);
				#endif
			}
		break;	
		case eSingleWorkStep_PreHeat:
			eSingleWorkStep=eSingleWorkStep_None;
			ticks=0;
		break;
		default:
			break;
	}
	
	SingleWrokTicks=ticks/100;
}



































