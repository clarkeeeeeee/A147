#include "xb_uart.h"
#include "dev.h"
#include "single.h"
#include "pid.h"

#if XB_UART

static bool bXbUartUpload=false;
eXbUartErrCheck_t eXbUartErrCheck;
eXbUartErrCodeAtByte11_t eXbUartErrCodeAtByte11;

uint8_t gXbUartErrorMask_CloseLid=0;

void XbUartFromIsr()
{
	static uint16_t ticks=0;
	
	if(bXbUartUpload)
		return;
	
	if(++ticks>=500)
	{
		ticks=0;
		bXbUartUpload=true;
	}
}

extern bool UART0_SendChar(uint8_t* dat,uint8_t len);
#define XB_UART_SEND	UART0_SendChar
#define XB_UART_UPLOAD_LEN	15
static uint8_t upload_buf[XB_UART_UPLOAD_LEN];


#define SEND_BUF	upload_buf

static int16_t pre_temp=0;

#define DEV_ID		147
#define START_ROW_WITH_CARAFE	1

static bool UpdateBuf()
{
	uint8_t i=0;
	uint32_t tmp;
	
	#if !START_ROW_WITH_CARAFE
	static eSingleWorkStep_t sws=0;
	#else
	static bool power=true;
	#endif
	
	static bool err=false;
	uint8_t err_code=0;
	if(gDevError&DEV_ERROR_NEEDLE)
		err_code|=2;
	if(gDevError&DEV_ERROR_FILL_H2O)
		err_code|=8;
	if(gDevError&DEV_ERROR_OVER_TEMP)
		err_code|=16;
//	if(!gbBrewChamberMicroswitch)
//		err_code|=(eDevStatus>=eDevStatus_Brewing)?(1<<7):(1<<6);
	err_code|=(gXbUartErrorMask_CloseLid&0xc0);
	gXbUartErrorMask_CloseLid=0;
	
	#if 0
	if(err_code&0x3f)
	{
		if(err)
			return false;
		err=true;
	}
	else
		err=false;
	#endif
	
	#if !START_ROW_WITH_CARAFE
	if(sws!=eSingleWorkStep)
	{
		if(sws==eSingleWorkStep_None)
		{
			sws=eSingleWorkStep;
	#else
	if(power!=gbPower)
	{
		if(power==false)
		{
			power=gbPower;
	#endif
			
			for(;i<9;i++)
				SEND_BUF[i]=0xff;
			SEND_BUF[9]=SingleCounts/254;
			SEND_BUF[10]=SingleCounts%254;
			SEND_BUF[11]=DEV_ID;
			SEND_BUF[12]=FIRMWARE_VERSION;
			SEND_BUF[13]=16;
			goto UpdateBuf_lastByte;
		}
		#if !START_ROW_WITH_CARAFE
		sws=eSingleWorkStep;
		#else
		power=gbPower;
		#endif
	}

	for(;i<XB_UART_UPLOAD_LEN;i++)
		SEND_BUF[i]=0;
	
	SEND_BUF[0]=(HeatTemp==NTC_SC || WaterTemp==NTC_OC)?0:(unsigned char)HeatTemp;
	SEND_BUF[0]=SEND_BUF[0]>199?199:SEND_BUF[0];	//0-199

extern eSingleWorkStep_t eSingleWorkStep;
	
	if(Single_GetKeepWarm())
	{
		SEND_BUF[1]=70;
		if(eDevStatus>=eDevStatus_Brewing)
		{
			if(WaterTemp<PID_START)SEND_BUF[1]+=10;
			else	SEND_BUF[1]+=20;
		}
	}
	SEND_BUF[2]=((PumpCurrentAdcRes/2)>253)?253:(PumpCurrentAdcRes/2);

extern uint8_t SingleMtDuty;
	if(eDevStatus>=eDevStatus_Brewing && eBrewSetup>=eBrewSetup_Single8)
		SEND_BUF[3]|=1;
	if(gbBrewChamberMicroswitch)
		SEND_BUF[3]|=2;
	if(gbDevSingleHeatRelay)
		SEND_BUF[3]|=4;
	if(SingleMtDuty)
		SEND_BUF[3]|=8;
	if(gbRelay)
		SEND_BUF[3]|=16;

	SEND_BUF[4]=(GetFlowmeter()>2539)?253:GetFlowmeter()/10;
	
	SEND_BUF[5]=(WaterTemp==NTC_SC || WaterTemp==NTC_OC)?0:(unsigned char)WaterTempForXb;
	SEND_BUF[5]=SEND_BUF[5]>120?120:SEND_BUF[5];	//0-199
	
	SEND_BUF[6]=(pre_temp==NTC_SC || pre_temp==NTC_OC)?0:(unsigned char)pre_temp;
	SEND_BUF[6]=SEND_BUF[6]>120?120:SEND_BUF[6];	//0-199
	
	pre_temp=SEND_BUF[5];
	
extern uint32_t SingleWrokTicks;
//	SEND_BUF[7]=(SingleWrokTicks>0xff)?0xff:SingleWrokTicks;
	SEND_BUF[7]=0xff;
	SEND_BUF[7]=OverTempProtectCounts;
	//bak_send_buf[7]=(((primeCnt<=10000/2)? primeCnt/500: (primeCnt-10000/2)) + OT_NTC*10);

	SEND_BUF[8]=SingleMtDuty/2;

//	tmp=PumpCurrentAdcRes*SingleMtDuty/100;
//	SEND_BUF[9]=(tmp>253)?253:tmp;	//bak_send_buf[9]= coldVoltageA*OT/100;

	tmp=(WaterTemp>=pre_temp)?(WaterTemp-pre_temp):(0);
	SEND_BUF[9]=(tmp>253)?253:tmp;
	
//	if(0)
//		SEND_BUF[10]|=1;
//	if(gDevError&DEV_ERROR_NEEDLE)
//		SEND_BUF[10]|=2;
//	if(gDevError&DEV_ERROR_OVER_TEMP)
//		SEND_BUF[10]|=4;
//	if(gDevError&DEV_ERROR_FILL_H2O)
//		SEND_BUF[10]|=8;
//	if(eBrewSetup<eBrewSetup_Single8)
//		SEND_BUF[10]|=16;
	SEND_BUF[10]=err_code;

//extern uint16_t CoolHeaterTicks;
//	SEND_BUF[11]=CoolHeaterTicks/100;	//bak_send_buf[11]= ASOstart/100;

	switch(eXbUartErrCodeAtByte11)
	{
		case eXbUartErrCodeAtByte11_200:	SEND_BUF[11]=200;break;
		case eXbUartErrCodeAtByte11_170:	SEND_BUF[11]=170;break;
		case eXbUartErrCodeAtByte11_130:	SEND_BUF[11]=130;break;
		case eXbUartErrCodeAtByte11_100:	SEND_BUF[11]=100;break;
		default:break;
	}

	SEND_BUF[12]=(eXbUartErrCheck==eXbUartErrCheck_Needle)?(150):((eXbUartErrCheck==eXbUartErrCheck_H2o)?(170):0);		//bak_send_buf[12]=  Step2? 170: 150;
	SEND_BUF[13]=eSingleWorkStep*10;	//bak_send_buf[13]=STAGE*10;
	
	UpdateBuf_lastByte:
	SEND_BUF[14]=0xfe;
	return true;
}
static void Upload()
{
	if(UpdateBuf())
	XB_UART_SEND(upload_buf,XB_UART_UPLOAD_LEN);
}
void XbUartLoop()
{
	if(bXbUartUpload)
	{
		bXbUartUpload=false;
		Upload();
	}
}


#endif