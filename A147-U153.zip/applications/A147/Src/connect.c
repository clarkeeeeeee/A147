#include "connect.h"
#include "ack.h"
#include "top.h"
#include "dev.h"
#include "single.h"
#include "metrics.h"


extern ACKLifecycleState_t ACK_LifecycleState;

extern void Alexa_InitiateFactoryReset(void);
extern void Alexa_InitiateUserGuidedSetup(void);
extern void Alexa_SendChangeReportDueToLocalControl(void);
uint32_t BeaconTicks=0;

uint32_t Status=2;
uint32_t CurrentTemperature=0;

bool gbModuleInSetupMode=false;

bool gbforceReport=false;

uint32_t AutoReportDelay=0;

static void UpdateStatus()
{
//	if(!gbPower)
//		Status=0;
//	if(gbLowWater)
//		Status=5;
//	else if(HeatintRetStatus())
//		Status=2;
//	else if(HeatintRetHeatingDone() || gbReadyStatus)
//		Status=3;
//	else if(KeepWarmRetStatus())
//		Status=4;
//	else
//		Status=1;
}

#define AUTO_REPORT_DELAY		3000


eDevStatus_t eDevStatus_Pre;
eBrewStrength_t eBrewStrength_Pre;
eTimeSinceBrew_t eTimeSinceBrew_Pre;
eBrewSetup_t eBrewSetup_Pre;
uint8_t CleaningRequired;
ePowerSaver_t ePowerSaver_Pre;
eTimeSinceBrew_t eTimeSinceBrew_Pre;
eCoffeeFreshness_t eCoffeeFreshness_Pre;


eDevStatus_t DevStatusFromConn;

static eDevStatus_t get_dev_status_now()
{
	if(eDevStatus<=eDevStatus_NotReadyToBrew)
	{
		if(eBrewSetup<eBrewSetup_Single8)
			return eDevStatus_NotReadyToBrew;
		return SingleCoffeeReady?eDevStatus_CoffeeReady:eDevStatus_NotReadyToBrew;
	}
	return eDevStatus;
}

static void AutoReport(bool reload)
{
	static bool power=false;
	static bool report=false;
	uint8_t clean;
	
	clean=((gCleaningRequired==CLEANING_REQUIRED_YES) || (gSingleCleaningRequired==CLEANING_REQUIRED_YES))?CLEANING_REQUIRED_YES:CLEANING_REQUIRED_NO;
	
	DevStatusFromConn=get_dev_status_now();
	
	if(reload)
	{
		report=false;
		AutoReportDelay=AUTO_REPORT_DELAY;
		goto AutoReport_Reload;
	}
	
	if(AutoReportDelay)
		return;
	
	if(gbforceReport)
	{
		gbforceReport=false;
		goto AutoReport_Reload;
	}
	
	if(power!=gbPower)
		goto AutoReport_Reload;
	if(eDevStatus_Pre!=DevStatusFromConn)
		goto AutoReport_Reload;
	if(eBrewStrength_Pre!=eBrewStrength)
		goto AutoReport_Reload;
	if(eTimeSinceBrew_Pre!=eTimeSinceBrew)
		goto AutoReport_Reload;
	if(eBrewSetup_Pre!=eBrewSetup)
		goto AutoReport_Reload;
	if(CleaningRequired!=clean)
		goto AutoReport_Reload;
	if(ePowerSaver_Pre!=ePowerSaver)
		goto AutoReport_Reload;
	if(eTimeSinceBrew_Pre!=eTimeSinceBrew)
		goto AutoReport_Reload;
	if(eCoffeeFreshness_Pre!=eCoffeeFreshness)
		goto AutoReport_Reload;
	
	goto AutoReport_Ex;
	
	AutoReport_Reload:
	report=true;
	
	{
		power=gbPower;
		eDevStatus_Pre=DevStatusFromConn;
		eBrewStrength_Pre=eBrewStrength;
		eTimeSinceBrew_Pre=eTimeSinceBrew;
		eBrewSetup_Pre=eBrewSetup;
		CleaningRequired=clean;
		ePowerSaver_Pre=ePowerSaver;
		eTimeSinceBrew_Pre=eTimeSinceBrew;
		eCoffeeFreshness_Pre=eCoffeeFreshness;
		return;
	}
	
	AutoReport_Ex:
	{
		if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		{
			if(!AutoReportDelay)
				AutoReportDelay=1000;
			return;
		}
			
		if(report && !AutoReportDelay)
		{
			report=false;
			Alexa_SendChangeReportDueToLocalControl();
			AutoReportDelay=AUTO_REPORT_DELAY;
			if(MetricChangeRepoerCounts<200000)
				MetricChangeRepoerCounts++;
		}
	}
}

void Conn_Handle()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
		gbModuleInSetupMode=true;
	else
		gbModuleInSetupMode=false;
	
	AutoReport(false);
}

bool Conn_ModuleRegistered()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)// || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
		return true;
	return false;
}
static void ClrBeaconTicks()
{
	BeaconTicks=0;
}
void Conn_StartUgs()
{
	Alexa_InitiateUserGuidedSetup();
	ClrBeaconTicks();
}
void Conn_StartFrs()
{
	Alexa_InitiateFactoryReset();
	ClrBeaconTicks();
}


void Conn_ForTmrInt()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
	{
		if(++BeaconTicks>=ACK_LIFECYCLE_IN_SETUP_MODE_OT_TIME)
			gbModuleInSetupMode=false;
	}
	
	if(AutoReportDelay)
		AutoReportDelay--;
}








