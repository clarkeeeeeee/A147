#include "data_save.h"
#include "data_flash.h"
#include "dev.h"
#include "connect.h"
#include "fmc.h"
#include "ack_m031_ota.h"
#include "metrics.h"
#include "single.h"

#define DATA_SAVE_HEAD		202210261
#define DATA_SAVE_DELAY		3000

#define EEPROM_LEN				8
#define EEPROM_LEN_BYTE			(EEPROM_LEN*4)
#define EEPROM_ADDR				ACK_NUMICRO_EEPROM_START

uint32_t Save[EEPROM_LEN]={DATA_SAVE_HEAD};
uint32_t Read[EEPROM_LEN]={};
uint32_t Read2[EEPROM_LEN]={};
	
uint32_t DataSaveDelay=0;
	
	
uint32_t EepromAddr=EEPROM_ADDR;

static void UpdateData(uint32_t *src)
{
	uint32_t tmp;
	
	tmp=*src;
	
	Metrics__carafe_relay_cycle_counts=*(src+2);

	tmp=*(src+3);
	if((tmp&0xaa000000)==0xaa000000)
	{
		WaterHighestTemp=(tmp&0xff);
		HeaterHighestTemp=((tmp&0xff00)>>8);
		#if C_PRINT
		printf("%s WaterHighestTemp=[%d]\r\n",__func__,WaterHighestTemp);
		printf("%s HeaterHighestTemp=[%d]\r\n",__func__,HeaterHighestTemp);
		#endif
	}
	

	SingleCounts=*(src+4);
	CarafeCounts=*(src+5);
	OverTempProtectCounts=*(src+6);
	Metrics__single_relay_cycle_counts=*(src+0);
	
	#if C_PRINT
	printf("%s OverTempProtectCounts=[%d]\r\n",__func__,OverTempProtectCounts);
	#endif
}
static void UpdateSave(uint32_t *save)
{
	uint32_t tmp;
	
	*(save+2)=Metrics__carafe_relay_cycle_counts;
	
	
	
	tmp=HeaterHighestTemp;
	tmp<<=8;
	tmp+=WaterHighestTemp;
	tmp+=0xaa000000;
	*(save+3)=tmp;
	
	
	
	*(save+4)=SingleCounts;
	*(save+5)=CarafeCounts;
	*(save+6)=OverTempProtectCounts;
	*(save+0)=Metrics__single_relay_cycle_counts;
}




uint32_t read_test[16];

void DataSave_Read()
{
	uint32_t i=0;
	uint32_t tab_idx=0;
	
//	DataFlash_Read(EEPROM_ADDR,read_test,16);
	
	for(i=0;i<ACK_NUMICRO_EEPROM_SIZE;i+=EEPROM_LEN_BYTE)
	{
		DataFlash_Read(EEPROM_ADDR+i,Read,EEPROM_LEN);	
		
		if(Read[0]==DATA_SAVE_HEAD)
		{
			for(tab_idx=0;tab_idx<EEPROM_LEN;tab_idx++)
				Read2[tab_idx]=Read[tab_idx];
			if(i==(ACK_NUMICRO_EEPROM_SIZE-EEPROM_LEN_BYTE))
				goto ReadSucc;
		}
		else
		{
			if(i==0)
				return;
			EepromAddr+=(i);
			goto ReadSucc;
		}
	}
	
	ReadSucc:
	if(Read2[0]==DATA_SAVE_HEAD)
	{
		UpdateData(&Read2[1]);
		DataSave_Scan(true);
	}
	
	
}


int32_t Write_Eeprom()
{
	int32_t ret;
	
	ret=DataFlash_Save(EepromAddr,Save,EEPROM_LEN);
	EepromAddr+=EEPROM_LEN_BYTE;
	if(EepromAddr>=(EEPROM_ADDR+ACK_NUMICRO_EEPROM_SIZE))
		EepromAddr=EEPROM_ADDR;
	#if C_PRINT
	printf("Next EepromAddr is [0x%x]!\n", EepromAddr);
	#endif
	return ret;
}
void DataSave_Scan(bool update)
{
	static uint8_t tmp[6];
	static bool save=false;
	static uint32_t Kettle_heater_life;
	static uint32_t carafe_relay_cycle;
	static uint32_t single_relay_cycle;
	static uint16_t single_cup_fm_counts_unit;
	
	static uint32_t carafe_counts;
	static uint32_t single_counts;
	static uint16_t over_temp_protect_counts;
	
	if(update)
	{
		goto DataSave_Scan_update_static;
	}
	
	if(carafe_relay_cycle!=Metrics__carafe_relay_cycle_counts\
		|| single_relay_cycle!=Metrics__single_relay_cycle_counts\
		|| single_cup_fm_counts_unit!=SingleCupFmCountsUnit\
		|| carafe_counts!=CarafeCounts\
		|| single_counts!=SingleCounts\
		|| over_temp_protect_counts!=OverTempProtectCounts\
		|| gbHighestTempUpdated\
		)
	{
		save=true;
		DataSaveDelay=DATA_SAVE_DELAY;
		gbHighestTempUpdated=false;
	}
	
	DataSave_Scan_update_static:
	tmp[0]=eBrewStrength;
	carafe_relay_cycle=Metrics__carafe_relay_cycle_counts;
	single_relay_cycle=Metrics__single_relay_cycle_counts;
	single_cup_fm_counts_unit=SingleCupFmCountsUnit;
	carafe_counts=CarafeCounts;
	single_counts=SingleCounts;
	over_temp_protect_counts=OverTempProtectCounts;
	
	if(save && !DataSaveDelay)
	{
		UpdateSave(&Save[1]);
		
		if(Write_Eeprom()==-1)
		{
			DataSaveDelay=DATA_SAVE_DELAY;
			return;
		}
		save=false;
	}
}

void DataSave_HandleForTmrInt()
{
	if(DataSaveDelay)
		DataSaveDelay--;
}










