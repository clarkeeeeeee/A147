#include "board.h"
#include "port.h"
#include "timer_process.h"

#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "led.h"
#include "connect.h"
#include "data_save.h"
#include "lcd.h"
#include "time.h"
#include "brew.h"
#include "metrics.h"
#include "xw_touch.h"
#include "top.h"
#include "single.h"

#include "adc_ex.h"

#include "my_rtc.h"

static uint8_t TimerUsTicker;
static uint8_t TimerMsTicker;


sFlip_t sFlip;
static void FlipHandle()
{
	if(++sFlip.Flip_1s_counts>=100)
	{
		sFlip.Flip_1s_counts=0;
		sFlip.sFlip_1s=!sFlip.sFlip_1s;
	}
	if(++sFlip.Flip_250ms_counts>=25)
	{
		sFlip.Flip_250ms_counts=0;
		sFlip.sFlip_250ms=!sFlip.sFlip_250ms;
	}
	if(++sFlip.Flip_500ms_counts>=50)
	{
		sFlip.Flip_500ms_counts=0;
		sFlip.sFlip_500ms=!sFlip.sFlip_500ms;
	}
	
	if(gbKeyUgsEn)
	{
		if(++sFlip.Flip_ticks_for_ugs>=100)
		{
			sFlip.Flip_ticks_for_ugs=0;
		}
		if(sFlip.Flip_ticks_for_ugs<=10 || (sFlip.Flip_ticks_for_ugs>20 && sFlip.Flip_ticks_for_ugs<=30))
			sFlip.ugs_led_on=true;
		else
			sFlip.ugs_led_on=false;
	}
}

void Timer_0_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 20000); // 100000Hz = 0.00001s = 0.01ms = 10us

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER0);
    NVIC_EnableIRQ(TMR0_IRQn);
	NVIC_SetPriority(TMR0_IRQn,0);

    /* Start Timer 0 */
    TIMER_Start(TIMER0);
}

void TMR0_IRQHandler(void)
{
	TIMER_ClearIntFlag(TIMER0);
	
	LedScan();
	SingleMtDrive();
	
	
		
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER0);
}

void Timer_2_Init(void)
{
	/* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER2, TIMER_PERIODIC_MODE, 10000); // 1000Hz  = 1ms

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER2);
    NVIC_EnableIRQ(TMR2_IRQn);
	
	NVIC_SetPriority(TMR2_IRQn,1);

    /* Start Timer 0 */
    TIMER_Start(TIMER2);
}
void TMR2_IRQHandler(void)
{
	XwTouchHandle();
	
//	SingleMtDrive();
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER2);
}


uint16_t Timer1IntTimeMs=0;
uint16_t Timer1IntFreq=1000;

void Timer_1_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER1, TIMER_PERIODIC_MODE, Timer1IntFreq); // 1000Hz  = 1ms
	Timer1IntTimeMs=1000/Timer1IntFreq;

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER1);
    NVIC_EnableIRQ(TMR1_IRQn);
	
	NVIC_SetPriority(TMR1_IRQn,1);

    /* Start Timer 0 */
    TIMER_Start(TIMER1);
}

extern uint16_t AckDelay;
extern int32_t gUgsWaitCounts;
extern int16_t PreCountsToUgs;
#if FM_DEBUG
void FmGenerate()
{
	static uint16_t ticks=0;
	
	if(++ticks>=10)
	{
		ticks=0;
//		if(gbFmDebug_SingleErrCheckNeedle)
//			PF3=!PF3;
//		PF2=!PF2;
	}
}
#endif

#if XB_UART
#include "xb_uart.h"
#endif
void TMR1_IRQHandler(void)
{
    static uint32_t timer1_sec = 1,msec = 0, min_timer=0, T_200ms=0;
    static uint16_t tmr1_int_counts=0;
	
	#if XB_UART
	XbUartFromIsr();
	#endif
	
	#if FM_DEBUG
	FmGenerate();
	#endif

	#if 0//C_PRINT
	static uint16_t print_ticks=0;
	static uint16_t print_steps=0;
	if(++print_ticks>=1000)
	{
		print_ticks=0;
		printf("\n %s system run %d ",__func__,print_steps++);
	}
	#endif
	
	if(++tmr1_int_counts>=10)
		tmr1_int_counts=0;
	
	switch(tmr1_int_counts)
	{
		case 0:
			LcdHandle();
			LcdHandleForTmrInt();
			#if LOAD_TEST
			ResetAckModual();
			#endif
		break;
		
		case 1:
			KeyHandle();
		break;
		
		case 2:
			LedHandle();
			LedHandleForTmrInt();
		break;
		
		case 3:
			BrewHandle();
			BrewHandleForTmrInt();
		break;
		
		case 4:
			Update_gbBrewChamberMicroswitch();
			MetricsHandleForTmrInt();
		break;
		
		case 5:
			SelfCheckHandle();
			SelfCheckHandleForTmrInt();
			DevErrorCheck();
		break;
		
		case 6:
			if(sTime.valid)
				sTime.invalid_ticks=0;
			else 
				sTime.invalid_ticks++;
			Update_gbAc();
			Update_gbThermostatOff();
			TimeHandleForTmrInt();
		break;
			
		case 7:
			gUgsWaitCounts--;
			if(PreCountsToUgs>0)
			{
				PreCountsToUgs--;
				if(PreCountsToUgs==0)
				{
					gUgsWaitCounts=1000;
					Conn_StartUgs();
					#if C_PRINT
					printf("\n\n\n>>>>>>>>>>>>>>>>>set sg_lifecyclePending USER_INITIATED_USER_GUIDED_SETUP \n\n\n");
					#endif
				}
			}
		break;
			
		case 8:
			SingleWorkHandle();
		break;
			
		case 9:
			FlipHandle();
			DevHandleForTmrInt();
			#ifdef MCU_LG6AE
			RTC_handle();
			#endif
			HighestTempCheck();
			TimeRtcRun();
			CheckAcHz();
		break;
		
		default:
			break;
	}
	
	AdcHandle();
	
	TimeHandleForTmrInt();
	
    TimerMsTicker++;
	
	if(AckDelay)
		AckDelay--;

	
	
	Conn_ForTmrInt();
	DataSave_HandleForTmrInt();
	
	
	
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER1);
    
}

