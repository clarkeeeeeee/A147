#include "brew.h"
#include "dev.h"
#include "metrics.h"

static uint16_t BrewSecondsTotal=0;
static uint16_t BoldSeconds=0;
uint16_t AutoPowerOffDelaySeconds=0;


bool gbBrewRelay=false;

static eBrewStrength_t eBrewStrength_Pre;

uint16_t EsoCounts=0;
uint16_t EsoCounts2_ToClear_gCleaningRequired=0;
bool gbPending_ToClear_gCleaningRequired=false;
uint16_t EsoCheckEnTicks=0;




void clear_eso_pra()
{
	EsoCounts=0;
	EsoCheckEnTicks=0;
//	gbEso_ThermostatOff=false;
//	gCleaningRequired=CLEANING_REQUIRED_NO;
	gCleaningRequiredLcd=CLEANING_REQUIRED_NO;
}

void BrewHandle()
{
	static bool bReloadEsoCheckEnTicks=false;
	static bool bEso_ThermostatOff=false;
	
	static bool bAllowEsoCheck=true;	//
	
	if(eDevStatus<eDevStatus_Brewing || eBrewSetup>=eBrewSetup_Single8)
	{
		BrewSecondsTotal=0;
		AutoPowerOffDelaySeconds=0;
		BoldSeconds=0;
		bEso_ThermostatOff=false;
		gbBrewRelay=false;
		bAllowEsoCheck=true;
		return;
	}
	
	if(eBrewStrength_Pre!=eBrewStrength)
	{
		eBrewStrength_Pre=eBrewStrength;
		BoldSeconds=0;
	}
	
	if(eDevStatus==eDevStatus_Brewing)
	{
		if(gbThermostatOff)
		{
			eDevStatus=eDevStatus_CoffeeReady;
//			AutoPowerOffDelaySeconds=0;
			#if C_PRINT
			printf("%s -> eDevStatus= %d\r\n",__func__,eDevStatus);
			#endif
			MetricBrewEnd(eMetrics_EndMethod_ASO);
		}
	}
	if((eDevStatus==eDevStatus_CoffeeReady) || (eDevStatus==eDevStatus_KeepWarm))
	{
		if(gbThermostatOff)
		{
			BrewSecondsTotal=0;
			BoldSeconds=0;
			gbBrewRelay=true;
			if(!bEso_ThermostatOff)
			{
				bEso_ThermostatOff=true;
				#if DEBUG_ESO
				EsoCheckEnTicks=5;
				#else
				EsoCheckEnTicks=30;
				#endif
				bReloadEsoCheckEnTicks=true;
			}
			if(bReloadEsoCheckEnTicks && !EsoCheckEnTicks)
			{
				bReloadEsoCheckEnTicks=false;
				bAllowEsoCheck=false;
				#if C_PRINT
				printf("EsoCounts2_ToClear_gCleaningRequired-->>>>>>>>>>>[%d]\n",EsoCounts2_ToClear_gCleaningRequired);
				#endif
				if(EsoCounts2_ToClear_gCleaningRequired && gbPending_ToClear_gCleaningRequired)
				{
					EsoCounts2_ToClear_gCleaningRequired--;
					if(!EsoCounts2_ToClear_gCleaningRequired)
					{
						clear_eso_pra();
						gCleaningRequired=CLEANING_REQUIRED_NO;
						gbPending_ToClear_gCleaningRequired=false;
					}
				}
			}
			return;
		}
	}
	
	bEso_ThermostatOff=false;
	if(EsoCheckEnTicks && bAllowEsoCheck)
	{
		EsoCheckEnTicks=0;
		EsoCounts++;
//		if(EsoCounts2_ToClear_gCleaningRequired<2)
			EsoCounts2_ToClear_gCleaningRequired=1;
		gbMetric__Eso=true;
		MetricEsoCounts=EsoCounts;
		
		eDevStatus=eDevStatus_Brewing;
		BrewSecondsTotal=0;
		BoldSeconds=0;
		#if C_PRINT
		printf("%s -> eDevStatus= %d\r\n",__func__,eDevStatus);
		#endif
		
		if(EsoCounts>=4)
		{
			if(gCleaningRequiredLcd!=CLEANING_REQUIRED_YES)
			{
				gCleaningRequiredLcd=gCleaningRequired=CLEANING_REQUIRED_YES;
				gbMetric__Clean=true;
			}
			if(EsoCounts==ESO_COUNTS)
			{
				DevPowerOff();
				MetricBrewEnd(eMetrics_EndMethod_Error);
			}
		}
		#if C_PRINT
		printf("\n ...............EsoCounts = %d \n",EsoCounts);
		#endif
	}
	switch(eBrewStrength)
	{
		case eBrewStrength_Regular:
			gbBrewRelay=true;
		break;
		case eBrewStrength_Bold:
			if(BrewSecondsTotal<BOLD_RELAY_CONTINUOUSLY || BoldSeconds>=BOLD_RELAY_CYCLING_TOTAL)
			{
				gbBrewRelay=true;
				break;
			}
			if((BoldSeconds%(BOLD_RELAY_CYCLING_UNIT*2))<BOLD_RELAY_CYCLING_UNIT)
				gbBrewRelay=false;
			else
				gbBrewRelay=true;
		break;
		default:
			break;
	}
}

uint16_t TimeSinceBrew=0;
static void TimeSinceBrewHandle()
{
	static eDevStatus_t status=eDevStatus_Other;
	
	if(status!=eDevStatus)
	{
		status=eDevStatus;
//		if(!(status==eDevStatus_CoffeeReady || status==eDevStatus_KeepWarm))
		if(eDevStatus<=eDevStatus_Brewing)
			TimeSinceBrew=0;
	}
//	if(status==eDevStatus_CoffeeReady || status==eDevStatus_KeepWarm)
	if(eDevStatus>eDevStatus_Brewing)
		TimeSinceBrew++;
	UpdateTimeSinceBrew(TimeSinceBrew);
	UpdateCoffeeFreshness();
}
#if FM_DEBUG
#define KEEP_WARM_HOUR		(60)
#else
#define KEEP_WARM_HOUR		(60*60)
#endif
void BrewHandleForTmrInt()
{
	static uint8_t ticks=0;
	
	if(++ticks>=100)		//1s
	{
		ticks=0;
		
		TimeSinceBrewHandle();
		
		if(EsoCheckEnTicks)
			EsoCheckEnTicks--;
		
		if(eDevStatus>=eDevStatus_Brewing && !gbThermostatOff)
		{
			BrewSecondsTotal++;
			if(BrewSecondsTotal>=BOLD_RELAY_CONTINUOUSLY && eBrewStrength==eBrewStrength_Bold)
				BoldSeconds++;
		}
		
		static uint16_t ready_ticks=0;
		
		if(eDevStatus>=eDevStatus_Brewing && eBrewSetup==eBrewSetup_Carafe)
		{
			if(eDevStatus>=eDevStatus_CoffeeReady)
			{
				ready_ticks++;
				if(ready_ticks>=COFFEE_READY_SECONDS)
					eDevStatus=eDevStatus_KeepWarm;
			}
			
			AutoPowerOffDelaySeconds++;
			switch(eCarafeKeepWarm)
			{
				case eCarafeKeepWarm_1h:
					if(AutoPowerOffDelaySeconds>=(1*KEEP_WARM_HOUR))
					{
						goto KeepWarmOver;
					}
				break;
				case eCarafeKeepWarm_2h:
					if(AutoPowerOffDelaySeconds>=(2*KEEP_WARM_HOUR))
					{
						goto KeepWarmOver;
					}
				break;
				case eCarafeKeepWarm_3h:
					if(AutoPowerOffDelaySeconds>=(3*KEEP_WARM_HOUR))
					{
						goto KeepWarmOver;
					}
				break;
				case eCarafeKeepWarm_4h:
					if(AutoPowerOffDelaySeconds>=(4*KEEP_WARM_HOUR))
					{
						goto KeepWarmOver;
					}
				break;
				default:
				break;
			}
			return;
			KeepWarmOver:
			DevPowerOff();
//			MetricBrewEnd(eMetrics_EndMethod_ASO);
			#if C_PRINT
			printf("\r\n %s -> KeepWarmOver AutoPowerOffDelaySeconds=%d \r\n",__func__,AutoPowerOffDelaySeconds);
			#endif
		}
		else
			ready_ticks=0;
	}
}










