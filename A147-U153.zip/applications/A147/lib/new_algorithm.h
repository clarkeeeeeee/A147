#ifndef _NEW_ALGORITHM_H_
#define _NEW_ALGORITHM_H_

#include <stdint.h>
#include <stdbool.h>

#define NEW_ALGORITHM_START		70
#define SINGLE_MT_PERIOD		200
#define SINGLE_MT_DUTY_MAX	(90*SINGLE_MT_PERIOD/100)
#define SINGLE_MT_DUTY_MIN	(18*SINGLE_MT_PERIOD/100)

void NewAlgorithmInit(float,signed short int *);
bool NewAlgorithm(float,float);

extern float NewAlgorithm__Duty;



#endif



