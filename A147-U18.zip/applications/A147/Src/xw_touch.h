#ifndef _XW_TOUCH_H_
#define _XW_TOUCH_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "top.h"


typedef enum
{
	eXwTouchComm_Idle,
	eXwTouchComm_Start,
	eXwTouchComm_Addr1_1,
	eXwTouchComm_Addr1_2,
	eXwTouchComm_Addr2_1,
	eXwTouchComm_Addr2_2,
	eXwTouchComm_Addr3_1,
	eXwTouchComm_Addr3_2,
	eXwTouchComm_Addr4_1,
	eXwTouchComm_Addr4_2,
	eXwTouchComm_Addr5_1,
	eXwTouchComm_Addr5_2,
	eXwTouchComm_Addr6_1,
	eXwTouchComm_Addr6_2,
	eXwTouchComm_Addr7_1,
	eXwTouchComm_Addr7_2,
	eXwTouchComm_Addr8_1,
	eXwTouchComm_Addr8_2,
	eXwTouchComm_GetAck1,
	eXwTouchComm_GetAck2,
	eXwTouchComm_Data1_1,
	eXwTouchComm_Data1_2,
	eXwTouchComm_Data2_1,
	eXwTouchComm_Data2_2,
	eXwTouchComm_Data3_1,
	eXwTouchComm_Data3_2,
	eXwTouchComm_Data4_1,
	eXwTouchComm_Data4_2,
	eXwTouchComm_Data5_1,
	eXwTouchComm_Data5_2,
	eXwTouchComm_Data6_1,
	eXwTouchComm_Data6_2,
	eXwTouchComm_Data7_1,
	eXwTouchComm_Data7_2,
	eXwTouchComm_Data8_1,
	eXwTouchComm_Data8_2,
	eXwTouchComm_Data9_1,
	eXwTouchComm_Data9_2,
	eXwTouchComm_Data10_1,
	eXwTouchComm_Data10_2,
	eXwTouchComm_Data11_1,
	eXwTouchComm_Data11_2,
	eXwTouchComm_Data12_1,
	eXwTouchComm_Data12_2,
	eXwTouchComm_Data13_1,
	eXwTouchComm_Data13_2,
	eXwTouchComm_Data14_1,
	eXwTouchComm_Data14_2,
	eXwTouchComm_Data15_1,
	eXwTouchComm_Data15_2,
	eXwTouchComm_Data16_1,
	eXwTouchComm_Data16_2,
	eXwTouchComm_SendNoAck,
}eXwTouchComm_t;

typedef struct
{
	eXwTouchComm_t eXwTouchComm;
	bool bAnyKey;
	unsigned int KeyMsk;
}sXwTouch_t;
extern sXwTouch_t sXwTouch;

void XwTouchHandle();
u16 XwTouchGet();

#endif



