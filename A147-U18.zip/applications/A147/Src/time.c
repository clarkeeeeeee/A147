#include "time.h"
#include "ack.h"
#include "my_rtc.h"

sTime_t sTime={12,0,0,true};

bool gbTimeShow=true;

bool bTimeForceUpdate=false;
	
static bool TimeReloadCfgTicks()
{
	if(!sTime.cfg_ticks)
	{
		sTime.cfg_ticks=3000;
		return true;
	}
	sTime.cfg_ticks=3000;
	return false;
}
bool TimeGetCfg()
{
	return sTime.cfg_idx;
}
void TimeSetCfg()
{
	sTime.cfg_idx++;
	if(sTime.cfg_idx<3)
		TimeReloadCfgTicks();
	else
	{
		sTime.cfg_idx=0;
		sTime.valid=1;
		gbTimeShow=true;
		sTime.invalid_ticks=0;
		sTime.ss=0;
		
		#ifdef MCU_LG6AE
		RTC_setTime(sTime.hh,sTime.mm,sTime.ss,sTime.am);
		#endif
		
//		if(sTime.hh==12)
//			sTime.am=!sTime.am;
	}
}

void TimeHandleForTmrInt()
{
	if(sTime.cfg_ticks)
	{
		sTime.cfg_ticks--;
		if(!sTime.cfg_ticks)
		{
			TimeSetCfg();
		}
	}
}


#ifdef MCU_LG6AE
void TimeRtcRun_fromMyRtc(int16_t hh,int16_t mm,int16_t ss,bool am)
{
	if(!sTime.valid || sTime.cfg_idx>0)
		return;
	
	sTime.hh=hh;
	sTime.mm=mm;
	sTime.ss=ss;
	sTime.am=am;
}
#endif

#include "dev.h"
void TimeRtcRun()
{
	static uint16_t time_run_sec_ticks=0;
	static uint16_t DelaySet_bTimeForceUpdate=10;
	
	if(!sTime.valid)
		return;
	
	if(sTime.cfg_idx)
		return;//time_run_sec_ticks=0;
	else if(gbUpdateTimeFromAc)//19959)
	{
		gbUpdateTimeFromAc=false;
		if(DelaySet_bTimeForceUpdate)
		{
			DelaySet_bTimeForceUpdate--;
			if(!DelaySet_bTimeForceUpdate)
			{
				DelaySet_bTimeForceUpdate=10;
				bTimeForceUpdate=true;
			}
		}
		
		time_run_sec_ticks=0;
		if(++sTime.ss>=60)
		{
//			printf("\n %s \n", __func__);
			sTime.ss=0;
			if(++sTime.mm>=60)
			{
				sTime.mm=0;
				sTime.hh++;
				if(sTime.hh==12)
					sTime.am=!sTime.am;
				if(sTime.hh==13)
					sTime.hh=1;
			}
		}
		
		#if C_PRINT
		printf("%s %2d:%2d:%2d\n",__func__,sTime.hh,sTime.mm,sTime.ss);
		#endif
		
		if(sTime.am && sTime.hh==2 && sTime.mm==1 && sTime.ss==0)
			bTimeForceUpdate=true;
		if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
			bTimeForceUpdate=true;
	}
}

void TimeUpdateCauseKey()
{
	if(!sTime.cfg_idx)
		return;
	
	if(sTime.cfg_idx==1)
	{
		sTime.hh++;
		if(sTime.hh==12)
			sTime.am=!sTime.am;
		if(sTime.hh>=13)
		{
			sTime.hh=1;
//			sTime.am=!sTime.am;
		}
		TimeReloadCfgTicks();
	}
	if(sTime.cfg_idx==2)
	{
		if(++sTime.mm>59)
			sTime.mm=0;
		TimeReloadCfgTicks();
	}
}

void TimeUpdateCauseInternet(int16_t hh,int16_t mm,int16_t ss)
{
	if(sTime.valid && !bTimeForceUpdate)
		return;
	
	bTimeForceUpdate=false;
	
//	printf("\n\n TimeUpdateCauseInternet  %d-%d-%d \n", hh,mm,ss);
	
	if(hh>=12)
		sTime.am=false;
	else
		sTime.am=true;
	
	if(sTime.am)
	{
		sTime.hh=hh;
	}
	else
	{
		if(hh>12)
			sTime.hh=hh-12;
		else
			sTime.hh=hh;
	}
	
	sTime.mm=mm;
	sTime.ss=ss;
	sTime.valid=1;
	
	#ifdef MCU_LG6AE
	RTC_setTime(sTime.hh,sTime.mm,sTime.ss,sTime.am);
	#endif
}

bool TimeGetCfgDisp()
{
	if((sTime.cfg_ticks%1000)>500 || (sTime.cfg_ticks%1000)==0)
		return true;
	return false;
}






