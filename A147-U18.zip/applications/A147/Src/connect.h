#ifndef _CONNECT_H_
#define _CONNECT_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "dev.h"

extern bool gbModuleInSetupMode;
extern uint32_t Status;
extern uint32_t CurrentTemperature;
extern bool gbforceReport;
extern eDevStatus_t DevStatusFromConn;

void Conn_ForTmrInt();
bool Conn_ModuleRegistered();
void Conn_StartUgs();
void Conn_StartFrs();
void Conn_Handle();
bool ConnRetReadyStatusRemain();


#endif



