#ifndef _DEV_H_
#define _DEV_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

#define CLEANING_REQUIRED_YES		1
#define CLEANING_REQUIRED_NO		2

#define NTC_OC		-1
#define NTC_SC		-2

#define DEV_ERROR_WATER_NTC_OC	(1<<0)
#define DEV_ERROR_WATER_NTC_SC	(1<<1)
#define DEV_ERROR_HEAT_NTC_OC	(1<<2)
#define DEV_ERROR_HEAT_NTC_SC	(1<<3)
#define DEV_ERROR_FILL_H2O		(1<<4)
#define DEV_ERROR_NEEDLE		(1<<5)
#define DEV_ERROR_OVER_TEMP		(1<<6)
#define DEV_ERROR_CLOSE_LID		(1<<7)
#define DEV_ERROR_CLEAN			(1<<8)

#define DEV_ERROR_EC1	(1<<9)
#define DEV_ERROR_EC2	(1<<10)
#define DEV_ERROR_A10	(1<<11)
#define DEV_ERROR_A11	(1<<12)

extern uint16_t gDevError;
extern bool gbUpdateTimeFromAc;


typedef enum{
	eDevStatus_Other,
	eDevStatus_NotReadyToBrew,
	eDevStatus_ReadyToBrew,
	eDevStatus_Brewing,
	eDevStatus_CoffeeReady,
	eDevStatus_KeepWarm,
}eDevStatus_t;
extern eDevStatus_t eDevStatus;

typedef enum
{
	eBrewStrength_Other,
	eBrewStrength_Regular,
	eBrewStrength_Bold,
}eBrewStrength_t;
extern eBrewStrength_t eBrewStrength;
extern eBrewStrength_t eBrewStrength_Carafe;
extern eBrewStrength_t eBrewStrength_Single;

typedef enum
{
	eTimeSinceBrew_Other,
	eTimeSinceBrew_StillBrewing,
	eTimeSinceBrew_LessThan15minutes,
	eTimeSinceBrew_LessThan30minutes,
	eTimeSinceBrew_LessThan1hour,
	eTimeSinceBrew_LessThan90minutes,
	eTimeSinceBrew_LessThan2hour,
	eTimeSinceBrew_LessThan150minutes,
	eTimeSinceBrew_LessThan3hour,
	eTimeSinceBrew_LessThan210minutes,
	eTimeSinceBrew_LessThan4hour,
	eTimeSinceBrew_UnavailableBrewerIsOff,
	eTimeSinceBrew_UnavailableInSingleMode,
	eTimeSinceBrew_UnavailableAsBrewIsInOperation,
}eTimeSinceBrew_t;
extern eTimeSinceBrew_t eTimeSinceBrew;


typedef enum
{
	eBrewSetup_None,
	eBrewSetup_Carafe,
	eBrewSetup_Single8,
	eBrewSetup_Single10,
	eBrewSetup_Single12,
	eBrewSetup_Single14,
}eBrewSetup_t;
extern eBrewSetup_t eBrewSetup;
extern eBrewSetup_t eBrewSetupBkp;

typedef enum
{
	eCarafeKeepWarm_none,
	eCarafeKeepWarm_1h,
	eCarafeKeepWarm_2h,
	eCarafeKeepWarm_3h,
	eCarafeKeepWarm_4h,
}eCarafeKeepWarm_t;
extern eCarafeKeepWarm_t eCarafeKeepWarm;

typedef enum
{
	eCoffeeFreshness_Other,
	eCoffeeFreshness_StillBrewing,
	eCoffeeFreshness_FreshlyBrewed,
	eCoffeeFreshness_Fresh,
	eCoffeeFreshness_Good,
	eCoffeeFreshness_OK,
	eCoffeeFreshness_KindOfOld,
	eCoffeeFreshness_Old,
	eCoffeeFreshness_PrettyOld,
	eCoffeeFreshness_OldAnd_a_BitStale,
	eCoffeeFreshness_OldTimeFor_a_NewPot,
	eCoffeeFreshness_UnavailableBrewerIsOff,
	eCoffeeFreshness_UnavailableInSingleMode,
}eCoffeeFreshness_t;
extern eCoffeeFreshness_t eCoffeeFreshness;

typedef enum
{
	ePowerSaver_none,
	ePowerSaver_economyModeOn,
	ePowerSaver_economyModeOff,
}ePowerSaver_t;
extern ePowerSaver_t ePowerSaver;


extern uint16_t DevAwake;

extern uint8_t 	gCleaningRequired;
extern uint8_t 	gCleaningRequiredLcd;
extern bool 	gbThermostatOff;
extern bool 	gbAcOff;

extern uint32_t CarafeCounts;
extern uint32_t SingleCounts;

extern int16_t 	HeatTemp;
extern float 	WaterTemp;
extern float 	WaterTempForXb;
extern uint16_t PumpCurrentAdcRes;
extern bool 	gbBrewChamberMicroswitch;


extern bool 	gbPower;
extern uint16_t TempSet_Celsius;
extern uint16_t TempSet_Fahrenheit;
extern uint16_t TempNow_Celsius;
extern uint16_t TempNow_Fahrenheit;
extern uint16_t TempNowWithDot_Celsius;
extern uint16_t TempUnit;
extern bool 	gbAckDsnRecived;
extern bool 	gbRelay;
extern uint16_t PreSet;
extern uint16_t TempSet;
extern bool 	gbDevSingleHeatRelay;

extern uint8_t 	HeaterHighestTemp;
extern uint8_t 	WaterHighestTemp;
extern bool 	gbHighestTempUpdated;
void HighestTempCheck();

void DevInit();
void DevTempSet_FahrenheitPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_FahrenheitMinus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusMinus(eKeyStatus_t eKeyStatus);
bool DevReloadTempSetTicks();
bool DevGetTempSetFlashShow();
bool DevGetTempSetShow();
bool DevReloadTempSetTicks();
void DevHandleForTmrInt();
void DevClrTempSetTicks();
void DevHeaterRelay(bool);
bool DevGetTempSetStatus();
void DevHandle();
void UpdateTempSet_CelsiusFromTempSet();
void UpdateTempSet_FahrenheitFromTempSet();
void UpdateTempSet();
void UpdateTempSet_CausePreSet(uint16_t pre_set);
void DevPowerOff();
void DevPowerOn();
void UpdateTimeSinceBrew(uint16_t seconds);
void UpdateCoffeeFreshness();
void Update_gbThermostatOff();
void Update_gbAc();


uint32_t GetFlowmeter();
void UpdateFlowmeter();
void ResetFlowmeter(uint32_t);
uint32_t GetAcZeroCounts();
void UpdateAcZeroCounts();
void ResetAcZeroCounts();
uint32_t GetHeatZeroCounts();
void UpdateHeatZeroCounts();
void ResetHeatZeroCounts();
void Update_gbBrewChamberMicroswitch();
void DevErrorCheck();
void CheckAcHz();

#endif



