/**************************************************************************//**
 * @brief    ACK HMCU platform porting.
 *
 * @note
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "board.h"
#include "port.h"
#include "timer_process.h"
#include "numicro_hal.h"
#include "ack_metrics.h"
#include "ack_user_config.h"

#include "ack_m031_ota.h"

#include "led.h"
#include "key.h"
#include "self_check.h"
#include "dev.h"
#include "top.h"
#include "connect.h"
#include "data_flash.h"
#include "data_save.h"
#include "lcd.h"
#include "metrics.h"
#include "adc_ex.h"
#ifdef MCU_LG6AE
#include "my_rtc.h"
#endif
#if XB_UART
#include "xb_uart.h"
#endif

bool g_bDoUserGuidedSetup;

/* GPIO */
S_GPIODev g_asBoardGpioDev [] =
{
    { .pin = (PinName)ACK_INT , .gpio_type = eGPIO_INPUT_PULL_UP },    //ACK_HW_PIN_HOST_INTERRUPT
    { .pin = (PinName)ACK_EN , .gpio_type = eGPIO_OUTPUT_PUSH_PULL }, //ACK_HW_PIN_MODULE_RESET
};
const int i32BoardMaxGPIONum  = sizeof(g_asBoardGpioDev) / sizeof(g_asBoardGpioDev[0]);

/* User-defined */
/* UART */
#define DEF_UART_BUFLEN_DBG 256
static uint8_t au8UartBuf_DBG[DEF_UART_BUFLEN_DBG];
#define DEF_UART_BUFLEN_ACK 256 //512 
static uint8_t au8UartBuf_ACK[DEF_UART_BUFLEN_ACK];

void platform_ack_irq_handler_rx(void *psUARTDev, E_UART_EVENT eHalUartEvent);
void platform_ack_irq_handler_tx(void *psUARTDev, E_UART_EVENT eHalUartEvent);


S_UARTDev g_asBoardUartDev[] =
{
    { /* UART PORT 0, STDIO UART, Tx/Rx over Nu-Link's VCOM */
        .uart           = UART_0,
        .pin_tx         = (PinName)PB_13,
        .pin_rx         = (PinName)NC,//PB_12,
        .pin_rts        = NC,
        .pin_cts        = NC,
        .pu8BufRx       = &au8UartBuf_DBG[0],
        .u32BufSize     = DEF_UART_BUFLEN_DBG,
		#if XB_UART
        .baudrate       = 9600,
		#else
		.baudrate       = 115200,
		#endif
        .databits       = eUART_DATA_WIDTH_8BIT,
        .flowctrl       = eUART_FLOW_CONTROL_DISABLED,
        .parity         = eUART_NO_PARITY,
        .stopbits       = eUART_STOP_BITS_1
    },
    { /* UART PORT 1, UART TX/RX in UDO IF */
        .uart           = UART_1,
        .pin_tx         = (PinName)PB_3,
        .pin_rx         = (PinName)PB_2,
        .pin_rts        = NC,
        .pin_cts        = NC,
        .pu8BufRx       = &au8UartBuf_ACK[0],
        .u32BufSize     = DEF_UART_BUFLEN_ACK,
        .baudrate       = 115200,
        .databits       = eUART_DATA_WIDTH_8BIT,
        .flowctrl       = eUART_FLOW_CONTROL_DISABLED,
        .parity         = eUART_NO_PARITY,
        .stopbits       = eUART_STOP_BITS_1,
        .irq_handler_tx = platform_ack_irq_handler_tx,
        .irq_handler_rx = platform_ack_irq_handler_rx,
    },
};
const int i32BoardMaxUartNum = sizeof(g_asBoardUartDev) / sizeof(g_asBoardUartDev[0]);

S_CRCDev    g_sCrcDev =
{
    .crc          = CRC_0,
    .eCRCMode     = eCRCMode_CRC32,
    .eCRCAttr     = (eCRCAttr_WDataRVS | eCRCAttr_ChecksumCom | eCRCAttr_ChecksumRVS),
    .eCRCCpuWLen  = eCRCCpuWLen_32,
    .u32SeedValue = 0xffffffff
};

/*
S_PWMDev g_asBoardPwmDev[] =
{
    {
        .pwm       = PWM_0_1,
        .pin       = (PinName)PWM0_CH1, //D9
        .frequency = 10000ul,
        .dutycycle = 0ul,
        .pinpolar_inverse = 0
    },
};
const int i32BoardMaxPwmNum = sizeof(g_asBoardPwmDev) / sizeof(g_asBoardPwmDev[0]);


void pwmdev_init(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxPwmNum; i++)
        HAL_PWM_Initialize(&g_asBoardPwmDev[i]);
}

void pwmdev_deinit(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxPwmNum; i++)
        HAL_PWM_Initialize(&g_asBoardPwmDev[i]);
}
*/


bool UART0_SendChar(uint8_t* dat,uint8_t len)
{
	if(UART_Write(UART0, dat, len) > 0)
        return true;
    return false;
}

#if 0
uint8_t TxDataBuffer[4] = {0};

bool UART2_SendCmd_Set_EEPROM(void)
{
	TxDataBuffer[0] = 0x5A;
	TxDataBuffer[1] = 0xAA;
	TxDataBuffer[2] = 0x00;
	TxDataBuffer[3] = gFan;

	if(UART_Write(UART2, TxDataBuffer, sizeof(TxDataBuffer)/sizeof(uint8_t)) > 0)
        return true;

    return false;
}

bool UART2_SendCmd_Get_EEPROM(void)
{
	TxDataBuffer[0] = 0x5A;
	TxDataBuffer[1] = 0xAA;
	TxDataBuffer[2] = 0x01;
	TxDataBuffer[3] = 0;

	if(UART_Write(UART2, TxDataBuffer, sizeof(TxDataBuffer)/sizeof(uint8_t)) > 0)
        return true;

    return false;
}


/*---------------------------------------------------------------------------------------------------------*/
/* Global variables                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
#define ReceiveDataCnt   20
volatile uint8_t ReceiveDataBuffer[ReceiveDataCnt]={0};
volatile uint8_t *DataBuffer1=ReceiveDataBuffer;
volatile uint8_t *DataBuffer2=ReceiveDataBuffer;
uint8_t SysReceiveDataBuffer[12]={0};

uint16_t u16UartKeyValue=0;
uint8_t KeyCnt_0=0, KeyCnt_1=0;


extern void UartQuePush(u8 dat);


void UART_TEST_HANDLE(void)
{
    uint8_t u8InChar = 0xFF;
	
	uint8_t recive;

    if (UART_GET_INT_FLAG(UART2,UART_INTSTS_RDAIF_Msk/*UART_INTSTS_RDAINT_Msk*/))
    {
        //printf("\nInput:");

        /* Get all the input characters */
        while(UART_IS_RX_READY(UART2))
        {
            /* Get the character from UART Buffer */
			
			recive=UART_READ(UART2);
			
			UartQuePush(recive);

			//printf("[*DataBuffer1] = %02x \n", *DataBuffer1);
        }
        
        //printf("\nTransmission Test:\n");
        
    }


    if(UART2->FIFOSTS & (UART_FIFOSTS_BIF_Msk | UART_FIFOSTS_FEF_Msk | UART_FIFOSTS_PEF_Msk | UART_FIFOSTS_RXOVIF_Msk))
    {
        UART_ClearIntFlag(UART2, (UART_INTSTS_RLSINT_Msk));
    }
}

void UART02_IRQHandler(void)
{
    UART_TEST_HANDLE();
}



uint16_t Get_UartKey_Value(void)
{
    uint16_t Key_Value = KEY_NULL;

    if(KeyCnt_0!=KeyCnt_1)
    {
        Key_Value = u16UartKeyValue;
        KeyCnt_1 = (KeyCnt_1+1) & 0x07;
    }
    else
        Key_Value = KEY_NULL;

	//if(Key_Value != KEY_NULL)
		//printf("\n~~~ Key_Value = 0x%04x~~~\n", Key_Value);
		
    return Key_Value;
}


#endif

void gpiodev_init(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxGPIONum; i++)
        HAL_GPIO_Initialize(&g_asBoardGpioDev[i]);
}

void gpiodev_deinit(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxGPIONum; i++)
        HAL_GPIO_Finalize(&g_asBoardGpioDev[i]);
}

void uartdev_init(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxUartNum; i++)
        HAL_UART_Initialize(&g_asBoardUartDev[i]);
}

void uartdev_deinit(void)
{
    int i = 0;
    for (i = 0; i < i32BoardMaxUartNum; i++)
        HAL_UART_Finalize(&g_asBoardUartDev[i]);
}

void crc32dev_init(void)
{
    HAL_CRC_Initialize(&g_sCrcDev);
}

void crc32dev_deinit(void)
{
    HAL_CRC_Finalize(&g_sCrcDev);
}

void peripheral_init(void)
{
	//#ifdef  ALEXA
    uartdev_init();
	//#endif
    crc32dev_init();
    gpiodev_init();
}

void peripheral_deinit(void)
{
    gpiodev_deinit();
    crc32dev_deinit();
    uartdev_deinit();
}

extern void ACK_ResetConnectivityModule(void);
void UserEventLoop(void)
{
//	LedHandle();
//	SelfCheckHandle();
//	DevHandle();
	Conn_Handle();
	DataSave_Scan(false);
	
	MetricsHandle();
	
	#if XB_UART
	XbUartLoop();
	#endif
	
	if(gbUgsNoOpThenReboot)
	{
		gbUgsNoOpThenReboot=false;
		ACK_ResetConnectivityModule();
	}
}


void mcu_init(void)
{
    HAL_SYS_Init();  
	
    peripheral_init();
	
	
//WDT	
	/* To check if system has been reset by WDT time-out reset or not */
    if(WDT_GET_RESET_FLAG() == 1)
    {
        WDT_CLEAR_RESET_FLAG();
        printf("*** System has been reset by WDT time-out event ***\n\n");
    }
	
	
	WDT_CLEAR_RESET_FLAG();
	WDT_RESET_COUNTER();
	/* Configure WDT settings and start WDT counting */
    WDT_Open(WDT_TIMEOUT_2POW18, WDT_RESET_DELAY_18CLK, TRUE, FALSE);
	
	
    Port_Init();
	LcdPortInit();
	KeyInit();
	AdcInit();
	
	DataFlash_Init();
	DataSave_Read();
	
    LedInit();
	
	#ifdef MCU_LG6AE
	MyRtcInit();
	#endif
	
	
    Timer_0_Init();
    Timer_1_Init();
	Timer_2_Init();
	
    printf("\n\nCPU @ %dHz\n", SystemCoreClock);
}

