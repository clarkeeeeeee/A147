#ifndef _TOP_H_
#define _TOP_H_

#define ALEXA
//#define MCU_LG6AE



#define XB_UART					1

#define FIRMWARE_VERSION		18
#define FIRMWARE_VERSION_MINOR	0

#define IGNORE_MICRO_SWITCH		0

#define CHANGE_STRENGTH_WHEN_BREWING_AT_CARAFE		0


#ifdef MCU_LG6AE
#define HARDWARE_VERSION		2
#else
#define HARDWARE_VERSION		1
#endif

#define PUMP_CURRENT_ADC_RES_MAX		400

#define SINGLE_COUNTS_CLEAN				100

//for debug
#define AC_ZERO_SHOW	0
#define CURRENT_SHOW	0
#define DUTY_SHOW		0
#define TEMP_SHOW		0
#define FM_SHOW			0
#define LED_DISPLAY_ALL		0

#define FM_DEBUG			0
#define MT_IO_WRONG			0
#define PCB_VER				3

#if XB_UART
#define C_PRINT				0
#else
#define C_PRINT				1
#endif


#define SINGLE_MT_PERIOD		200
#define SINGLE_MT_DUTY_MAX	(90*SINGLE_MT_PERIOD/100)

#if FIRMWARE_VERSION>10
#define SINGLE_MT_DUTY_MIN	(18*SINGLE_MT_PERIOD/100)
#else
#define SINGLE_MT_DUTY_MIN	(16*SINGLE_MT_PERIOD/100)
#endif







#define ADD_TO_CORE		1			//1:add my code to core		0:delete my code to core

#define DEBUG_ESO		0

#if XB_UART
#define TOP_DEBUG_PORT   NC
#else
#define TOP_DEBUG_PORT   UART0
#endif

#define	LED_DUTY_REF	28
#define LED_DUTY_ON		LED_DUTY_REF
#define LED_DUTY_OFF	0
#define LED_DUTY_DIM	3

//#define	LED_DUTY_REF	20
//#define LED_DUTY_ON		10
//#define LED_DUTY_OFF	0
//#define LED_DUTY_DIM	1


//#define KEY_UPDATE_TEMP_EN
//#define LED_IS_RELAY_STATUS

#define TEMP_SET_TICKS					(60*1000)
#define TEMP_SET_TICKS_POWER_ON			(4*1000)
#define ACK_LIFECYCLE_IN_SETUP_MODE_OT_TIME		(5*60*1000)



#define DEFAULT_TEMP_CELSIUS_SET		100
#define DEFAULT_TEMP_FAHRENHEIT_SET		212

#define TEMP_CELSIUS_SET_MAX			100
#define TEMP_CELSIUS_SET_MIN			15
#define TEMP_FAHRENHEIT_SET_MAX			212
#define TEMP_FAHRENHEIT_SET_MIN			100

#define DEFAULT_KEEP_WARM_MINUTES		(3)

#define CLEAR_HOT_TEMP_FAHRENHEIT		158

#define KEEP_WARM_MINUTES__TOTAL_MS		(60*1000)
#define LOW_WATER_SHOW					(10*60*1000)
#define READY_STATUS_REMAIN				(1*20*1000)

#define POWER_ON_ALL_SHOW_TIME			100



#define BOLD_RELAY_CONTINUOUSLY			60
#define BOLD_RELAY_CYCLING_UNIT			30
#define BOLD_RELAY_CYCLING_TOTAL		450		//20221027

//#define BOLD_RELAY_CONTINUOUSLY			10
//#define BOLD_RELAY_CYCLING_UNIT			3
//#define BOLD_RELAY_CYCLING_TOTAL		30

#define AUTO_POWER_OFF_DELAY_SECONDS	(2*60*60)
#define COFFEE_READY_SECONDS			(20*60)
#define ESO_COUNTS		5

//#define AUTO_POWER_OFF_DELAY_SECONDS	(2*60)
//#define COFFEE_READY_SECONDS			(30)


#define DEV_AWAKE		(10*60*100)




//no modify

#define u8 	uint8_t
#define u16 uint16_t
#define u32 uint32_t

//


#endif



