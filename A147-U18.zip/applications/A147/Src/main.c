/**************************************************************************//**
 * @brief    ACK HMCU platform porting.
 *
 * @note
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
 
#include "main.h"
#include "top.h"
/**
  * @brief  The application entry point.
  * @retval int
  */
void setup(void);
void loop(void);
void mcu_init(void);

uint16_t AckDelay=100;

bool TestUgs=false;

extern void Alexa_InitiateUserGuidedSetup(void);

#ifdef MCU_LG6AE
#warning "............................please make sure IROM start addr is 0x2000 in options for target"
#else
#warning "............................please make sure IROM start addr is 0x1800 in options for target"
#endif

int main(void)
{
    mcu_init();

#ifdef ALEXA
//    while(AckDelay);
	setup();
#else
	PC14=0;
#endif
    while (1)
    {
		WDT_RESET_COUNTER();
		
        if(!AckDelay)
			UserEventLoop();
		
#ifdef ALEXA
		loop();
#endif		
    }
}

