#include "dev.h"
#include "top.h"
#include "self_check.h"
#include "brew.h"
#include "single.h"
#include "xb_uart.h"
#include "metrics.h"


bool gbDevSingleHeatRelay=false;

eDevStatus_t eDevStatus=eDevStatus_NotReadyToBrew;
eBrewStrength_t eBrewStrength=eBrewStrength_Regular;
eBrewStrength_t eBrewStrength_Carafe=eBrewStrength_Regular;
eBrewStrength_t eBrewStrength_Single=eBrewStrength_Regular;
eTimeSinceBrew_t eTimeSinceBrew=eTimeSinceBrew_UnavailableBrewerIsOff;
eBrewSetup_t eBrewSetup=eBrewSetup_Carafe;
eBrewSetup_t eBrewSetupBkp;		//save previously single mode
eCarafeKeepWarm_t eCarafeKeepWarm=eCarafeKeepWarm_2h;
eCoffeeFreshness_t eCoffeeFreshness=eCoffeeFreshness_Other;
ePowerSaver_t ePowerSaver=ePowerSaver_economyModeOn;

int16_t HeatTemp=NTC_OC;
float WaterTemp=NTC_OC;
float WaterTempForXb=NTC_OC;
uint16_t PumpCurrentAdcRes=0;
uint32_t Flowmeter=0;
uint32_t CarafeCounts=0;
uint32_t SingleCounts=0;
bool gbBrewChamberMicroswitch=true;
uint16_t gDevError=0;

uint8_t HeaterHighestTemp=0;
uint8_t WaterHighestTemp=0;
bool gbHighestTempUpdated=false;
void HighestTempCheck()
{
	static uint16_t ticks=0;
	
	if(WaterTemp<0 || HeatTemp<0)
		return;
	
	if(WaterTemp>=100 || HeatTemp>=100)
	{
		if(WaterTemp>WaterHighestTemp || HeatTemp>HeaterHighestTemp)
		{
			if(++ticks>=100)
			{
				ticks=0;
				WaterHighestTemp=(WaterTemp>WaterHighestTemp)?WaterTemp:WaterHighestTemp;
				HeaterHighestTemp=(HeatTemp>HeaterHighestTemp)?HeatTemp:HeaterHighestTemp;
				gbHighestTempUpdated=true;
			}
		}
		else
			ticks=0;
	}
	else
		ticks=0;
}

void DevErrorCheck()
{
	if(HeatTemp==NTC_SC)
		gDevError|=DEV_ERROR_HEAT_NTC_SC;
	else
		gDevError&=~DEV_ERROR_HEAT_NTC_SC;
	if(HeatTemp==NTC_OC)
		gDevError|=DEV_ERROR_HEAT_NTC_OC;
	else
		gDevError&=~DEV_ERROR_HEAT_NTC_OC;
	
	if(WaterTemp==NTC_SC)
		gDevError|=DEV_ERROR_WATER_NTC_SC;
	else
		gDevError&=~DEV_ERROR_WATER_NTC_SC;
	if(WaterTemp==NTC_OC)
		gDevError|=DEV_ERROR_WATER_NTC_OC;
	else
		gDevError&=~DEV_ERROR_WATER_NTC_OC;
	
//	if(gbAcOff)
//		gDevError|=DEV_ERROR_EC2;
}

uint16_t DevAwake=DEV_AWAKE;///2;

bool gbThermostatOff=false;
bool gbAcOff=false;

uint8_t gCleaningRequired=CLEANING_REQUIRED_NO;
uint8_t gCleaningRequiredLcd=CLEANING_REQUIRED_NO;

bool gbAckDsnRecived=false;

bool gbPower=false;
uint16_t TempSet_Celsius=DEFAULT_TEMP_CELSIUS_SET;
uint16_t TempSet_Fahrenheit=DEFAULT_TEMP_FAHRENHEIT_SET;
uint16_t TempNow_Celsius=0;
uint16_t TempNow_Fahrenheit=0;
uint16_t TempNowWithDot_Celsius=0;
uint16_t TempSet=0;

uint16_t TempUnit=2;

uint16_t TempSetTicks=0;

bool gbRelay=false;

uint16_t PreSet=17;
uint16_t TempSet_CelsiusBkp=DEFAULT_TEMP_CELSIUS_SET;
uint16_t TempSet_FahrenheitBkp=DEFAULT_TEMP_FAHRENHEIT_SET;

//Flowmeter
uint32_t GetFlowmeter()
{
	return Flowmeter;
}
void UpdateFlowmeter()
{
	Flowmeter++;
}
void ResetFlowmeter(uint32_t value)
{
	Flowmeter=value;
	#if C_PRINT
	printf("%s Flowmeter=%d \n",__func__,Flowmeter);
	#endif
}
//end

volatile uint32_t AcZeroCounts=0;
volatile uint32_t HeatZeroCounts=0;

//AcZeroCounts HeatZeroCounts
#define AC_ZERO_IO	PA8
static bool bAc60hz=true;
void CheckAcHz()
{
	static int check_ticks=100;
	static uint32_t counts;
	
	if(check_ticks==-1)
		return;
	if(check_ticks==100)
		counts=GetAcZeroCounts();
	check_ticks--;
	if(check_ticks==0)
	{
		if(GetAcZeroCounts()-counts>=47 && GetAcZeroCounts()-counts<=53)
		{
			bAc60hz=false;
			#if C_PRINT
			printf("%s %dhz\n",__func__,GetAcZeroCounts()-counts);
			#endif
		}
		else if(GetAcZeroCounts()-counts>=57 && GetAcZeroCounts()-counts<=63)
		{
			bAc60hz=true;
			#if C_PRINT
			printf("%s %dhz\n",__func__,GetAcZeroCounts()-counts);
			#endif
		}
		else
		{
			#if C_PRINT
			printf("%s invalid %dhz\n",__func__,GetAcZeroCounts()-counts);
			#endif
		}
	}
}
uint32_t GetAcZeroCounts()
{
	return AcZeroCounts;
}

bool gbUpdateTimeFromAc=false;

void UpdateAcZeroCounts()
{
	AcZeroCounts++;
	
	static uint8_t UpdateTimeFromAc=0;
	if(++UpdateTimeFromAc>=(bAc60hz?60:50))
	{
		UpdateTimeFromAc=0;
		gbUpdateTimeFromAc=true;
		#if 0//C_PRINT
		printf("%s \n",__func__);
		#endif
	}
	
}
void ResetAcZeroCounts()
{
	AcZeroCounts=0;
}

uint32_t GetHeatZeroCounts()
{
	return HeatZeroCounts;
}
void UpdateHeatZeroCounts()
{
	HeatZeroCounts++;
}
void ResetHeatZeroCounts()
{
	HeatZeroCounts=0;
}
//end

#if(DEBUG_ESO)
#define THERMOSTAT_IO	!PC5
#else
#define THERMOSTAT_IO	PF5
#endif
void Update_gbThermostatOff()
{
	static uint8_t ticks=0;
	static uint32_t tmp;
	
	if(!gbRelay && !gbDevSingleHeatRelay)
	{
		ticks=0;
		gbThermostatOff=false;
		return;
	}
	
	if(ticks==0)
	{
		tmp=GetHeatZeroCounts();
	}
	if(++ticks>=30)
	{
		ticks=0;
		if(GetHeatZeroCounts()-tmp>=10)
			gbThermostatOff=false;
		else
			gbThermostatOff=true;
	}
}
#define AC_IO	PF4
void Update_gbAc()
{
	static uint8_t ticks=0;
	static uint32_t tmp;
	
	if(ticks==0)
	{
		tmp=GetAcZeroCounts();
	}
	if(++ticks>=100)
	{
		ticks=0;
		if(GetAcZeroCounts()-tmp>=10)
			gbAcOff=false;
		else
			gbAcOff=true;
//		printf("\r\n GetAcZeroCounts=%d gbAcOff=%d \r\n",GetAcZeroCounts(),gbAcOff);
	}
}
#if PCB_VER>1
	#if !XB_UART
	#define BREW_CHAMBER_MICROSWITCH_IO		PA11
	#else
	#define BREW_CHAMBER_MICROSWITCH_IO		PA11
	#endif
#else
#define BREW_CHAMBER_MICROSWITCH_IO		PA10
#endif
void Update_gbBrewChamberMicroswitch()
{
	static uint16_t hold_ticks=0;
	
	#if 0//TEMP_SHOW || FM_DEBUG || CURRENT_SHOW || IGNORE_MICRO_SWITCH
	gbBrewChamberMicroswitch=true;
	return;
	#endif
	
	if(!BREW_CHAMBER_MICROSWITCH_IO)
	{
		if(++hold_ticks>=50)
		{
			if(!gbBrewChamberMicroswitch)
			{
				gbBrewChamberMicroswitch=true;
				gDevError=0;
				#if C_PRINT
				printf("\r\n %s -> Reset gDevError \r\n",__func__);
				#endif
				DevAwake=DEV_AWAKE;
				CheckResetPreHeatTicksCauseSingleOp();
				sRestartBrew.flag=false;
			}	
			gDevError&=~DEV_ERROR_CLOSE_LID;
		}
	}
	else
	{
		if(gbBrewChamberMicroswitch)
		{
			gbBrewChamberMicroswitch=false;
			gDevError=0;
			#if C_PRINT
			printf("\r\n %s -> Reset gDevError \r\n",__func__);
			#endif
			DevAwake=DEV_AWAKE;
			CheckResetPreHeatTicksCauseSingleOp();
			sRestartBrew.flag=false;
			SingleClear_ClearWaterTicks();
		}
		hold_ticks=0;
		if(eDevStatus>eDevStatus_ReadyToBrew && eBrewSetup>=eBrewSetup_Single8)
		{
			gDevError|=DEV_ERROR_CLOSE_LID;
			gbMetric__ERR_brew_chamber=true;
			#if XB_UART
			gXbUartErrorMask_CloseLid=128;
			#endif
		}
		ClearCoolHeaterTicks();
	}
}

void DevPowerOff()
{
	if(gbPower)
	{
		gbPower=false;
		eDevStatus=eDevStatus_NotReadyToBrew;
		eTimeSinceBrew=eTimeSinceBrew_Other;
		SingleClear_ClearWaterTicks();
	}
}

void DevPowerOn()
{
	if(!gbPower)// && eDevStatus==eDevStatus_ReadyToBrew)
	{
		if(!gbBrewChamberMicroswitch && eBrewSetup>=eBrewSetup_Single8)
		{
			gDevError|=DEV_ERROR_CLOSE_LID;
			#if XB_UART
			gXbUartErrorMask_CloseLid=64;
			#endif
			return;
		}
		gbPower=true;
		eDevStatus=eDevStatus_Brewing;
		
		clear_eso_pra();
		SingleClear_ClearWaterTicks();
	}
}


//	eTimeSinceBrew_Other,
//	eTimeSinceBrew_LessThan30minutes,
//	eTimeSinceBrew_LessThan45minutes,
//	eTimeSinceBrew_LessThan1hour,
//	eTimeSinceBrew_LessThan75minutes,
//	eTimeSinceBrew_LessThan90minutes,
//	eTimeSinceBrew_LessThan105minutes,
//	eTimeSinceBrew_LessThan2hour,

#if(AUTO_POWER_OFF_DELAY_SECONDS<=120)
const uint16_t ConstSec=1;
#else
const uint16_t ConstSec=60;
#endif
void UpdateTimeSinceBrew(uint16_t seconds)
{
//	if(eBrewSetup>=eBrewSetup_Single8)
//	{
//		eTimeSinceBrew=eTimeSinceBrew_UnavailableInSingleMode;
//		return;
//	}
	if(eDevStatus<eDevStatus_Brewing)
	{
		eTimeSinceBrew=eTimeSinceBrew_UnavailableBrewerIsOff;
		return;
	}
	if(eDevStatus==eDevStatus_Brewing)
	{
		eTimeSinceBrew=eTimeSinceBrew_StillBrewing;
		return;
	}
	if(!seconds)
		eTimeSinceBrew=eTimeSinceBrew_Other;
	else if(seconds<(15*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan15minutes;
	else if(seconds<(30*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan30minutes;
	else if(seconds<(60*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan1hour;
	else if(seconds<(90*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan90minutes;
	else if(seconds<(120*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan2hour;
	else if(seconds<(150*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan150minutes;
	else if(seconds<(180*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan3hour;
	else if(seconds<(210*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan210minutes;
	else if(seconds<(240*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan4hour;
}
void UpdateCoffeeFreshness()
{
	static uint16_t coffee_freshness_ticks_for_single=0;
		
	if(eBrewSetup>=eBrewSetup_Single8)
	{
		if(eDevStatus>=eDevStatus_Brewing)
		{
			coffee_freshness_ticks_for_single=15*60;
			eCoffeeFreshness=eCoffeeFreshness_StillBrewing;
		}
		else if(coffee_freshness_ticks_for_single)
		{
			coffee_freshness_ticks_for_single--;
			eCoffeeFreshness=eCoffeeFreshness_FreshlyBrewed;
		}
		else
		{
			eCoffeeFreshness=eCoffeeFreshness_UnavailableBrewerIsOff;
		}
		return;
	}
	
	coffee_freshness_ticks_for_single=0;
	eCoffeeFreshness=(eCoffeeFreshness_t)eTimeSinceBrew;
}
void DevClrTempSetTicks()
{
	TempSetTicks=0;
}
bool DevReloadTempSetTicks()
{
	if(gbPower)
	{
		if(!TempSetTicks)
		{
			TempSetTicks=TEMP_SET_TICKS_POWER_ON;
			return true;
		}
		TempSetTicks=TEMP_SET_TICKS_POWER_ON;
		return false;
	}
	
	if(!TempSetTicks)
	{
		TempSetTicks=TEMP_SET_TICKS;
		return true;
	}
	TempSetTicks=TEMP_SET_TICKS;
	return false;
}
bool DevGetTempSetStatus()
{
	if(TempSetTicks)
		return true;
	return false;
}
bool DevGetTempSetFlashShow()
{
//	if(gbPower)
//		return true;
	if((TempSetTicks%1000)>=500)
		return true;
	return false;
}
bool DevGetTempSetShow()
{
	if(TempSetTicks)
		return true;
	return false;
}

void DevHandleForTmrInt()
{
	if(TempSetTicks)
		TempSetTicks--;
	
	if(DevAwake && eDevStatus<eDevStatus_Brewing)
	{
		DevAwake--;
		#if C_PRINT
		if(!DevAwake)
			printf("%s DevAwake clear \r\n",__func__);
		#endif
	}
}

void DevHeaterRelay(bool on)
{
	
}




#if FM_DEBUG
#define RELAY_ON	
#define RELAY_OFF	
#else
#define RELAY_ON	PF2=1
#define RELAY_OFF	PF2=0
#endif

#if FM_DEBUG
#define SINGLE_RELAY_ON		
#define SINGLE_RELAY_OFF	
#else
#if 0//FM_SHOW
#define SINGLE_RELAY_ON		PF3=0
#define SINGLE_RELAY_OFF	PF3=0
#else
#define SINGLE_RELAY_ON		PF3=1
#define SINGLE_RELAY_OFF	PF3=0
#endif
#endif
void DevHandle()
{
	if(gbBrewRelay || gbSelfCheckRelayOn)
	{
		#if C_PRINT
		if(!gbRelay)
			printf("%s -> gbRelay=1 \r\n",__func__);
		#endif
		gbRelay=true;
	}
	else
	{
		#if C_PRINT
		if(gbRelay)
			printf("%s -> gbRelay=0 \r\n",__func__);
		#endif
		gbRelay=false;
	}
	
	if(gbRelay)
		RELAY_ON;
	else
		RELAY_OFF;
	
	if(Single_GetHeatRelay())
	{
		SINGLE_RELAY_ON;
		if(!gbDevSingleHeatRelay)
		{
			gbDevSingleHeatRelay=true;
			#if C_PRINT
			printf("\r\n %s -> gbDevSingleHeatRelay=%d \r\n",__func__,gbDevSingleHeatRelay);
			#endif
		}
	}
	else
	{
		SINGLE_RELAY_OFF;
		if(gbDevSingleHeatRelay)
		{
			gbDevSingleHeatRelay=false;
			#if C_PRINT
			printf("\r\n %s -> gbDevSingleHeatRelay=%d \r\n",__func__,gbDevSingleHeatRelay);
			#endif
		}
	}
	
	
	
}







