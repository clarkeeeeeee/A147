#ifndef _KEY_H_
#define _KEY_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

typedef enum
{
  	eKeyStatus_Null,
	eKeyStatus_Down,
	eKeyStatus_Long,
}eKeyStatus_t;

typedef enum
{
  	eKey_Null,
	eKey_IO,
	eKey_OPTION,
	eKey_READY,
	eKey_WIFI,
	eKey_TIME,
	eKey_CARAFE,
	eKey_SINGLE,
	eKey_REGULAR,
	eKey_BOLD,
}eKey_t;

extern eKey_t geKey;

typedef struct
{
  	uint8_t key_pre;
    uint8_t key_lock;
    uint8_t key_now;
	uint32_t key_cnts;
	uint8_t key_long;
}sKey_t;

extern uint8_t SetTicks;

extern bool KeyLongFlag;
extern sKey_t sKey;
extern bool gbKeyUgsEn;
extern bool gbKeyFrsEn;
extern bool gbKeyFrsDown;
extern bool gbKeyUgsDown;
extern uint8_t gKeyStuck;

void KeyHandle();
void KeyInit();

#endif