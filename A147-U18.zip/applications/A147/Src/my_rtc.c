#include "my_rtc.h"
#include "rtc.h"
#include "time.h"
#include <hal_sys.h>
#include "board.h"
#include "numicro_hal.h"




S_RTC_TIME_DATA_T MyRtc;
S_RTC_TIME_DATA_T sCurTime;

static unsigned long MyRtcCounts=0;

void MyRtcInit()
{
	MyRtc.u32Year       = 2017;
    MyRtc.u32Month      = 5;
    MyRtc.u32Day        = 1;
    MyRtc.u32Hour       = 12;
    MyRtc.u32Minute     = 30;
    MyRtc.u32Second     = 0;
    MyRtc.u32DayOfWeek  = RTC_MONDAY;
    MyRtc.u32TimeScale  = RTC_CLOCK_12;
	MyRtc.u32AmPm		= RTC_AM;
	
	RTC_CLKSRCRESET();
	RTC_CLKSRCSEL(0<<RTC_LXTCTL_C32KS_Pos);//RTC_CLKSRC_LXT return;
	RTC_Open(&MyRtc);
	RTC_SetTickPeriod(RTC_TICK_1_SEC);
	#if 0
	RTC_EnableInt(RTC_INTEN_TICKIEN_Msk);
	NVIC_EnableIRQ(RTC_IRQn);
	NVIC_SetPriority(RTC_IRQn,1);
	RTC->INTSTS = 0x2;
	#endif
	/* Get the current time */
    RTC_GetDateAndTime(&sCurTime);

    printf("Current Time:%d/%02d/%02d %02d:%02d:%02d\n",sCurTime.u32Year,sCurTime.u32Month,
           sCurTime.u32Day,sCurTime.u32Hour,sCurTime.u32Minute,sCurTime.u32Second);
}

void RTC_IRQHandler()
{
	/* clear timer interrupt flag */
//    RTC_CLEAR_TICK_INT_FLAG();
	
	if ( (RTC->INTEN & RTC_INTEN_TICKIEN_Msk) && (RTC->INTSTS & RTC_INTSTS_TICKIF_Msk) )        /* tick interrupt occurred */
    {
        RTC->INTSTS = 0x2;

//        TimeRtcRun();
    }
	
	#if C_PRINT
	printf("%s MyRtcCounts=%ld\r\n",__func__,MyRtcCounts++);
	#endif
}

void RTC_setTime(int16_t hh,int16_t mm,int16_t ss,bool am)
{
	sCurTime.u32Hour=hh;
	sCurTime.u32Minute=mm;
	sCurTime.u32Second=ss;
	sCurTime.u32AmPm=(am==true)?RTC_AM:RTC_PM;
	
	RTC_SetDateAndTime(&sCurTime);
}

void RTC_handle()
{
	static uint8_t ticks=0;
	
	if(++ticks>=100)
	{
		ticks=0;
		RTC_GetDateAndTime(&sCurTime);
		#ifdef MCU_LG6AE
		TimeRtcRun_fromMyRtc(sCurTime.u32Hour,sCurTime.u32Minute,sCurTime.u32Second,(sCurTime.u32AmPm==RTC_AM)?true:false);
		#endif
		printf("Current Time:%d/%02d/%02d %02d:%02d:%02d\n",sCurTime.u32Year,sCurTime.u32Month,
           sCurTime.u32Day,sCurTime.u32Hour,sCurTime.u32Minute,sCurTime.u32Second);
	}
}























